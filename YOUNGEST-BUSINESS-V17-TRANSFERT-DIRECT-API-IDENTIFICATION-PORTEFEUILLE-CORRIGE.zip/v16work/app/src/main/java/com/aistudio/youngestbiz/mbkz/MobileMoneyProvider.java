package com.aistudio.youngestbiz.mbkz;

/**
 * V17 contract for a real Mobile Money / authorized PSP integration.
 * The Android app must never collect or store the customer's Mobile Money PIN.
 * A production implementation should call a secure backend, not expose API secrets in the APK.
 */
public interface MobileMoneyProvider {
    /** Verify that the number belongs to the selected Mobile Money wallet and return the wallet holder name when the provider exposes it. */
    WalletVerification verifyWallet(String phone);

    /** Start a transfer authorization with the provider/PSP. */
    String initiateTransfer(String senderPhone, String beneficiaryPhone, double amount, String currency);

    /** Query the provider/PSP for the transaction status. */
    String getStatus(String providerReference);

    class WalletVerification {
        public final boolean verified;
        public final String phone;
        public final String holderName;
        public final String message;

        public WalletVerification(boolean verified, String phone, String holderName, String message) {
            this.verified = verified;
            this.phone = phone;
            this.holderName = holderName;
            this.message = message;
        }
    }
}
