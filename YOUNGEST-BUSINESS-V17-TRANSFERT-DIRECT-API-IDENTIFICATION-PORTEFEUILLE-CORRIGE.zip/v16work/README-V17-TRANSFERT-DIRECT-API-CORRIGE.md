# YOUNGEST'S BUSINESS — V17 corrigé

## Fonction principale
V17 sépare explicitement l'identification d'un **portefeuille Mobile Money** de l'identité GSM/SIM.

Le client choisit le réseau : M-Pesa, Airtel Money, Orange Money ou Afrimoney, puis saisit le numéro du portefeuille.
Le bouton **VÉRIFIER LE PORTEFEUILLE** doit, en production, appeler le service officiel de l'opérateur ou un PSP autorisé et afficher le nom du titulaire retourné par ce service lorsqu'il est disponible.

## État actuel
Cette archive reste une **simulation fonctionnelle** : elle ne débite aucun compte Mobile Money réel. Les profils déjà présents dans l'application servent uniquement à tester l'affichage du flux. Un numéro inconnu n'est pas inventé ni accepté comme portefeuille vérifié.

## Authentification
V17 ne demande et ne stocke aucun PIN Mobile Money. En production, l'authentification doit être effectuée par l'opérateur/PSP (PIN, OTP, USSD, push ou autre mécanisme officiel).

## Architecture API
`MobileMoneyProvider.java` définit le contrat pour brancher un fournisseur réel :
- vérification du portefeuille et du nom lorsqu'exposé par l'API ;
- initiation du transfert ;
- suivi du statut.

Les clés/API secrets ne doivent pas être embarqués dans l'APK : utiliser un backend sécurisé et l'onboarding/les autorisations du fournisseur.
