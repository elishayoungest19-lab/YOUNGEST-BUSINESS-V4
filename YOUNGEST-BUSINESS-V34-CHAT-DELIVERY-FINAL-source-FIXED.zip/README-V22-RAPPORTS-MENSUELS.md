# V22 — Rapports mensuels internes

Ajouté au menu Bureau / Administration :
- rapport filtrable par mois et année ;
- prêts accordés pendant le mois et intérêts prévus ;
- paiements reçus pendant le mois avec liste des dates et montants ;
- échéances dues pendant le mois ;
- prêts en retard à la date de consultation ;
- solde actuel à récupérer ;
- partage/export du rapport sous forme de texte via les applications Android disponibles.

Les rapports sont visibles depuis l'espace Administration uniquement. Les calculs utilisent les prêts et paiements présents dans les données de l'application. La synchronisation Firebase doit avoir terminé son chargement pour que les chiffres reflètent toutes les données cloud.

Note : le « solde actuel à récupérer » est un instantané de la situation actuelle, même lorsqu'on consulte un mois antérieur ; les données historiques complètes nécessitent des journaux d'événements immuables.
