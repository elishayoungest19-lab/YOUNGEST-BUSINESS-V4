# YOUNGEST’S BUSINESS V32 — Correction définitive du routage Chat

## Objectif
V32 corrige deux points qui pouvaient empêcher le Bureau de voir correctement les conversations :

1. Le compte administrateur est reconnu par le UID Firebase historique **ou** par l’adresse administrateur `elishayoungest19@gmail.com`.
2. Les règles Firestore utilisent la même logique d’autorisation Admin (UID historique ou email Admin).

## Parcours client conservé
CONTACTEZ-NOUS → message → vérification SMS → compte Firebase téléphone → conversation `yb_chat_conversations` → message dans `messages` → boîte de réception Admin.

## Sécurité
La création d’une conversation et l’envoi d’un message client restent réservés à un utilisateur Firebase authentifié par téléphone. Le téléphone n’est donc pas contourné.

## Point important
Le code ne peut pas activer Phone Authentication ni enregistrer les SHA-1/SHA-256 dans la console Firebase à distance. Si l’APK affiche une erreur Phone Auth/SMS, il faut activer **Authentication > Sign-in method > Phone** et enregistrer les empreintes du certificat qui signe l’APK dans Firebase.

## Version
- versionCode: 32
- versionName: 1.25.0
- applicationId: `com.aistudio.youngestbiz.mbkz`
