# V27 — Chat intégré à CONTACTEZ-NOUS

- Reprise de la base source V26.
- Côté client, la page CONTACTEZ-NOUS conserve les coordonnées et ajoute un bouton pour démarrer le chat.
- Côté administration, CONTACT_NOUS propose les coordonnées et l'accès « Répondre au chat ».
- Le projet Firebase et les règles existantes sont conservés ; aucune modification automatique de Firebase n'est effectuée.

## Vérifications restantes

Compiler avec GitHub Actions puis tester la vérification SMS, l'envoi/réception des messages et les autorisations des conversations.
