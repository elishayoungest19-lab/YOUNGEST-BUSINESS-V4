# YOUNGEST'S BUSINESS V24 — Journal Mobile Money et interface P2P

Cette version repart du projet V22 fourni et conserve les fonctions existantes.

## Journal des opérations
- Enregistrement manuel d'une opération déjà effectuée (aucun transfert déclenché depuis le journal).
- Date, numéro, nom complet, montant, frais distincts et devise CDF/USD.
- Filtre aujourd'hui / mois courant / historique et recherche par date, nom ou numéro.
- Totaux séparés CDF et USD : nombre d'opérations, montants envoyés, frais et total montant + frais.
- Stockage local sur l'appareil via SharedPreferences. Les entrées du journal V24 ne sont pas encore synchronisées entre plusieurs appareils.

## Transferts P2P
L'espace Transferts existant est conservé. Un vrai envoi nécessite une API opérateur/prestataire active, des identifiants serveur valides et la confirmation du prestataire. Le journal ne réalise aucun débit Mobile Money.

## Construire l'APK signé avec GitHub Actions
1. Ajouter `YOUNGEST-BUSINESS-V24-JOURNAL-P2P.zip` à la racine du dépôt GitHub.
2. Remplacer le workflow dans `.github/workflows/build-apk.yml` par le workflow fourni dans ce projet.
3. Vérifier les secrets du dépôt : `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_PASSWORD`.
4. Exécuter Actions et télécharger l'artifact `YOUNGEST-BUSINESS-V24-JOURNAL-P2P-APK`.

Le ZIP du projet ne contient pas d'APK déjà construit. La signature est vérifiée dans GitHub Actions.
