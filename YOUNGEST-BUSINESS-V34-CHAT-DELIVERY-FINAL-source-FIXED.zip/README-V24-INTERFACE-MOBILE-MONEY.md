# YOUNGEST'S BUSINESS V24 — Interface Mobile Money

Version Android: `versionCode 24`, `versionName 1.18.0`.

## Changements V24
- Nouvelle page d'accueil Mobile Money commune aux espaces Client et Administration.
- Quatre actions distinctes : Envoyer de l'argent, Recevoir, Historique et Rapports.
- Le parcours Envoyer réutilise les pages de transfert existantes (client et bureau) au lieu de simuler une opération.
- Recevoir conserve les coordonnées Mobile Money déjà présentes.
- Historique et rapports renvoient vers les historiques existants; le bureau accède au journal manuel des opérations.
- Le journal manuel demeure distinct des transferts réels : il n'envoie pas d'argent.

## Limites importantes
L'interface seule ne réalise pas un paiement. Un transfert réel dépend du backend/API WonyaPay autorisé et de sa confirmation. Les libellés, montants ou statuts ne doivent pas être considérés comme preuve de paiement sans réponse confirmée du prestataire.

Le journal manuel utilise le stockage local de l'appareil. Pour partager ces enregistrements entre plusieurs appareils, il faudra implémenter et sécuriser une synchronisation serveur.
