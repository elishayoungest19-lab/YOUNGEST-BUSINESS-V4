# YOUNGEST’S BUSINESS V31 — Correction de session Firebase du Bureau

V31 corrige la déconnexion de l’espace Administrateur : le bouton SE DÉCONNECTER ferme désormais aussi la session Firebase (`firebaseAuth.signOut()`), réinitialise l’UID client local et le brouillon de chat.

Objectif : empêcher qu’un ancien compte Firebase Admin reste connecté et que CONTACTEZ-NOUS redirige automatiquement vers BOÎTE DE RÉCEPTION CHAT.

Le parcours client du chat reste : CONTACTEZ-NOUS → ENVOYER LE MESSAGE → vérification SMS si nécessaire → conversation Firestore.
