# V28 — Notifications automatiques du chat

Cette version ajoute une Cloud Function Firebase qui envoie une notification FCM au client quand un message avec `senderRole: admin` est créé dans `yb_chat_conversations/{conversationId}/messages/{messageId}`.

## Déploiement requis

1. Déployer les règles Firestore nécessaires au chat et aux jetons.
2. Dans un environnement avec Firebase CLI connecté au bon projet, installer les dépendances de `functions` (`npm install`).
3. Déployer les fonctions (`firebase deploy --only functions:notifyClientWhenAdminReplies`).
4. Installer l’APK V28 sur l’appareil client, ouvrir l’application et accepter les notifications Android.
5. Tester avec une réponse réelle de l’administration pendant que l’application est en arrière-plan puis fermée.

La compilation de l’APK seule ne déploie pas la Cloud Function. Les notifications nécessitent une connexion Internet et l’autorisation de notifications du téléphone.
