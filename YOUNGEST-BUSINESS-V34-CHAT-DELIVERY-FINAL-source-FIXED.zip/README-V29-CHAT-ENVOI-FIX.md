# YOUNGEST'S BUSINESS V29 — correctif envoi du chat

- Le bouton d'envoi affiche maintenant une erreur utile au lieu de quitter silencieusement si aucun compte Firebase n'est connecté.
- Le parcours de vérification SMS est relancé côté client si nécessaire.
- Les erreurs Firebase sont affichées et journalisées pour faciliter le diagnostic.
- Version Android : versionCode 29, versionName 1.23.0.

Le code doit être compilé et testé avec GitHub Actions avant installation.
