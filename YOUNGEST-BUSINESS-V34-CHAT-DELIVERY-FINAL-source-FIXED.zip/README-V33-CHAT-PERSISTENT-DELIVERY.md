# YOUNGEST'S BUSINESS V33 — CHAT PERSISTENT DELIVERY

## Objectif
Rendre le chat client persistant et fiable après authentification téléphone et redémarrage de l'application.

## Corrections
- Le brouillon du client est sauvegardé dans SharedPreferences (`pending_chat_draft`) au lieu de rester uniquement en mémoire.
- Le brouillon est restauré dans CONTACTEZ-NOUS après recréation/redémarrage de l'Activity.
- La création d'une nouvelle conversation et son premier message client sont écrits dans une transaction Firestore.
- Pour une conversation existante, le message client et la mise à jour `lastMessage/adminUnread/updatedAt` sont écrits dans une transaction.
- Le brouillon n'est effacé qu'après réussite de l'écriture Firestore.
- Une erreur d'envoi conserve le message pour permettre une nouvelle tentative.
- Le processus de notification FCM est séparé de l'enregistrement du message client.
- Version Android : versionCode 33, versionName 1.26.0.
