# YOUNGEST'S BUSINESS V30 — Chat robuste et diagnostic Firebase

Cette version conserve le chat V29 mais renforce le parcours d'envoi :
- le texte n'est plus pré-enregistré comme `lastMessage` avant le vrai enregistrement du message ;
- les erreurs Firebase détaillées sont affichées ;
- l'échec de création, de lecture, d'enregistrement du message et de mise à jour de conversation est distingué ;
- le brouillon reste conservé si l'enregistrement échoue.

## Configuration Firebase indispensable
1. Authentication → Sign-in method → Phone doit être activé.
2. Les empreintes SHA-1 et SHA-256 du certificat qui signe l'APK doivent être enregistrées dans Firebase.
3. Les règles `firestore.rules` de ce ZIP doivent être déployées sur le projet `youngestsbusiness`.
4. L'UID administrateur dans `isAdmin()` doit correspondre au compte administrateur réel.

La compilation GitHub Actions ne déploie pas automatiquement les règles Firestore ni les paramètres Authentication.

## Test
Client : CONTACTEZ-NOUS → écrire → ENVOYER LE MESSAGE → SMS → message.
Admin : BOÎTE DE RÉCEPTION CHAT → conversation.
