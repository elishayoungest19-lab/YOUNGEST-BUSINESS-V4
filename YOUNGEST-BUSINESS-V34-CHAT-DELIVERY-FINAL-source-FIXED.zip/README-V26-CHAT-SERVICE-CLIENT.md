# YOUNGEST'S BUSINESS V26 — Chat Service Client

## Inclus dans cette version
- Accès au chat depuis l'écran d'accueil et l'espace client.
- Authentification client par numéro de téléphone avec code SMS Firebase.
- Liaison du téléphone au compte Firebase anonyme existant, lorsqu'il est présent, afin de conserver le même UID client.
- Conversation client synchronisée dans Firestore et boîte de réception réservée à l'UID administrateur configuré dans les règles.
- Règles Firestore dédiées aux conversations et aux messages, sans accès aux conversations d'autres clients.
- Version Android `versionCode 26`, `versionName 1.20.0`.

## Configuration Firebase indispensable avant les tests
1. Dans Firebase Console → Authentication → Sign-in method, activer **Phone**. L'authentification anonyme reste nécessaire au parcours client existant.
2. Dans les paramètres du projet Firebase, enregistrer les empreintes SHA-1 et SHA-256 du certificat de signature utilisé pour construire l'APK. La vérification téléphone peut échouer si elles manquent.
3. Déployer `firestore.rules` sur le projet `youngestsbusiness` (Firestore → Rules, ou `firebase deploy --only firestore:rules` depuis un environnement Firebase CLI connecté).
4. Vérifier que l'UID de l'administrateur dans `isAdmin()` est toujours celui du compte Admin réel. Ne pas remplacer cette vérification par une adresse e-mail côté client.
5. Tester avec un numéro réel et un deuxième appareil. Firebase peut appliquer des limites ou des coûts aux SMS selon le projet et la région.

## Important
Le code et les règles sont préparés, mais ce ZIP n'est pas une preuve que l'APK a été compilé ou que les SMS/Firestore ont été testés sur appareils. La compilation signée doit être exécutée dans GitHub Actions avec les secrets de signature déjà utilisés pour V25. Les règles Firestore doivent être déployées avant de tester le chat en ligne.

## Construction GitHub Actions
Le workflow `.github/workflows/build-apk.yml` recherche le fichier `YOUNGEST-BUSINESS-V26-CHAT-SERVICE-CLIENT.zip` dans le dépôt. Ajoutez ce ZIP au dépôt, puis lancez le workflow `Build YOUNGEST'S BUSINESS V26 Chat Service Client`.
