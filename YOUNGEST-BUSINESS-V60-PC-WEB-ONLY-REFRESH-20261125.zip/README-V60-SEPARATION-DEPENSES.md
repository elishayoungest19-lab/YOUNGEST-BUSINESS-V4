# YOUNGEST’S BUSINESS V60 — Journal des opérations

## Modifications V60
- Formulaire ENVOI / RETRAIT distinct du formulaire DÉPENSE, sur Android et Web Admin.
- Les dépenses restent enregistrées dans `yb_mobile_money_journal` avec `type=DEPENSE`, pour préserver l’historique et la synchronisation existante.
- Les dépenses sont présentées dans une section dédiée, après le résumé des frais journaliers.
- Les reçus individuels restent réservés aux opérations ENVOI et RETRAIT.
- Les rapports intègrent les opérations et les dépenses; les devises CDF et USD restent calculées séparément, sans conversion.
- Version Android : `versionCode 60`, `versionName 1.60.0-separated-expenses`.

## Conservation
Le projet complet V59 est conservé : prêts, clients, remboursements, demandes, chat, Wi-Fi, journal LUMICASH, Firebase et reçus. Le flux de dépenses LUMICASH reste indépendant.

## Déploiement
Le workflow `yb-journal-v60.yml` lance en parallèle la compilation APK Android et le déploiement Firebase Hosting. Il ne déploie pas Cloud Functions ni les règles Firestore.

Secrets GitHub requis : `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_PASSWORD`, `FIREBASE_SERVICE_ACCOUNT_JSON`.
