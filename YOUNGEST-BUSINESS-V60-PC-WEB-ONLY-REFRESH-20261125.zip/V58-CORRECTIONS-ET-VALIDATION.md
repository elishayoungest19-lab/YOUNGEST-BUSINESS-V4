# YOUNGEST'S BUSINESS — V58 corrections et contrôles

## Corrections intégrées dans les sources

### Journal LUMICASH (Android + Web Admin + Firebase)
- Opérateur fixé à LUMICASH.
- Types de transaction : dépôt et retrait; les dépenses restent identifiées séparément.
- Saisie de la devise FBU, CDF ou USD pour chaque opération et dépense.
- Dépenses avec motif, montant, date, agent et devise.
- Historique Android/Web et export PDF Android/Web.
- Résultat net calculé par devise : frais de dépôt + commissions de retrait − dépenses.
- Aucune addition entre devises différentes.
- Les anciens enregistrements sans devise restent interprétés en FBU.

### YOUNGEST'S B WIFI (Android + Web Admin + Firebase)
- Saisie des dépenses avec motif, montant, devise, date et agent.
- Enregistrement dans `yb_wifi_expenses` avec service `WIFI`.
- Historique des dépenses sur Android et Web Admin.
- Rapports PDF avec recettes confirmées, dépenses et résultat net, séparés par devise.
- Journal d'audit pour les dépenses Wi-Fi.

### Reçus Mobile Money
- Les reçus restent réservés au Journal Envoi Argent / Mobile Money.
- Les reçus Lumicash et Wi-Fi ne sont pas ajoutés.
- L'opérateur, la référence, le client, le montant, les frais/commissions, l'agent et le statut sont affichés à partir des données enregistrées.

### Déploiement GitHub Actions
- Le workflow valide les fichiers JavaScript et la présence des modules attendus.
- Le workflow compile et vérifie l'APK signé avant le déploiement.
- Le déploiement inclut Hosting, règles Firestore et Cloud Functions.

## Contrôles effectués dans cet environnement
- `node --check web-admin/app.js` : OK.
- `node --check functions/index.js` : OK.
- Contrôles statiques des chemins, collections, reçus et versionCode : OK.
- Vérification de syntaxe YAML du workflow : OK.
- Vérification d'équilibre des délimiteurs Java et analyse syntaxique `javac` sans erreur de syntaxe détectée : OK.

## Contrôles qui restent à exécuter dans GitHub / Firebase
- La compilation Android complète n'a pas pu être exécutée ici : Android SDK et Gradle ne sont pas installés dans cet environnement.
- Le workflow GitHub doit confirmer la compilation réelle, la signature APK et les secrets de déploiement.
- Le déploiement Firebase doit être exécuté avec le secret `FIREBASE_SERVICE_ACCOUNT_JSON` et les secrets Cloud Functions existants (`AGENT1_PIN`, `AGENT2_PIN`, ainsi que les secrets utilisés par les autres fonctions).
- Après déploiement, faire un test réel de création/lecture d'une dépense Lumicash et Wi-Fi depuis Android et Web Admin, puis vérifier le PDF et la synchronisation sur les deux interfaces.

**Important :** cette archive contient les sources V58 modifiées. Elle n'est pas une preuve que le build GitHub ou le déploiement Firebase ont déjà réussi.
