# YOUNGEST’S BUSINESS V59 — Reçus officiels personnalisés

## Corrections intégrées
- Formulaire Web Admin et formulaire Android : numéro du bénéficiaire avant nom et postnom.
- Reçu Web imprimable : logo officiel fourni, identité bleu marine/vert/or, tableau encadré, numéro avant nom/postnom, frais d’envoi cohérents, contacts et localisation Congo / DRC.
- Reçu PDF Android : mise en page dédiée avec logo officiel, tableau, montant/statut mis en évidence et coordonnées.
- Logo officiel fourni intégré au Web Admin et à la ressource Android.
- Version Android : versionCode 59, versionName 1.59.0-branded-receipts.

## Coordonnées du pied de reçu
- +243 817 447 127
- +243 994 565 534
- +257 646 604 75
- Congo / DRC

## Déploiement
Le workflow `.github/workflows/yb-journal-v59.yml` construit l’APK signé et déploie Firebase Hosting + Firestore rules uniquement. Il ne déploie pas Cloud Functions et n’active pas Blaze. Les opérations qui dépendent encore de fonctions serveur existantes doivent être testées séparément.
