YOUNGEST'S BUSINESS V59 - RECEIPT FIX

Web receipt corrections:
- Logo uses an absolute Firebase Hosting path with a cache-busting token.
- Print waits for the logo to load before opening the print dialog.
- Receipt rows remain ordered: beneficiary number, beneficiary name, client postname.
- Contact footer is retained with the three supplied numbers and Congo / DRC.
- Web app script cache token updated to force browsers to fetch the corrected JavaScript.

No Firestore rules, collections, authentication, or Cloud Functions were changed.
Android versionCode/versionName remain 59 / 1.59.0-branded-receipts.
