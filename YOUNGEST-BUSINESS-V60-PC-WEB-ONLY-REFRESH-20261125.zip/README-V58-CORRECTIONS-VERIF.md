# V58 — Corrections des journaux et vérifications

- Journal LUMICASH : types DEPOT / RETRAIT / DEPENSE, motif, postnom, devise FBU/CDF/USD, opérateur fixe LUMICASH.
- Synchronisation Android vers Firestore et lecture Android des nouveaux champs; anciens enregistrements sans type traités comme DEPOT et sans devise comme FBU.
- Web Admin : agrégation des frais et dépenses par devise, sans additionner CDF, USD et FBU.
- YB Wi-Fi : module de dépenses et rapport net présents dans les sources Web Admin.
- Reçus : réservés au journal Mobile Money.

## Déploiement
Ne pas considérer ce ZIP comme déjà déployé. GitHub Actions doit compiler l’APK et déployer les composants Firebase avec les secrets et droits nécessaires. Vérifier en environnement de test avant utilisation en production.
