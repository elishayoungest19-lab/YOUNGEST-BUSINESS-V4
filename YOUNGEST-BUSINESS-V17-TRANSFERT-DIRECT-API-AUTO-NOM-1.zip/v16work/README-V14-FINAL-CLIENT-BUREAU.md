# YOUNGEST'S BUSINESS V14 FINAL - ESPACE CLIENT / BUREAU

Cette version V14 renforce le parcours de demande de prêt client :

- profil client local (nom et téléphone) pour préremplir les demandes ;
- création et envoi d'une demande de prêt ;
- page MES DEMANDES avec compteurs EN ATTENTE / APPROUVÉES / REFUSÉES ;
- détail complet d'une demande ;
- affichage des informations du prêt lorsqu'une demande est approuvée ;
- bouton d'actualisation des demandes ;
- accès aux demandes côté bureau pour étude, approbation ou refus ;
- synchronisation Firestore via la collection yb_loan_requests.

La version reste une phase pilote : l'authentification client anonyme et les règles Firestore actuelles ne constituent pas encore une sécurité suffisante pour une ouverture publique d'un service financier réel.
