# YOUNGEST’S BUSINESS — V17 TRANSFERT MOBILE MONEY DIRECT + API

## Objectif
Permettre au client de préparer et autoriser directement un transfert Mobile Money depuis son espace client, sans validation manuelle du bureau pour chaque opération.

## Flux V17
1. Le client ouvre « ENVOYER DE L’ARGENT ».
2. Il choisit FC ou USD.
3. Il choisit le portefeuille source : M-Pesa, Airtel Money, Orange Money ou Afrimoney.
4. Le portefeuille source est identifié par le numéro du client.
5. Il saisit le bénéficiaire et son réseau.
6. Il saisit le montant.
7. Les frais de 1,5 % et le total sont calculés automatiquement.
8. L’application crée une demande d’autorisation API.
9. En V17 pilote, une simulation API permet de tester le parcours complet sans mouvement d’argent réel.
10. En production, la réponse de l’API officielle du prestataire déterminera le résultat réel du débit/crédit.

## Sécurité
- Aucun PIN Mobile Money n’est demandé ni enregistré par l’application.
- L’authentification/autorisation réelle devra utiliser les mécanismes officiels du prestataire.
- Le bureau sert à superviser les opérations et non à approuver manuellement chaque transfert.

## Statuts
- EN COURS
- TERMINÉ
- ANNULÉ

## Frais
- FC : 1,5 %
- USD : 1,5 %

## Important
Cette version V17 est un pilote avec simulation API. Elle ne débite pas réellement M-Pesa, Airtel Money, Orange Money ou Afrimoney. Le mouvement d’argent réel nécessitera l’intégration technique, les identifiants API, les mécanismes d’authentification/consentement et les autorisations/accords nécessaires auprès du prestataire de paiement concerné.


## V17.1 — Identification automatique du titulaire

- Le nom de l'expéditeur est prérempli depuis le profil client vérifié.
- Le nom du bénéficiaire est rempli automatiquement lorsqu'un numéro correspond à un profil client déjà vérifié dans les données de l'application.
- La normalisation accepte les formats congolais +243, 243 et 0XXXXXXXXX.
- En mode simulation, un numéro inconnu reste non identifié au lieu d'inventer un nom.
- En production, la vérification du titulaire devra être fournie par l'API officielle du réseau Mobile Money choisi.
