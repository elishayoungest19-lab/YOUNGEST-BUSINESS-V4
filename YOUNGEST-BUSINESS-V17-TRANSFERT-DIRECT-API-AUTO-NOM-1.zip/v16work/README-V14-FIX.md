# YOUNGEST’S BUSINESS V14 — Correction

Cette version conserve les fonctions V14 de demandes de prêt client et ajoute :
- accès visible aux demandes clients depuis l'accueil Bureau ;
- compteur des demandes en attente ;
- accès direct aux demandes depuis le tableau de bord ;
- message explicite lorsqu'un espace client n'a aucune demande ;
- version Android 1.4.0 / versionCode 8 pour identifier correctement V14.

Le workflow GitHub doit fournir `google-services.json` et la clé de signature comme dans les versions précédentes.
