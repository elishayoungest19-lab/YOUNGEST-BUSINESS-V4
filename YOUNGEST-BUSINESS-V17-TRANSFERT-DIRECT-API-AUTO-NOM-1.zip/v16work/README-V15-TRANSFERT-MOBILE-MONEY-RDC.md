# YOUNGEST'S BUSINESS — V15 Transfert Mobile Money RDC

Cette version ajoute la première étape fonctionnelle du module **TRANSFERT MOBILE MONEY** destiné à la RDC.

## Contenu vérifié
- Devise : **FC (franc congolais)**, sans FBu dans ce module.
- Expéditeur : nom, numéro, réseau Mobile Money.
- Bénéficiaire : nom, numéro, réseau Mobile Money.
- Réseaux proposés : M-Pesa, Airtel Money, Orange Money, Afrimoney.
- Montant du transfert en FC.
- Frais de transfert en FC.
- Calcul automatique du total : montant + frais.
- Motif / description facultatif.
- Référence générée automatiquement.
- Date et heure enregistrées automatiquement.
- Statut initial : **EN_COURS**.
- Confirmation et reçu récapitulatif après enregistrement.
- Enregistrement local persistant des transferts.

Les fonctions « transferts en cours », « terminés », « annulés » et « historique » restent volontairement pour les prochaines étapes, afin de continuer bouton par bouton.
