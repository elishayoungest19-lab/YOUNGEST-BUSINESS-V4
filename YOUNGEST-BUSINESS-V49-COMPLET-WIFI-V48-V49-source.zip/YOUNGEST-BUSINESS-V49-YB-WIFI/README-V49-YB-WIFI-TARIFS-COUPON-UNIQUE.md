# V49 — YOUNGEST’S B WIFI : tarifs et règle du coupon

Cette copie de développement ajoute à la maquette V48 la grille tarifaire proposée et la politique de coupon demandée.

## Tarifs à confirmer avant lancement
- 4 heures : 2 000 FC (CDF)
- 8 heures : 3 500 FC (CDF)
- 12 heures : 5 000 FC (CDF)
- 24 heures : 8 000 FC (CDF)

## Règle métier visée
- Un code par client et un seul appareil associé après la première connexion.
- Durée de validité à partir de la première activation.
- Pas de réutilisation ou partage; un remplacement d'appareil doit être une opération exceptionnelle, autorisée par le gérant, avec révocation de l'association précédente et journal d'audit.
- Une recette n'est comptabilisée qu'après confirmation de vente.

## Limites de cette version
Cette version est encore un prototype d'interface : les nombres et ventes restent fictifs. Elle ne crée pas de vrais codes, n'applique pas encore la règle côté MikroTik et ne synchronise pas les ventes réelles avec Firebase. Les rôles et permissions `admin` / `wifi_manager` restent à sécuriser côté serveur et dans Firestore avant toute production. Ne pas déployer en production.


## Paquet combiné V48 + V49

Ce ZIP regroupe dans une seule copie de développement le module YOUNGEST'S B WIFI préparé en V48 et les tarifs/règles de coupons préparés en V49. Il remplace le besoin de déposer séparément les ZIP V48 et V49.

Tarifs configurés pour la préparation : 4 h = 2 000 FC ; 8 h = 3 500 FC ; 12 h = 5 000 FC ; 24 h = 8 000 FC.

Règles prévues : coupon personnel à usage unique, association à un appareil, durée à partir de la première connexion, ventes comptées seulement après confirmation, procédure d'autorisation pour remplacement d'appareil.

**Statut : prototype de développement uniquement.** Les données d'écran peuvent être fictives ; les permissions Firebase, la sécurité réelle des coupons, l'intégration au MikroTik et la génération effective des coupons doivent être développées et testées avant production. Ne pas lancer de déploiement de production sur la seule base de cette maquette.
