# YOUNGEST’S BUSINESS V48 — YOUNGEST’S B WIFI (prototype isolé)

Cette archive est une COPIE de développement basée sur le Web Admin V47. Les écrans historiques de prêts, remboursements, clients, alertes, rapports, LUMICASH, envois et chat sont conservés. Un écran YOUNGEST’S B WIFI a été ajouté au menu.

## Important — pas encore de mise en production
- Les nombres, coupons et ventes Wi-Fi visibles sont des exemples fictifs.
- Ce prototype ne génère pas de vrais coupons MikroTik, ne communique pas avec le routeur, n'enregistre aucune vente réelle dans Firestore et ne crée pas encore de PDF comptable réel.
- Le compte administrateur V47 reste le seul compte autorisé à ouvrir l'administration. Le rôle `wifi_manager` est défini comme besoin fonctionnel/documenté, mais son authentification et son application par les règles Firestore ne sont PAS activées dans cette maquette.
- Ne déployez pas cette archive sur Firebase Hosting en production avant les étapes ci-dessous.

## Rôles à implémenter et tester
1. `admin`: toutes les fonctions YOUNGEST’S BUSINESS; configure le Wi-Fi, tarifs, profils, utilisateurs et rapports.
2. `wifi_manager`: accès uniquement au module Wi-Fi, ventes et rapports attribués. Aucun accès aux clients/prêts/remboursements/chat ni aux règles de configuration sensibles.
3. `client` (étape future facultative): portail d'achat ou de connexion aux coupons.

## Étapes avant activation
1. Choisir le matériel exact MikroTik et confirmer l'accès API disponible.
2. Créer un service backend sécurisé; les identifiants MikroTik ne doivent jamais apparaître dans `web-admin/app.js` ou dans le navigateur.
3. Ajouter une attribution de rôle fiable (custom claims gérées par Admin SDK ou collection de rôles protégée) et appliquer les contrôles dans les règles Firestore ET dans l'interface. Cacher un bouton seul n'est pas une sécurité.
4. Définir les tarifs réels et la devise, les règles de vente/annulation et la preuve de paiement.
5. Tester ventes, annulations, doublons, fuseaux horaires, permissions et exports dans un projet Firebase de test.
6. Déployer uniquement après validation, avec sauvegarde de V47.

## Collections prévues (non créées par ce prototype)
- `yb_wifi_plans` : profils et prix, écriture admin seulement.
- `yb_wifi_coupons` : code, profil, état, créé par, dates.
- `yb_wifi_sales` : référence unique, coupon, montant, devise, gérant, timestamp serveur, état de confirmation/annulation.
- `yb_wifi_audit_logs` : journal d'audit append-only, écrit côté serveur.

Une vente doit être comptée une seule fois après confirmation; la création d'un coupon et son utilisation ne valent pas automatiquement vente. Les annulations doivent conserver une trace.
