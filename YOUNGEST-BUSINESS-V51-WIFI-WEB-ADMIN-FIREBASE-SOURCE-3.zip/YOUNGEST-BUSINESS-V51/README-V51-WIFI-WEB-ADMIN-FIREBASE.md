# V51 — YOUNGEST'S B WIFI Web Admin + Firebase

## Inclus
- Web Admin Wi-Fi branch uses Firebase live listeners for `yb_wifi_config/main`, `yb_wifi_profiles`, `yb_wifi_sales`, and `yb_wifi_sessions`.
- Configure service name, currency, antenna location, MikroTik address, SSID and notes from Web Admin.
- Create/editable-by-admin tariff profiles (name, duration, price, currency) saved to Firestore.
- Record manually confirmed sales and compute daily/monthly totals from saved sale records.
- Daily/monthly printable reports (browser print dialog can save as PDF).
- Firestore rules restrict config, profiles and sales to `isAdmin()`. Session events are read-only for clients; the planned network/backend integration must write them using Firebase Admin SDK.
- The interface does not generate actual MikroTik vouchers or claim actual connectivity. First activation counts remain zero until real events are supplied by the network integration.

## Firestore collections
- `yb_wifi_config/main`
- `yb_wifi_profiles/{profileId}`
- `yb_wifi_sales/{saleId}`
- `yb_wifi_sessions/{sessionId}` (events to be written by trusted backend only)

## Important deployment note
This source archive does not deploy itself. To publish the Web Admin, deploy the `web-admin` folder to Firebase Hosting and deploy `firestore.rules` to the `youngestsbusiness` Firebase project. Verify the production deployment before relying on reports. The Android configuration page already writes `yb_wifi_config/main` according to the current project workflow; confirm field compatibility in a device test.

## Accounting semantics
- Sales count from `yb_wifi_sales`, only records not marked `CANCELLED`.
- Used coupon counts are based on distinct activation/session documents in `yb_wifi_sessions`; they are not inferred from sales.
- Amounts are summarized with their currency; CDF and USD must not be combined into one numeric total.
- Manual sales are accounting entries only and do not create a network login.
