# YOUNGEST'S BUSINESS — V44 Gestion complète des prêts et remboursements

## Changements Web
- Gestion des prêts : capital, taux enregistré, intérêt prévu, total dû, échéance, montant payé, solde restant et statut estimé.
- Remboursements : recherche, actualisation, export PDF et indicateur des paiements qui n'ont pas d'identifiant de prêt reconnu.
- Calculs : utilise les montants d'intérêt/total déjà enregistrés lorsqu'ils existent; sinon calcule l'intérêt simple selon le taux enregistré. Confirmer que cette formule correspond au contrat avant usage comptable.
- Sécurité comptable : les paiements sont rapprochés par `loanId` (ou champ équivalent reconnu) uniquement. Les paiements non liés sont signalés et ne sont pas automatiquement imputés au prêt d'un client, pour éviter de compter deux fois un paiement lorsqu'un client a plusieurs prêts.
- Demandes V43 : conserve les boutons de validation/refus et l'export PDF journalier.

## À tester avant déploiement
1. Vérifier sur Firebase que chaque document de remboursement possède un `loanId` valide.
2. Vérifier les noms de champs et les taux/durées des prêts existants.
3. Tester avec l'administrateur : validation/refus, prêt avec remboursement partiel, paiement lié à un prêt, paiement sans `loanId`, échéance dépassée, export PDF.
4. Ne pas considérer les totaux comme certifiés tant que les anciens paiements non liés n'ont pas été rapprochés.
5. Déployer Hosting et tester avec une connexion Internet active.

Projet Firebase : `youngestsbusiness`.
