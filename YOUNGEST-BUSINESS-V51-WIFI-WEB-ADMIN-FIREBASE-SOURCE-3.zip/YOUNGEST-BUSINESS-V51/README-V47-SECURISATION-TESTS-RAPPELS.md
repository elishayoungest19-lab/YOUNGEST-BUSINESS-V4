# YOUNGEST'S BUSINESS V47 — Dossiers de test sécurisés et rappels contrôlés

## Ce qui change
- Depuis Gestion des prêts, l’administrateur peut marquer explicitement un prêt `TEST` ou le réintégrer.
- Marquer TEST ne supprime aucun document : le prêt et ses remboursements restent sauvegardés.
- Les dossiers marqués TEST sont exclus du tableau de bord de production, des alertes d’échéance et des rapports Web.
- Le traitement planifié ignore les dossiers explicitement marqués TEST pour ne pas créer de nouveaux rappels pour eux.
- Les rappels destinés aux clients restent soumis à la validation manuelle de l’administration et s’ouvrent dans WhatsApp/SMS; aucun message WhatsApp n’est envoyé automatiquement.

## Procédure recommandée
1. Sauvegarder les données avant toute opération.
2. Déployer le Web V47.
3. Dans Gestion des prêts, marquer TEST uniquement les dossiers fictifs confirmés.
4. Ne pas marquer les dossiers incertains : ils restent dans les données de production jusqu’à vérification.
5. Vérifier alertes, rapports et notifications après le traitement quotidien.
6. Ne supprimer aucun dossier automatiquement. Toute suppression éventuelle doit être une opération séparée, après sauvegarde et vérification des remboursements liés.

## Données et compatibilité
- Firebase project : `youngestsbusiness`.
- Collections : `yb_loans`, `yb_payments`, `yb_admin_due_notifications`, `yb_loan_contact_logs`.
- Les données existantes ne sont pas modifiées au déploiement. Seuls les prêts explicitement marqués reçoivent un champ de classification.
- L’application Android V42 continue à partager les données Firebase. Les dossiers TEST peuvent rester visibles dans certaines vues Android jusqu’à adaptation de l’interface Android, mais ils ne sont pas supprimés.

## Vérifications
- `node --check web-admin/app.js`
- `node --check .github/scripts/process-due-reminders.js`
- Validation de l’archive ZIP.

## Important
Cette archive est une source préparée, pas un déploiement. Le site de production ne changera qu’après ajout de l’archive et du workflow au dépôt GitHub puis exécution réussie de l’action.
