# YOUNGEST'S BUSINESS V46 — Rappels d’échéances sans Cloud Functions

## Fonctionnement
- Un workflow GitHub Actions planifié traite les échéances quotidiennement (cron 06:00 UTC, soit 07:00 à Kinshasa selon le fuseau actuel).
- Le traitement se lance même lorsque le site Web est fermé. Il lit `yb_loans` et `yb_payments`, calcule le solde restant et crée des alertes dans `yb_admin_due_notifications`.
- Prêts soldés et dossiers sans date reconnue sont exclus. Une clé déterministe empêche les doublons pour le même prêt/jour/type d’alerte.
- Si `yb_notification_tokens/{ADMIN_UID}` contient un jeton FCM valide, le traitement tente une notification push à l’administration. Sinon l’alerte reste enregistrée dans Firestore et sera visible dans le tableau de bord lors de sa prochaine ouverture.
- L’administration envoie ensuite le rappel au client manuellement via WhatsApp/SMS/téléphone depuis le Centre des alertes. L’ouverture de WhatsApp ne signifie pas que le message a été envoyé.

## Sans facturation Firebase ?
Cette variante ne déploie pas la fonction planifiée Cloud Functions. Elle utilise les minutes GitHub Actions disponibles pour le dépôt et l’accès Admin SDK via le secret GitHub `FIREBASE_SERVICE_ACCOUNT_JSON`. GitHub Actions peut avoir ses propres limites de minutes et les permissions Firestore du compte de service doivent être suffisantes. Les notifications push dépendent d’un jeton FCM valide et de la configuration déjà en place.

## Déploiement
1. Garder le ZIP V42 Android à la racine du dépôt si l’on veut aussi produire l’APK.
2. Ajouter le ZIP V46 à la racine du dépôt.
3. Remplacer `.github/workflows/build-apk.yml` par le workflow contenu dans ce ZIP.
4. Vérifier que le secret `FIREBASE_SERVICE_ACCOUNT_JSON` existe dans GitHub Actions.
5. Faire un commit sur `main`. Le déploiement publie Hosting et les règles Firestore; le traitement quotidien s’exécute par le job GitHub programmé.

## Limites
- Ce système ne transmet pas automatiquement de WhatsApp au client. Il alerte l’administration qui déclenche le contact.
- L’exécution planifiée GitHub peut être retardée et dépend des limites et de la disponibilité de GitHub Actions.
- Vérifier les dates, les identifiants des paiements liés et les autorisations avant usage en production.
