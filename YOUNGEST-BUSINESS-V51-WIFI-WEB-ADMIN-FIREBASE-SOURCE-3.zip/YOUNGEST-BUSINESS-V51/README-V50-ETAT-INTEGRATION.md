# V50 — intégration de développement Android V42 + Web Admin V47 + aperçu YOUNGEST’S B WIFI

Cette archive est un paquet de travail non-production assemblé à partir des sources fournies.
- Base Android : sources V42.
- Base Web/Admin, configuration Firebase et règles Firestore : V47.
- Écran Wi-Fi : interface prototype V49 reprise pour revue.

IMPORTANT : l'écran Wi-Fi reste une maquette. Les ventes/coupons sont fictifs; cette archive ne réalise pas la création de vrais coupons, ne pilote pas un MikroTik et n'ajoute pas les permissions Firebase de production pour le rôle wifi_manager. Ne pas déployer ni distribuer comme version finale.

Avant production, il faut implémenter et tester le backend sécurisé (Cloud Functions/Admin SDK), règles Firestore, intégration RouterOS/MikroTik avec secrets côté serveur, flux réel de ventes, attribution unique par appareil, activation à la première connexion, audit des remplacements, exports PDF et test de régression Android/Web.
