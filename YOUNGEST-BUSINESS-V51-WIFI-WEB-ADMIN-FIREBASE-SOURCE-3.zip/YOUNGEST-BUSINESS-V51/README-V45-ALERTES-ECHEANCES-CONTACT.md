# YOUNGEST’S BUSINESS V45 — Alertes d’échéances et contact direct

## Nouveautés
- Menu « Alertes des échéances » et accès rapide depuis le tableau de bord.
- Classement à partir de la date d’échéance réellement enregistrée : en retard, aujourd’hui, demain, dans 2–3 jours, à venir, prêt soldé, ou date manquante à vérifier.
- Solde restant calculé depuis les paiements directement liés au prêt. Les paiements non liés ne sont pas imputés arbitrairement.
- Boutons WhatsApp (message prérempli), appel téléphonique et SMS. Le gestionnaire vérifie le message puis déclenche l’envoi dans l’application correspondante.
- Rapport PDF des alertes.
- Journal Firestore `yb_loan_contact_logs` pour tracer l’ouverture du canal et le message préparé. Cette trace ne signifie pas que le message a été envoyé ou lu.

## Limites importantes
- Si un prêt contient uniquement une date finale d’échéance, le système ne fabrique pas des versements intermédiaires.
- Les numéros doivent inclure l’indicatif international pour WhatsApp (ex. +243…). Les données existantes ne sont pas modifiées par cette fonctionnalité.
- Les alertes sont calculées lorsque l’administration ouvre/actualise la page. Il ne s’agit pas encore de notifications push automatiques lorsque le site est fermé.
- L’historique de contact nécessite le déploiement des règles Firestore incluses dans ce paquet.

## Déploiement
Utiliser le workflow `build-apk-V45-web-deploy.yml` fourni avec ce paquet et le secret GitHub `FIREBASE_SERVICE_ACCOUNT_JSON` déjà requis par le workflow précédent. Le job conserve la construction APK Android V42 et déploie l’interface Web V45 ainsi que les règles Firestore.
