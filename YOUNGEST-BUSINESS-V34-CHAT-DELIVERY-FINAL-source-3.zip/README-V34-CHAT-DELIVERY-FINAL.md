# YOUNGEST’S BUSINESS V34 — CHAT DELIVERY FINAL

## Objectif
Garantir que les messages du Chat client arrivent dans la boîte de réception administrative.

## Corrections
- Le Chat client utilise la session Firebase anonyme déjà utilisée par l’espace client au lieu de dépendre de Phone Authentication/SMS.
- Le numéro international saisi par le client est conservé avec la conversation.
- Le brouillon du message et le numéro sont persistants via SharedPreferences.
- La création de la conversation et le premier message sont écrits dans une transaction Firestore.
- Les messages d’une conversation existante utilisent une transaction Firestore.
- La boîte Admin lit les conversations sans dépendre d’un `orderBy` Firestore et les trie localement par `updatedAt`.
- Les nouvelles conversations avec `adminUnread=true` sont clairement signalées à l’administration.
- Le texte des coordonnées utilise de vrais retours à la ligne.
- Les règles Firestore autorisent le Chat pour tout utilisateur Firebase authentifié possédant sa propre conversation; l’Admin reste contrôlé par UID/email.
- Le flux Phone Auth reste présent uniquement pour compatibilité source mais n’est plus appelé par le parcours Chat V34.

Version Android : versionCode 34, versionName 1.27.0.
