package com.aistudio.youngestbiz.mbkz;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * YOUNGEST'S BUSINESS - prototype V4.
 * Local persistent prototype: clients, loans and payments survive app restart.
 * This is not yet a production financial backend; server authentication/payment
 * integration must be added before real-money deployment.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "youngest_business_data";
    private static final String KEY_DATA = "data";

    final int NAVY = Color.rgb(6,43,99), GREEN = Color.rgb(47,143,20), GOLD = Color.rgb(217,165,27);
    final int RED = Color.rgb(198,40,40), PURPLE = Color.rgb(112,55,180), BLUE = Color.rgb(25,100,210);
    final int LIGHT = Color.rgb(245,247,250);

    LinearLayout root, body;
    final ArrayList<Client> clients = new ArrayList<>();
    final ArrayList<Loan> loans = new ArrayList<>();
    final ArrayList<Payment> payments = new ArrayList<>();
    SharedPreferences prefs;

    static class Client {
        String name, phone;
        Client(String n, String p) { name=n; phone=p; }
    }

    static class Loan {
        Client c; double principal, rate; int days; long date;
        Loan(Client c, double p, double r, int d) {
            this.c=c; principal=p; rate=r; days=d; date=System.currentTimeMillis();
        }
        double interest(){ return principal * rate / 100.0; }
        double total(){ return principal + interest(); }
        long dueDate(){ return date + days * 24L * 60L * 60L * 1000L; }
        double paid(ArrayList<Payment> ps){ double x=0; for(Payment p:ps) if(p.loan==this) x+=p.amount; return x; }
        double balance(ArrayList<Payment> ps){ return Math.max(0, total()-paid(ps)); }
    }

    static class Payment {
        Loan loan; double amount; long date;
        Payment(Loan l, double a){ loan=l; amount=a; date=System.currentTimeMillis(); }
    }

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(14),dp(10),dp(14),dp(10)); return t;
    }

    GradientDrawable bg(int c,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    Button btn(String s,int c){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(bg(c,14)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        loadData();
        showSplash();
    }

    private void seedIfEmpty(){
        if(!clients.isEmpty()) return;
        clients.add(new Client("KIEUERECI KALAY",""));
        clients.add(new Client("MUKOSA CHRISTIAN",""));
        clients.add(new Client("NZAGIRE VALENTINE",""));
        loans.add(new Loan(clients.get(0),350000,30,30));
        loans.add(new Loan(clients.get(1),350000,20,14));
        loans.add(new Loan(clients.get(2),100000,10,7));
        saveData();
    }

    private void saveData(){
        try {
            JSONObject all=new JSONObject();
            JSONArray cs=new JSONArray();
            for(Client c:clients){ JSONObject o=new JSONObject(); o.put("name",c.name); o.put("phone",c.phone); cs.put(o); }
            JSONArray ls=new JSONArray();
            for(Loan l:loans){ JSONObject o=new JSONObject(); o.put("client",clients.indexOf(l.c)); o.put("principal",l.principal); o.put("rate",l.rate); o.put("days",l.days); o.put("date",l.date); ls.put(o); }
            JSONArray ps=new JSONArray();
            for(Payment p:payments){ JSONObject o=new JSONObject(); o.put("loan",loans.indexOf(p.loan)); o.put("amount",p.amount); o.put("date",p.date); ps.put(o); }
            all.put("clients",cs); all.put("loans",ls); all.put("payments",ps);
            prefs.edit().putString(KEY_DATA,all.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void loadData(){
        String raw=prefs.getString(KEY_DATA,null);
        if(raw==null){ seedIfEmpty(); return; }
        try {
            JSONObject all=new JSONObject(raw);
            JSONArray cs=all.optJSONArray("clients");
            JSONArray ls=all.optJSONArray("loans");
            JSONArray ps=all.optJSONArray("payments");
            if(cs!=null) for(int i=0;i<cs.length();i++){ JSONObject o=cs.getJSONObject(i); clients.add(new Client(o.optString("name"),o.optString("phone"))); }
            if(ls!=null) for(int i=0;i<ls.length();i++){ JSONObject o=ls.getJSONObject(i); int ci=o.optInt("client",-1); if(ci>=0&&ci<clients.size()){ Loan l=new Loan(clients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days")); l.date=o.optLong("date",l.date); loans.add(l); } }
            if(ps!=null) for(int i=0;i<ps.length();i++){ JSONObject o=ps.getJSONObject(i); int li=o.optInt("loan",-1); if(li>=0&&li<loans.size()){ Payment p=new Payment(loans.get(li),o.optDouble("amount")); p.date=o.optLong("date",p.date); payments.add(p); } }
            if(clients.isEmpty()) seedIfEmpty();
        } catch(Exception e){ clients.clear(); loans.clear(); payments.clear(); seedIfEmpty(); }
    }

    void base(String name,int color){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),0,dp(8),0); bar.setBackgroundColor(color);
        TextView back=tv("‹",30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->home());
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(60)));
        TextView title=tv(name,19); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(60),1)); root.addView(bar);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(18));
        ScrollView sv=new ScrollView(this); sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showSplash(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this); im.setImageResource(R.drawable.presentation_youngests_business); im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        Button b=btn("ENTRER DANS L'APPLICATION",NAVY); b.setOnClickListener(v->home()); root.addView(b,new LinearLayout.LayoutParams(-1,dp(58))); setContentView(root);
    }

    void home(){
        base("YOUNGEST'S BUSINESS",NAVY);
        body.addView(tv("Bienvenue 👋\nGestion des prêts et services financiers",20));
        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","🔄 TRANSFERTS","💵 REMBOURSEMENTS","👤 CLIENTS","⚙ ADMINISTRATION"};
        int[] cs={RED,GREEN,BLUE,PURPLE,GOLD,NAVY};
        for(int i=0;i<6;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{ if(k==0)loanForm(); else if(k==1)services(); else if(k==2)transfers(); else if(k==3)repay(); else if(k==4)clientsPage(); else adminDash(); });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=dp(82); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g); Button dash=btn("📊 TABLEAU DE BORD",NAVY); dash.setOnClickListener(v->dashboard()); body.addView(dash,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void dashboard(){
        base("TABLEAU DE BORD",NAVY);
        double capital=0,intt=0,paid=0; int late=0,active=0;
        for(Loan l:loans){ capital+=l.principal; intt+=l.interest(); paid+=l.paid(payments); if(l.balance(payments)>0){active++; if(System.currentTimeMillis()>l.dueDate())late++;} }
        body.addView(tv("SITUATION RÉELLE DE L'ACTIVITÉ",19));
        body.addView(tv("👥 Clients : "+clients.size()+"\n📋 Prêts : "+loans.size()+"\n🟢 Prêts actifs : "+active+"\n🔴 Échéances dépassées : "+late+"\n💰 Capital prêté : "+fmt(capital)+" FBu\n📈 Intérêts prévus : "+fmt(intt)+" FBu\n💵 Total à récupérer : "+fmt(capital+intt)+" FBu\n🔄 Total encaissé : "+fmt(paid)+" FBu\n⏳ Solde à récupérer : "+fmt(capital+intt-paid)+" FBu",17));
        Button journal=btn("📋 JOURNAL DES PRÊTS",NAVY); journal.setOnClickListener(v->loanJournal()); body.addView(journal);
    }

    void loanJournal(){
        base("JOURNAL DES PRÊTS",NAVY); body.addView(tv("Historique des prêts",19));
        if(loans.isEmpty()){body.addView(tv("Aucun prêt enregistré.",16)); return;}
        for(Loan l:loans){
            double paid=l.paid(payments), bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(l.c.name+"\n"+fmt(l.principal)+" FBu • Total "+fmt(l.total())+" FBu\n"+status+" • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(88)));
        }
    }

    void loanDetails(Loan l){
        base("DÉTAIL DU PRÊT",RED);
        double paid=l.paid(payments), bal=l.balance(payments);
        body.addView(tv("CLIENT\n"+l.c.name+(l.c.phone.isEmpty()?"":"\n"+l.c.phone),17));
        body.addView(tv("MONTANT : "+fmt(l.principal)+" FBu\nTAUX : "+fmt(l.rate)+" %\nDURÉE : "+l.days+" jours\nINTÉRÊT : "+fmt(l.interest())+" FBu\nTOTAL : "+fmt(l.total())+" FBu\nDÉJÀ PAYÉ : "+fmt(paid)+" FBu\nSOLDE : "+fmt(bal)+" FBu\nÉCHÉANCE : "+date(l.dueDate()),17));
        Button p=btn("💵 ENREGISTRER UN REMBOURSEMENT",PURPLE); p.setOnClickListener(v->paymentForm(l)); body.addView(p);
    }

    void loanForm(){
        base("NOUVEAU PRÊT",RED); body.addView(tv("Enregistrer un prêt",19));
        Spinner sp=new Spinner(this); ArrayList<String> ns=new ArrayList<>(); for(Client c:clients)ns.add(c.name);
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ns)); body.addView(sp);
        EditText amt=input("Montant prêté (FBu)",InputType.TYPE_CLASS_NUMBER), rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL), days=input("Durée en jours",InputType.TYPE_CLASS_NUMBER);
        body.addView(amt); body.addView(rate); body.addView(days); TextView calc=tv("Intérêt : —\nTotal à récupérer : —",16); body.addView(calc);
        TextWatcher w=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){calculate(amt,rate,calc);} public void afterTextChanged(Editable e){}};
        amt.addTextChangedListener(w); rate.addTextChangedListener(w);
        Button save=btn("ENREGISTRER LE PRÊT",RED); save.setOnClickListener(v->{
            try{ if(clients.isEmpty())throw new Exception(); double a=Double.parseDouble(amt.getText().toString()),r=Double.parseDouble(rate.getText().toString()); int d=Integer.parseInt(days.getText().toString());
                if(a<=0||r<0||d<=0)throw new Exception(); loans.add(new Loan(clients.get(sp.getSelectedItemPosition()),a,r,d)); saveData(); Toast.makeText(this,"Prêt enregistré avec succès",Toast.LENGTH_LONG).show(); loanJournal();
            }catch(Exception e){Toast.makeText(this,"Veuillez remplir correctement les champs",Toast.LENGTH_SHORT).show();}
        }); body.addView(save);
    }

    EditText input(String hint,int type){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); return e; }
    void calculate(EditText a,EditText r,TextView out){ try{double x=Double.parseDouble(a.getText().toString()),y=Double.parseDouble(r.getText().toString()); out.setText("Intérêt : "+fmt(x*y/100)+" FBu\nTotal à récupérer : "+fmt(x+x*y/100)+" FBu");}catch(Exception ignored){out.setText("Intérêt : —\nTotal à récupérer : —");} }

    void clientsPage(){
        base("CLIENTS",NAVY); body.addView(tv("CLIENTS ENREGISTRÉS : "+clients.size(),19));
        for(Client c:clients){ Button b=btn("👤 "+c.name+(c.phone.isEmpty()?"":" — "+c.phone),NAVY); b.setOnClickListener(v->clientDetails(c)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(56))); }
        Button add=btn("＋ AJOUTER UN CLIENT",NAVY); add.setOnClickListener(v->addClient()); body.addView(add);
    }

    void clientDetails(Client c){
        base("FICHE CLIENT",NAVY); body.addView(tv("👤 "+c.name+"\n📱 "+(c.phone.isEmpty()?"Non renseigné":c.phone),19));
        int n=0; double total=0,paid=0; for(Loan l:loans)if(l.c==c){n++;total+=l.total();paid+=l.paid(payments);}
        body.addView(tv("Prêts : "+n+"\nTotal à récupérer : "+fmt(total)+" FBu\nTotal payé : "+fmt(paid)+" FBu\nSolde : "+fmt(total-paid)+" FBu",17));
    }

    void addClient(){
        final EditText n=input("Nom et post-nom",InputType.TYPE_CLASS_TEXT), p=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("Nouveau client").setView(box).setPositiveButton("ENREGISTRER",(d,w)->{if(n.getText().length()>0){clients.add(new Client(n.getText().toString().trim(),p.getText().toString().trim()));saveData();clientsPage();}}).setNegativeButton("ANNULER",null).show();
    }

    void repay(){
        base("REMBOURSEMENTS",PURPLE); body.addView(tv("Choisissez un prêt puis enregistrez le paiement",18));
        for(Loan l:loans){ double bal=l.balance(payments); if(bal>0){ Button b=btn(l.c.name+" — Solde "+fmt(bal)+" FBu",PURPLE); b.setOnClickListener(v->paymentForm(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(62))); } }
    }

    void paymentForm(Loan l){
        EditText a=input("Montant du paiement (FBu)",InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("Paiement — "+l.c.name).setView(a).setPositiveButton("ENCAISSER",(d,w)->{
            try{double x=Double.parseDouble(a.getText().toString()); if(x<=0||x>l.balance(payments))throw new Exception(); payments.add(new Payment(l,x)); saveData(); Toast.makeText(this,"Remboursement enregistré",Toast.LENGTH_SHORT).show(); loanDetails(l);}
            catch(Exception e){Toast.makeText(this,"Montant invalide",Toast.LENGTH_SHORT).show();}
        }).setNegativeButton("ANNULER",null).show();
    }

    void adminDash(){ dashboard(); }

    void services(){
        base("SERVICES FINANCIERS",GREEN); body.addView(tv("MOBILE MONEY\nM-Pesa • Airtel Money • Orange Money • Afrimoney",17));
        for(String s:new String[]{"Dépôt d'argent","Retrait d'argent","Transfert d'argent"}){Button b=btn(s+" ›",GREEN); b.setOnClickListener(v->Toast.makeText(this,"Cette fonction sera connectée au service partenaire dans une prochaine version.",Toast.LENGTH_LONG).show()); body.addView(b);}
    }

    void transfers(){
        base("TRANSFERTS",BLUE); body.addView(tv("Transfert d'argent\nChoisissez le service et le bénéficiaire.",18));
        Button b=btn("NOUVEAU TRANSFERT",BLUE); b.setOnClickListener(v->Toast.makeText(this,"Module de transfert en préparation.",Toast.LENGTH_LONG).show()); body.addView(b);
    }

    String date(long time){return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date(time));}
    String fmt(double x){return String.format(Locale.US,"%,.0f",x).replace(',',' ');}
}
