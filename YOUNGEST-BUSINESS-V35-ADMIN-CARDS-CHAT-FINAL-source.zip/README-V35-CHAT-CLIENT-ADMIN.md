# YOUNGEST’S BUSINESS V35 — CHAT CLIENT → ADMINISTRATION

## Objectif
V35 conserve l’interface d’administration en cartes validée dans V34 et finalise le parcours de chat réel entre un client et l’administration.

## Parcours client
1. Le client ouvre **CONTACTEZ-NOUS**.
2. Il écrit son message dans la zone de chat.
3. Le message est conservé si l’envoi doit être repris.
4. Firebase Anonymous Auth fournit l’identité technique du client.
5. Le numéro international est associé à la conversation.
6. Firestore crée la conversation `yb_chat_conversations` avant le premier message.
7. Le message est enregistré dans `messages`.

## Parcours administration
1. L’administrateur ouvre **CONTACT_NOUS — RÉPONDRE AU CHAT** depuis l’interface en cartes existante.
2. Les conversations sont chargées en temps réel.
3. Les conversations non lues sont signalées.
4. L’administrateur ouvre une conversation et répond.
5. La réponse est enregistrée dans Firestore et le client reçoit une notification FCM lorsque son jeton est disponible.

## Sécurité
- Le client ne lit que sa propre conversation.
- L’administration peut consulter et répondre aux conversations.
- Les règles ne dépendent pas de `request.auth.token.phone_number` pour le client anonyme.

Version Android : `versionCode 35`, `versionName 1.28.0`.
