# YOUNGEST’S BUSINESS V14

Version pilote orientée validation des demandes de prêt client.

- Espace Bureau : réception, consultation, approbation/refus et création du prêt.
- Espace Client : demande de prêt et suivi du statut.
- Firebase/Firestore : synchronisation des demandes.
- V14 ajoute un indicateur des demandes en attente dans l’espace Bureau.

IMPORTANT : l’authentification anonyme et les règles Firestore doivent être renforcées avant toute ouverture à des clients réels.
