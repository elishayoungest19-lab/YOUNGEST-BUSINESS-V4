# YOUNGEST'S BUSINESS V13

V13 ajoute un espace client pilote au projet V12, sans supprimer les fonctions de bureau existantes.

## Bureau
- Gestion des clients, prêts, paiements et remboursements
- Tableau de bord
- Synchronisation Firebase/Firestore
- Réception des demandes de prêt clients
- Approbation/refus d'une demande
- En cas d'approbation, création d'un prêt avec saisie du taux d'intérêt

## Client
- Espace client séparé du menu bureau
- Envoi d'une demande de prêt
- Nom, téléphone, montant, durée et motif
- Consultation de ses demandes et de leur statut

## Important
L'authentification client de cette V13 est encore en phase pilote (authentification anonyme). Les règles Firestore actuelles de V13 permettent l'accès aux utilisateurs authentifiés pour faciliter les tests entre l'espace client et le bureau.

Avant toute ouverture publique à de vrais clients, il faut mettre en place une authentification client robuste et des règles Firestore basées sur les rôles/identités afin qu'un client ne puisse jamais consulter les données d'un autre client.
