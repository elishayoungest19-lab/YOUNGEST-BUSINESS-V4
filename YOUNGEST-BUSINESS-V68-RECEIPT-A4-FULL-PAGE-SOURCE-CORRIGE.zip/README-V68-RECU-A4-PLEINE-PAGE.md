# V68 — Reçu A4 pleine page + logo Airtel Money ajusté

- Reprend la base source V67.
- Définit explicitement la page d’impression en A4 portrait sans marge navigateur CSS.
- Dimensionne le reçu à 204 × 291 mm avec une marge de sécurité de 3 mm autour.
- Conserve les champs, logos opérateurs, QR code, contacts et structure du reçu.
- Agrandit le QR code à 150 px.
- Remplace le logo Airtel Money horizontal simplifié par une version vectorielle verticale rouge, avec symbole au-dessus de « airtel » et « money ».
- Ajoute une classe d’affichage dédiée pour dimensionner correctement le logo Airtel Money sur le reçu.
- Le SVG est une vectorisation de référence, pas un fichier maître certifié fourni par Airtel Money RDC. Pour une conformité officielle stricte, utiliser le fichier source officiel transmis par Airtel.
- Version Android conservée à versionCode 68 et versionName 1.68.0-receipt-a4-full-page.
- Déploiement Web Admin : Firebase Hosting uniquement via le workflow V68.

À vérifier après déploiement dans l’aperçu PDF A4 : le navigateur et l’imprimante peuvent encore appliquer leurs propres marges ou leur échelle.
