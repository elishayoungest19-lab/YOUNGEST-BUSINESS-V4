// V46 Spark-compatible daily processor. Runs on GitHub Actions, not Cloud Functions.
const admin = require("../../functions/node_modules/firebase-admin");

if (!admin.apps.length) admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  projectId: process.env.FIREBASE_PROJECT_ID || "youngestsbusiness"
});
const db = admin.firestore();
const TZ = "Africa/Kinshasa";
const ADMIN_UID = "StxrZBDeUodj7YVPmXRA2AbWcUF2";
const amount = v => { const n = Number(v ?? 0); return Number.isFinite(n) ? n : 0; };
function millis(v) {
  if (!v) return 0;
  if (typeof v.toDate === "function") return v.toDate().getTime();
  if (typeof v === "number") return v < 1e12 ? v * 1000 : v;
  if (typeof v === "object" && Number.isFinite(v.seconds)) return v.seconds * 1000;
  const n = Date.parse(v); return Number.isFinite(n) ? n : 0;
}
function dayKey(ms) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(ms));
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}
function dueDate(l) { return l.dueDate || l.echeance || l.dueAt || (l.date && l.days ? millis(l.date) + amount(l.days) * 86400000 : null); }
async function main() {
  const [loanSnap, paymentSnap] = await Promise.all([db.collection("yb_loans").get(), db.collection("yb_payments").get()]);
  const loans = loanSnap.docs.map(d => ({ id: d.id, ...d.data() }));
  const payments = paymentSnap.docs.map(d => d.data());
  const today = dayKey(Date.now());
  const todayNoon = Date.parse(`${today}T12:00:00Z`);
  const alerts = db.collection("yb_admin_due_notifications");
  const tokenSnap = await db.collection("yb_notification_tokens").doc(ADMIN_UID).get();
  const token = tokenSnap.exists ? String((tokenSnap.data() || {}).token || "") : "";
  let created = 0, pushSent = 0;
  for (const loan of loans) {
    const principal = amount(loan.principal ?? loan.amount ?? loan.montant ?? loan.approvedAmount);
    const rate = amount(loan.rate ?? loan.interestRate ?? loan.taux);
    const savedInterest = loan.interestAmount ?? loan.interest ?? loan.interestGenerated;
    const interest = savedInterest == null ? principal * rate / 100 : amount(savedInterest);
    const savedTotal = loan.totalDue ?? loan.totalToRepay ?? loan.totalRepayment;
    const totalDue = savedTotal == null ? principal + interest : amount(savedTotal);
    const paid = payments.filter(p => (p.loanId && p.loanId === loan.id) || (p.loan && typeof p.loan === "object" && p.loan.id === loan.id) || (p.loanRef && p.loanRef === loan.id))
      .reduce((s,p) => s + amount(p.amount ?? p.montant ?? p.paidAmount ?? p.amountPaid), 0);
    const balance = Math.max(0, totalDue - paid);
    if (balance <= 0) continue;
    const dueMs = millis(dueDate(loan)); if (!dueMs) continue;
    const dueKey = dayKey(dueMs);
    const days = Math.round((Date.parse(`${dueKey}T12:00:00Z`) - todayNoon) / 86400000);
    if (days > 3) continue;
    const alertType = days < 0 ? "overdue" : days === 0 ? "today" : days === 1 ? "tomorrow" : "upcoming";
    const alertLabel = days < 0 ? `EN RETARD (${Math.abs(days)} j)` : days === 0 ? "ÉCHÉANCE AUJOURD'HUI" : days === 1 ? "ÉCHÉANCE DEMAIN" : `ÉCHÉANCE DANS ${days} J`;
    const id = `${String(loan.id).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 90)}_${today}_${alertType}`;
    const ref = alerts.doc(id); let wasCreated = false;
    await db.runTransaction(async tx => {
      const existing = await tx.get(ref); if (existing.exists) return;
      tx.create(ref, { loanId: String(loan.id), clientId: String(loan.clientId || ""), clientName: String(loan.clientName || loan.name || loan.client || loan.clientId || "Client sans nom"), phone: String(loan.clientPhone || loan.phone || loan.telephone || ""), dueDate: dueKey, dueDateLabel: dueKey, alertType, alertLabel, days, balance, status: "NOUVELLE", createdAt: admin.firestore.FieldValue.serverTimestamp(), createdAtMs: Date.now(), source: "V46_GITHUB_SCHEDULE" });
      wasCreated = true;
    });
    if (!wasCreated) continue;
    created++;
    if (token) {
      try {
        await admin.messaging().send({ token, notification: { title: "YOUNGEST'S BUSINESS — Échéance", body: `${alertLabel} : ${loan.clientName || loan.name || loan.clientId || "Client"}. Solde : ${Math.round(balance).toLocaleString("fr-FR")} FBU.` }, data: { type: "loan_due", loanId: String(loan.id), notificationId: id, alertType }, android: { priority: "high" } });
        pushSent++;
      } catch (e) { console.warn("Push administration non envoyé; alerte conservée dans Firestore:", e.code || e.message); }
    }
  }
  console.log(`V46 ${today}: ${created} nouvelle(s) alerte(s); ${pushSent} push tenté(s) avec succès.`);
}
main().then(() => process.exit(0)).catch(e => { console.error("V46 daily reminder processor failed:", e); process.exit(1); });
