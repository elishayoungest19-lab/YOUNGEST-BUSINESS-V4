const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

const BASE_URL = "https://app-api.wonyasoft.com";

// Un couple Token + RefPartenaire est prévu par réseau/caisse.
// Si plusieurs réseaux utilisent la même caisse, on peut renseigner le même secret.
const SECRETS = {
  "M-Pesa": {
    token: defineSecret("WONYAPAY_TOKEN_MPESA"),
    ref: defineSecret("WONYAPAY_REF_MPESA")
  },
  "Airtel Money": {
    token: defineSecret("WONYAPAY_TOKEN_AIRTEL"),
    ref: defineSecret("WONYAPAY_REF_AIRTEL")
  },
  "Orange Money": {
    token: defineSecret("WONYAPAY_TOKEN_ORANGE"),
    ref: defineSecret("WONYAPAY_REF_ORANGE")
  },
  "Afrimoney": {
    token: defineSecret("WONYAPAY_TOKEN_AFRIMONEY"),
    ref: defineSecret("WONYAPAY_REF_AFRIMONEY")
  }
};

const allowedCurrencies = new Set(["CDF", "USD"]);
const allowedNetworks = new Set(Object.keys(SECRETS));

function normalizePhone(value) {
  let n = String(value || "").replace(/\D/g, "");
  if (n.startsWith("243") && n.length === 12) n = "0" + n.slice(3);
  return n;
}

function makeRef() {
  const now = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `YB${now}${random}`.slice(0, 20);
}

function jsonData(response) {
  return response.json().catch(() => ({}));
}

function normalizeApiResult(body) {
  const data = body && body.data && typeof body.data === "object" ? body.data : {};
  return {
    success: body && body.success === true,
    message: body && body.message ? String(body.message) : "",
    data: {
      refTransa: data.refTransa || "",
      transactionId: data.transactionId || "",
      montant: data.montant,
      devise: data.devise,
      frais: data.frais,
      commission: data.commission,
      network: data.network || "",
      action: data.action || "B2C",
      status: data.status || "pending"
    }
  };
}

exports.createWonyaPayTransfer = onCall(
  { secrets: Object.values(SECRETS).flatMap(x => [x.token, x.ref]) },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");

    const input = request.data || {};
    const network = String(input.network || "").trim();
    const currency = String(input.currency || "").trim().toUpperCase();
    const mobileMoney = normalizePhone(input.mobileMoney);
    const amount = Number(input.amount);
    const reason = String(input.reason || "Transfert YOUNGEST'S BUSINESS").trim().slice(0, 120);

    if (!allowedNetworks.has(network)) throw new HttpsError("invalid-argument", "Réseau Mobile Money non supporté.");
    if (!allowedCurrencies.has(currency)) throw new HttpsError("invalid-argument", "Devise invalide. Utilisez CDF ou USD.");
    if (!/^\d{10}$/.test(mobileMoney)) throw new HttpsError("invalid-argument", "Le numéro Mobile Money doit contenir 10 chiffres.");
    if (!Number.isFinite(amount) || amount <= 0) throw new HttpsError("invalid-argument", "Montant invalide.");

    const cfg = SECRETS[network];
    const token = cfg.token.value();
    const refPartenaire = cfg.ref.value();
    if (!token || !refPartenaire) {
      throw new HttpsError("failed-precondition", `Configuration WonyaPay absente pour ${network}.`);
    }

    const refTransa = makeRef();
    const payload = {
      RefPartenaire: refPartenaire,
      RefTransa: refTransa,
      Montant: amount,
      Devise: currency,
      Action: "B2C",
      MobileMoney: mobileMoney,
      Motif: reason
    };

    const response = await fetch(`${BASE_URL}/payment`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    const body = await jsonData(response);
    const result = normalizeApiResult(body);

    await db.collection("yb_transfers").doc(refTransa).set({
      refTransa,
      uid: request.auth.uid,
      network,
      mobileMoney,
      amount,
      currency,
      action: "B2C",
      reason,
      success: result.success,
      httpStatus: response.status,
      providerTransactionId: result.data.transactionId,
      providerStatus: result.data.status,
      fee: result.data.frais ?? null,
      commission: result.data.commission ?? null,
      message: result.message,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    if (!response.ok || !result.success) {
      return {
        success: false,
        message: result.message || `WonyaPay a répondu avec le code ${response.status}.`,
        data: { ...result.data, refTransa }
      };
    }

    return {
      success: true,
      message: result.message || "Transaction B2C initiée avec succès",
      data: { ...result.data, refTransa }
    };
  }
);

exports.getWonyaPayStatus = onCall(
  { secrets: Object.values(SECRETS).flatMap(x => [x.token, x.ref]) },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");
    const refTransa = String((request.data || {}).refTransa || "").trim();
    if (!refTransa) throw new HttpsError("invalid-argument", "Référence de transaction manquante.");

    const snap = await db.collection("yb_transfers").doc(refTransa).get();
    if (!snap.exists) throw new HttpsError("not-found", "Transaction introuvable.");
    const saved = snap.data();
    const isAdmin = request.auth.uid === "StxrZBDeUodj7YVPmXRA2AbWcUF2";
    if (saved.uid !== request.auth.uid && !isAdmin) throw new HttpsError("permission-denied", "Accès refusé.");

    const cfg = SECRETS[saved.network];
    if (!cfg) throw new HttpsError("failed-precondition", "Réseau de la transaction inconnu.");
    const token = cfg.token.value();
    if (!token) throw new HttpsError("failed-precondition", "Token WonyaPay absent.");

    const response = await fetch(`${BASE_URL}/transaction-status/status/${encodeURIComponent(refTransa)}`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const body = await jsonData(response);
    const result = normalizeApiResult(body);

    await snap.ref.update({
      providerStatus: result.data.status,
      providerTransactionId: result.data.transactionId || saved.providerTransactionId || "",
      fee: result.data.frais ?? saved.fee ?? null,
      commission: result.data.commission ?? saved.commission ?? null,
      message: result.message || saved.message || "",
      httpStatus: response.status,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    return { success: response.ok && result.success, message: result.message, data: result.data };
  }
);




// V41 : enregistrement LUMICASH après validation serveur du PIN de l'agent.
// Les PIN sont stockés dans Firebase Secret Manager, jamais dans le JavaScript public.
const AGENT1_PIN = defineSecret("AGENT1_PIN");
const AGENT2_PIN = defineSecret("AGENT2_PIN");
exports.createLumicashJournalEntry = onCall(
  { secrets: [AGENT1_PIN, AGENT2_PIN] },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");
    const email = String(request.auth.token.email || "").toLowerCase();
    if (request.auth.uid !== "StxrZBDeUodj7YVPmXRA2AbWcUF2" && email !== "elishayoungest19@gmail.com") {
      throw new HttpsError("permission-denied", "Accès réservé à l'administration.");
    }
    const input = request.data || {};
    const agent = String(input.agent || "");
    const pin = String(input.pin || "");
    const expectedPin = agent === "ELISHA YOUNGEST" ? AGENT1_PIN.value() : agent === "BLESSING" ? AGENT2_PIN.value() : "";
    if (!expectedPin) throw new HttpsError("invalid-argument", "Agent invalide.");
    if (!pin || pin !== expectedPin) throw new HttpsError("permission-denied", "Code PIN incorrect.");
    const date = String(input.date || "");
    const phone = String(input.phone || "").trim().slice(0, 40);
    const beneficiary = String(input.beneficiary || "").trim().slice(0, 120);
    const amount = Number(input.amount);
    const fees = Number(input.fees);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !phone || !beneficiary || !Number.isFinite(amount) || amount <= 0 || !Number.isFinite(fees) || fees < 0) {
      throw new HttpsError("invalid-argument", "Vérifiez la date, le numéro, le bénéficiaire et les montants.");
    }
    const ref = db.collection("yb_lumicash_journal").doc();
    await ref.set({
      agent, agentLabel: agent === "BLESSING" ? "AGENT 2" : "AGENT 1", date, phone, beneficiary, amount, fees,
      createdAt: admin.firestore.FieldValue.serverTimestamp(), source: "web-admin", createdBy: request.auth.uid
    });
    return { success: true, id: ref.id };
  }
);

// Envoie une notification push au client lorsqu'un administrateur répond dans le chat.
exports.notifyClientWhenAdminReplies = onDocumentCreated(
  "yb_chat_conversations/{conversationId}/messages/{messageId}",
  async (event) => {
    const message = event.data && event.data.data();
    if (!message || message.senderRole !== "admin") return;

    const conversationId = event.params.conversationId;
    const conversationSnap = await db.collection("yb_chat_conversations")
      .doc(conversationId).get();
    if (!conversationSnap.exists) return;

    const conversation = conversationSnap.data() || {};
    const ownerUid = String(conversation.ownerUid || "");
    if (!ownerUid || ownerUid === String(message.senderUid || "")) return;

    const tokenSnap = await db.collection("yb_notification_tokens").doc(ownerUid).get();
    if (!tokenSnap.exists) return;
    const token = String((tokenSnap.data() || {}).token || "");
    if (!token) return;

    const text = String(message.text || "Vous avez reçu une réponse du service client.");
    await admin.messaging().send({
      token,
      notification: {
        title: "YOUNGEST'S BUSINESS — Réponse du service",
        body: text.length > 160 ? text.slice(0, 157) + "..." : text
      },
      data: {
        type: "chat_reply",
        conversationId,
        title: "YOUNGEST'S BUSINESS — Réponse du service",
        body: text
      },
      android: { priority: "high" }
    });
  }
);


// V46 : traitement quotidien des échéances côté serveur (heure de Kinshasa).
// Crée une seule notification par prêt, par jour et par catégorie d'alerte.
const { onSchedule } = require("firebase-functions/v2/scheduler");

function v46Millis(value) {
  if (!value) return 0;
  try {
    if (typeof value.toDate === "function") return value.toDate().getTime();
    if (typeof value === "number") return value < 1000000000000 ? value * 1000 : value;
    if (typeof value === "object" && Number.isFinite(value.seconds)) return value.seconds * 1000;
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : 0;
  } catch (_) { return 0; }
}
function v46DayKey(ms) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Kinshasa", year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(new Date(ms));
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}
function v46StartOfLocalDay(dayKey) {
  // Kinshasa is UTC+1/UTC+2 depending on historical rules; current timezone is UTC+1.
  // Compare date keys in Africa/Kinshasa rather than relying on runner timezone.
  return dayKey;
}
function v46DueDate(loan) {
  return loan.dueDate || loan.echeance || loan.dueAt ||
    (loan.date && loan.days ? Number(loan.date) + Number(loan.days) * 86400000 : null);
}
function v46Amount(value) {
  const n = Number(value ?? 0);
  return Number.isFinite(n) ? n : 0;
}
exports.processLoanDueRemindersV46 = onSchedule(
  { schedule: "0 7 * * *", timeZone: "Africa/Kinshasa", region: "us-central1", retryCount: 2 },
  async () => {
    const [loanSnap, paymentSnap] = await Promise.all([
      db.collection("yb_loans").get(),
      db.collection("yb_payments").get()
    ]);
    const loans = loanSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const payments = paymentSnap.docs.map(doc => doc.data());
    const now = Date.now();
    const todayKey = v46DayKey(now);
    const dueNotifications = db.collection("yb_admin_due_notifications");
    const adminTokenSnap = await db.collection("yb_notification_tokens").doc("StxrZBDeUodj7YVPmXRA2AbWcUF2").get();
    const adminToken = adminTokenSnap.exists ? String((adminTokenSnap.data() || {}).token || "") : "";
    let created = 0;

    for (const loan of loans) {
      const principal = v46Amount(loan.principal ?? loan.amount ?? loan.montant ?? loan.approvedAmount);
      const rate = v46Amount(loan.rate ?? loan.interestRate ?? loan.taux);
      const savedInterest = loan.interestAmount ?? loan.interest ?? loan.interestGenerated;
      const interest = savedInterest !== undefined && savedInterest !== null ? v46Amount(savedInterest) : principal * rate / 100;
      const savedTotal = loan.totalDue ?? loan.totalToRepay ?? loan.totalRepayment;
      const totalDue = savedTotal !== undefined && savedTotal !== null ? v46Amount(savedTotal) : principal + interest;
      const paid = payments.filter(p =>
        (p.loanId && p.loanId === loan.id) ||
        (p.loan && typeof p.loan === "object" && p.loan.id === loan.id) ||
        (p.loanRef && p.loanRef === loan.id)
      ).reduce((sum, p) => sum + v46Amount(p.amount ?? p.montant ?? p.paidAmount ?? p.amountPaid), 0);
      const balance = Math.max(0, totalDue - paid);
      if (balance <= 0) continue;
      const dueMs = v46Millis(v46DueDate(loan));
      if (!dueMs) continue; // Ne pas inventer de date d'échéance.
      const dueKey = v46DayKey(dueMs);
      const nowDate = new Date(`${todayKey}T12:00:00Z`);
      const dueDate = new Date(`${dueKey}T12:00:00Z`);
      const days = Math.round((dueDate.getTime() - nowDate.getTime()) / 86400000);
      if (days > 3) continue;
      const alertType = days < 0 ? "overdue" : days === 0 ? "today" : days === 1 ? "tomorrow" : "upcoming";
      const alertLabel = days < 0 ? `EN RETARD (${Math.abs(days)} j)` : days === 0 ? "ÉCHÉANCE AUJOURD'HUI" : days === 1 ? "ÉCHÉANCE DEMAIN" : `ÉCHÉANCE DANS ${days} J`;
      const notificationId = `${String(loan.id).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 90)}_${todayKey}_${alertType}`;
      const ref = dueNotifications.doc(notificationId);
      let wasCreated = false;
      await db.runTransaction(async tx => {
        const existing = await tx.get(ref);
        if (existing.exists) return;
        tx.create(ref, {
          loanId: String(loan.id), clientId: String(loan.clientId || ""),
          clientName: String(loan.clientName || loan.name || loan.client || loan.clientId || "Client sans nom"),
          phone: String(loan.clientPhone || loan.phone || loan.telephone || ""),
          dueDate: dueKey, dueDateLabel: dueKey, alertType, alertLabel, days,
          balance, status: "NOUVELLE", createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdAtMs: Date.now(), source: "V46_DAILY_SCHEDULE"
        });
        wasCreated = true;
      });
      if (!wasCreated) continue;
      created++;
      // Push best-effort: only works when the admin device/browser has registered a valid FCM token.
      if (adminToken) {
        try {
          await admin.messaging().send({
            token: adminToken,
            notification: {
              title: "YOUNGEST'S BUSINESS — Échéance",
              body: `${alertLabel} : ${loan.clientName || loan.name || loan.clientId || "Client"}. Solde : ${Math.round(balance).toLocaleString("fr-FR")} FBU.`
            },
            data: { type: "loan_due", loanId: String(loan.id), notificationId, alertType },
            android: { priority: "high" }
          });
        } catch (error) {
          console.warn("V46 push admin non envoyé; notification Firestore conservée.", error && error.code);
        }
      }
    }
    console.log(`V46 échéances: ${created} nouvelle(s) notification(s) pour ${todayKey}.`);
  }
);


// V50 YOUNGEST'S B WIFI: génération de coupons d'inventaire côté serveur.
// Aucun accès MikroTik ni encaissement n'est simulé ici. Le statut initial reste AVAILABLE.
const crypto = require("node:crypto");
const WIFI_PLANS = {
  4: { label: "4 heures", price: 2000 },
  8: { label: "8 heures", price: 3500 },
  12: { label: "12 heures", price: 5000 },
  24: { label: "24 heures", price: 8000 }
};

function assertWifiAdmin(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");
  const email = String(request.auth.token.email || "").toLowerCase();
  const uid = String(request.auth.uid || "");
  if (email !== "elishayoungest19@gmail.com" && uid !== "StxrZBDeUodj7YVPmXRA2AbWcUF2") {
    throw new HttpsError("permission-denied", "Réservé à l'administrateur YOUNGEST'S BUSINESS.");
  }
}

exports.createWifiCoupons = onCall(async (request) => {
  assertWifiAdmin(request);
  const input = request.data || {};
  const hours = Number(input.hours);
  const quantity = Number(input.quantity);
  const currency = String(input.currency || "CDF").toUpperCase();
  const plan = WIFI_PLANS[hours];
  if (!plan) throw new HttpsError("invalid-argument", "Forfait Wi-Fi invalide.");
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
    throw new HttpsError("invalid-argument", "La quantité doit être comprise entre 1 et 50.");
  }
  if (currency !== "CDF") throw new HttpsError("invalid-argument", "Seule la devise CDF est autorisée pour ces tarifs.");

  const now = admin.firestore.FieldValue.serverTimestamp();
  const batch = db.batch();
  const created = [];
  const codes = new Set();
  for (let i = 0; i < quantity; i++) {
    let code;
    do { code = `YB${crypto.randomBytes(6).toString("hex").toUpperCase()}`; } while (codes.has(code));
    codes.add(code);
    const ref = db.collection("yb_wifi_coupons").doc();
    const record = {
      code, hours, planLabel: plan.label, price: plan.price, currency,
      status: "AVAILABLE", deviceId: null, activatedAt: null, expiresAt: null,
      saleId: null, createdAt: now, createdBy: request.auth.uid,
      createdByEmail: String(request.auth.token.email || ""),
      source: "YB_WIFI_V50_INVENTORY", routerProvisioned: false
    };
    batch.create(ref, record);
    created.push({ id: ref.id, code, planLabel: plan.label, price: plan.price, currency, status: "AVAILABLE" });
  }
  await batch.commit();
  await db.collection("yb_wifi_audit").add({
    action: "COUPONS_CREATED", quantity, hours, price: plan.price, currency,
    actorUid: request.auth.uid, actorEmail: String(request.auth.token.email || ""),
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    note: "Inventaire généré; pas encore provisionné sur MikroTik et pas une vente confirmée."
  });
  return { success: true, quantity: created.length, coupons: created, message: "Coupons enregistrés dans Firebase; activation MikroTik à configurer." };
});

