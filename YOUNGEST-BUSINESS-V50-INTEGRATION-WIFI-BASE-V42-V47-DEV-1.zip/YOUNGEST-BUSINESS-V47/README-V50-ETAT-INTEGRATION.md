# V50 — correction d'intégration Android + Web Admin

## Inclus dans cette révision
- Base Android V42 conservée; version de développement passée à versionCode 50 / versionName 1.50.0-wifi-dev.
- Entrée « YOUNGEST'S B WIFI » dans l'écran d'accueil Android et écran d'inventaire synchronisé avec Firestore.
- Web Admin : inventaire des coupons lu depuis `yb_wifi_coupons`, tarifs 4 h/8 h/12 h/24 h et création via callable Cloud Function.
- Cloud Function `createWifiCoupons`: authentification administrateur, validation du forfait et quantité (1–50), codes aléatoires générés côté serveur, état initial `AVAILABLE`, journal d'audit.
- Règles Firestore : lecture réservée à l'administrateur; les écritures des coupons et du journal d'audit passent par le backend.
- Les modules prêts, remboursements, rapports, Lumicash, envois et chat sont conservés dans les fichiers de base.

## Limites connues — pas production
- Cette révision n'est pas encore déployée sur Firebase; la Cloud Function et les règles doivent être déployées avant que la création côté serveur fonctionne.
- Aucun endpoint RouterOS/MikroTik ni secret routeur n'est configuré. `routerProvisioned` reste `false` et les coupons créés sont de l'inventaire seulement.
- Aucun paiement réel n'est traité. Aucune vente ou recette ne doit être comptabilisée tant qu'un flux de paiement vérifiable n'est pas intégré.
- L'activation au premier appareil, le minuteur d'expiration, la révocation/remplacement d'appareil et le provisioning MikroTik restent à implémenter et tester.
- L'APK de CI est un APK debug non signé pour production.

## Vérifications exécutées
- `node --check web-admin/app.js`
- `node --check functions/index.js`
- Validation JSON de `firebase.json`, `functions/package.json` et `app/google-services.json`
- Le build Gradle Android n'a pas été exécuté dans l'environnement local de préparation; lancer le workflow GitHub Actions après import de l'archive.
