package com.aistudio.youngestbiz.mbkz;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.Manifest;
import android.content.pm.PackageManager;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.functions.FirebaseFunctions;

/**
 * YOUNGEST'S BUSINESS - V18. Transfert Mobile Money direct client + API authorization architecture + Firebase.
 * Local persistent application with admin protection, Firebase/Firestore synchronization and manual data backup/restore.
 * Local persistent prototype: clients, loans and payments survive app restart.
 * This is not yet a production financial backend; real Mobile Money debit/credit requires
 * authorized operator/payment APIs and legal approvals before real-money deployment.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "youngest_business_data";
    private static final String KEY_DATA = "data";
    private static final String KEY_ADMIN_HASH = "admin_password_hash";
    // Compte Firebase utilisé uniquement par l'espace Bureau/Admin.
    // Le mot de passe n'est jamais stocké dans le code : il est saisi à la connexion.
    private static final String FIREBASE_ADMIN_EMAIL = "elishayoungest19@gmail.com";
    private static final String KEY_TRANSFERS = "transfers";
    private boolean adminSession = false;

    // Synchronisation centrale Firebase/Firestore
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private ListenerRegistration clientsListener;
    private ListenerRegistration loansListener;
    private ListenerRegistration paymentsListener;
    private ListenerRegistration loanRequestsListener;
    private boolean loanRequestsListenerIsClient = false;
    private boolean cloudSyncStarted = false;
    private boolean initialCloudClientsDone = false;
    private boolean initialCloudLoansDone = false;
    private boolean initialCloudPaymentsDone = false;
    private boolean initialCloudRequestsDone = false;
    private boolean clientMode = false;
    private String clientUid = "";
    // Files reçus avant leur dépendance (client/loan) : on les conserve puis on les rejoue.
    private final Map<String,DocumentSnapshot> pendingCloudLoans = new HashMap<>();
    private final Map<String,DocumentSnapshot> pendingCloudPayments = new HashMap<>();

    final int NAVY = Color.rgb(6,43,99), GREEN = Color.rgb(47,143,20), GOLD = Color.rgb(217,165,27);
    final int RED = Color.rgb(198,40,40), PURPLE = Color.rgb(112,55,180), BLUE = Color.rgb(25,100,210);
    final int LIGHT = Color.rgb(245,247,250);

    LinearLayout root, body;
    final ArrayList<Client> clients = new ArrayList<>();
    final ArrayList<Loan> loans = new ArrayList<>();
    final ArrayList<Payment> payments = new ArrayList<>();
    final ArrayList<LoanRequest> loanRequests = new ArrayList<>();
    final ArrayList<Transfer> transfersList = new ArrayList<>();
    SharedPreferences prefs;

    static class Client {
        String id, name, phone;
        Client(String n, String p) { this(makeId(n + "|" + p), n, p); }
        Client(String i, String n, String p) { id=i; name=n; phone=p; }
    }

    static class Loan {
        String id; Client c; double principal, rate; int days; long date;
        Loan(Client c, double p, double r, int d) {
            this(c, p, r, d, System.currentTimeMillis());
        }
        Loan(Client c, double p, double r, int d, long when) {
            this.c=c; principal=p; rate=r; days=d; date=when;
            id=makeId(c.id + "|" + p + "|" + r + "|" + d + "|" + date);
        }
        double interest(){ return principal * rate / 100.0; }
        double total(){ return principal + interest(); }
        long dueDate(){ return date + days * 24L * 60L * 60L * 1000L; }
        double paid(ArrayList<Payment> ps){ double x=0; for(Payment p:ps) if(p.loan==this) x+=p.amount; return x; }
        double balance(ArrayList<Payment> ps){ return Math.max(0, total()-paid(ps)); }
    }

    static class Payment {
        String id; Loan loan; double amount; long date;
        Payment(Loan l, double a){ this(l, a, System.currentTimeMillis()); }
        Payment(Loan l, double a, long when){ loan=l; amount=a; date=when; id=makeId(l.id + "|" + a + "|" + date); }
    }

    static class LoanRequest {
        String id, requesterUid, clientId, name, phone, reason, status;
        double amount; int days; long date, updatedAt;
        LoanRequest(String uid, String n, String p, double a, int d, String r){
            requesterUid=uid; name=n; phone=p; amount=a; days=d; reason=r;
            status="EN_ATTENTE"; date=System.currentTimeMillis(); updatedAt=date;
            id=makeId(uid + "|" + name + "|" + phone + "|" + amount + "|" + date);
        }
    }

    static class Transfer {
        String id, currency, senderName, senderPhone, senderNetwork, beneficiaryName, beneficiaryPhone, beneficiaryNetwork, reason, status, apiStatus, providerReference, requesterUid;
        boolean clientInitiated;
        double amount, fees; long date;
        Transfer(String cur,String sn,String sp,String sr,String bn,String bp,String br,double a,double f,String rs){
            currency=cur; senderName=sn; senderPhone=sp; senderNetwork=sr; beneficiaryName=bn; beneficiaryPhone=bp; beneficiaryNetwork=br; amount=a; fees=f; reason=rs;
            status="EN_COURS"; apiStatus="SIMULATION"; providerReference=""; requesterUid=""; clientInitiated=false; date=System.currentTimeMillis();
            id="TRF-"+makeId(senderPhone+"|"+beneficiaryPhone+"|"+amount+"|"+date).substring(0,10).toUpperCase(Locale.US);
        }
        double total(){ return amount+fees; }
    }

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    private String clientPref(String suffix){ return "client_" + (clientUid==null?"":clientUid) + "_" + suffix; }
    private String savedClientName(){ return clientUid==null?"":prefs.getString(clientPref("name"),""); }
    private String savedClientPhone(){ return clientUid==null?"":prefs.getString(clientPref("phone"),""); }
    private String savedClientWalletNetwork(){ return clientUid==null?"":prefs.getString(clientPref("wallet_network"),""); }

    private void setupNotifications(){
        AppNotificationService.createChannel(this);
        if(android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            if(token!=null && !token.isEmpty()) prefs.edit().putString("fcm_token",token).apply();
            uploadNotificationToken(token);
        });
    }

    private void uploadNotificationToken(String token){
        if(token==null || token.isEmpty() || firestore==null || clientUid==null || clientUid.isEmpty()) return;
        Map<String,Object> m=new HashMap<>();
        m.put("token",token);
        m.put("uid",clientUid);
        m.put("clientMode",clientMode);
        m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_notification_tokens").document(clientUid).set(m);
    }

    private void localNotification(String title,String message){
        AppNotificationService.notifyLocal(this,title,message);
    }

    private void showNotificationsPage(){
        base("NOTIFICATIONS",BLUE);
        body.addView(tv("🔔 CENTRE DE NOTIFICATIONS",21));
        String raw=prefs.getString("app_notifications","[]");
        try{
            JSONArray a=new JSONArray(raw);
            if(a.length()==0) body.addView(tv("Aucune notification pour le moment.",15));
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.getJSONObject(i);
                body.addView(tv("🔔 "+o.optString("title")+"\n"+o.optString("message")+"\n"+o.optString("date"),15));
            }
        }catch(Exception e){ body.addView(tv("Aucune notification pour le moment.",15)); }
        Button clear=btn("🗑️ EFFACER LES NOTIFICATIONS",RED);
        clear.setOnClickListener(v->{ prefs.edit().remove("app_notifications").apply(); showNotificationsPage(); });
        body.addView(clear);
        Button back=btn("← RETOUR",NAVY); back.setOnClickListener(v->{ if(clientMode) clientHome(); else home(); }); body.addView(back);
    }

    private String normalizePhone(String phone){
        if(phone==null) return "";
        String n=phone.replaceAll("[^0-9+]","");
        if(n.startsWith("+243")) n="0"+n.substring(4);
        else if(n.startsWith("243") && n.length()>9) n="0"+n.substring(3);
        return n;
    }

    static class WalletVerification {
        boolean verified; String network, phone, holderName, source;
        WalletVerification(boolean ok,String net,String ph,String holder,String src){ verified=ok; network=net; phone=ph; holderName=holder; source=src; }
    }

    private WalletVerification verifyWalletSimulation(String phone, String network){
        String n=normalizePhone(phone);
        String net=network==null?"":network.trim();
        if(n.isEmpty() || net.isEmpty()) return new WalletVerification(false,net,phone,"","AUCUNE_VERIFICATION");

        // Phase pilote : on ne lit pas la SIM. On recherche automatiquement le numéro
        // dans le portefeuille client déjà enregistré dans l'application.
        String saved=normalizePhone(savedClientPhone());
        String savedNet=savedClientWalletNetwork();
        if(!saved.isEmpty() && saved.equals(n) && net.equalsIgnoreCase(savedNet) && !savedClientName().trim().isEmpty()) {
            return new WalletVerification(true,net,phone,savedClientName().trim(),"PROFIL PORTEFEUILLE VÉRIFIÉ");
        }

        // Si le numéro existe déjà dans les fiches clients, son nom est repris
        // automatiquement pendant le pilote. La vérification opérateur réelle
        // sera remplacée par l'API officielle dès que l'autorisation sera obtenue.
        Client match=null;
        for(Client c:clients){
            if(!normalizePhone(c.phone).isEmpty() && normalizePhone(c.phone).equals(n)){
                if(match!=null && !match.name.equalsIgnoreCase(c.name)) return new WalletVerification(false,net,phone,"","PLUSIEURS_PROFILS");
                match=c;
            }
        }
        if(match!=null && !match.name.trim().isEmpty()){
            return new WalletVerification(true,net,phone,match.name.trim(),"REGISTRE CLIENT YOUNGEST'S BUSINESS");
        }

        return new WalletVerification(false,net,phone,"","API_OFFICIELLE_REQUISE");
    }

    private String findVerifiedWalletName(String phone, String network){
        WalletVerification r=verifyWalletSimulation(phone,network);
        return r.verified?r.holderName:"";
    }


    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(14),dp(10),dp(14),dp(10)); return t;
    }

    GradientDrawable bg(int c,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    Button btn(String s,int c){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(bg(c,14)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        loadData();
        showSplash();
        setupNotifications();
        startCloudSync();
    }

    private void seedIfEmpty(){
        if(!clients.isEmpty()) return;
        clients.add(new Client("KIEUERECI KALAY",""));
        clients.add(new Client("MUKOSA CHRISTIAN",""));
        clients.add(new Client("NZAGIRE VALENTINE",""));
        loans.add(new Loan(clients.get(0),350000,30,30));
        loans.add(new Loan(clients.get(1),350000,20,14));
        loans.add(new Loan(clients.get(2),100000,10,7));
        saveData();
    }

    private void saveData(){
        try {
            JSONObject all=new JSONObject();
            JSONArray cs=new JSONArray();
            for(Client c:clients){ JSONObject o=new JSONObject(); o.put("id",c.id); o.put("name",c.name); o.put("phone",c.phone); cs.put(o); }
            JSONArray ls=new JSONArray();
            for(Loan l:loans){ JSONObject o=new JSONObject(); o.put("id",l.id); o.put("client",clients.indexOf(l.c)); o.put("clientId",l.c.id); o.put("principal",l.principal); o.put("rate",l.rate); o.put("days",l.days); o.put("date",l.date); ls.put(o); }
            JSONArray ps=new JSONArray();
            for(Payment p:payments){ JSONObject o=new JSONObject(); o.put("id",p.id); o.put("loan",loans.indexOf(p.loan)); o.put("loanId",p.loan.id); o.put("amount",p.amount); o.put("date",p.date); ps.put(o); }
            JSONArray rs=new JSONArray();
            for(LoanRequest r:loanRequests){ JSONObject o=new JSONObject(); o.put("id",r.id); o.put("requesterUid",r.requesterUid); o.put("clientId",r.clientId); o.put("name",r.name); o.put("phone",r.phone); o.put("amount",r.amount); o.put("days",r.days); o.put("reason",r.reason); o.put("status",r.status); o.put("date",r.date); o.put("updatedAt",r.updatedAt); rs.put(o); }
            JSONArray ts=new JSONArray();
            for(Transfer t:transfersList){ JSONObject o=new JSONObject(); o.put("id",t.id); o.put("currency",t.currency); o.put("senderName",t.senderName); o.put("senderPhone",t.senderPhone); o.put("senderNetwork",t.senderNetwork); o.put("beneficiaryName",t.beneficiaryName); o.put("beneficiaryPhone",t.beneficiaryPhone); o.put("beneficiaryNetwork",t.beneficiaryNetwork); o.put("amount",t.amount); o.put("fees",t.fees); o.put("reason",t.reason); o.put("status",t.status); o.put("apiStatus",t.apiStatus); o.put("providerReference",t.providerReference); o.put("requesterUid",t.requesterUid); o.put("clientInitiated",t.clientInitiated); o.put("date",t.date); ts.put(o); }
            all.put("clients",cs); all.put("loans",ls); all.put("payments",ps); all.put("loanRequests",rs); all.put("transfers",ts);
            prefs.edit().putString(KEY_DATA,all.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void loadData(){
        String raw=prefs.getString(KEY_DATA,null);
        if(raw==null){ seedIfEmpty(); return; }
        try {
            JSONObject all=new JSONObject(raw);
            JSONArray cs=all.optJSONArray("clients");
            JSONArray ls=all.optJSONArray("loans");
            JSONArray ps=all.optJSONArray("payments");
            if(cs!=null) for(int i=0;i<cs.length();i++){ JSONObject o=cs.getJSONObject(i); String n=o.optString("name"), ph=o.optString("phone"); String id=o.optString("id",makeId(n+"|"+ph)); clients.add(new Client(id,n,ph)); }
            if(ls!=null) for(int i=0;i<ls.length();i++){ JSONObject o=ls.getJSONObject(i); int ci=o.optInt("client",-1); if(ci>=0&&ci<clients.size()){ long when=o.optLong("date",System.currentTimeMillis()); Loan l=new Loan(clients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days"),when); l.id=o.optString("id",l.id); loans.add(l); } }
            if(ps!=null) for(int i=0;i<ps.length();i++){ JSONObject o=ps.getJSONObject(i); int li=o.optInt("loan",-1); if(li>=0&&li<loans.size()){ long when=o.optLong("date",System.currentTimeMillis()); Payment p=new Payment(loans.get(li),o.optDouble("amount"),when); p.id=o.optString("id",p.id); payments.add(p); } }
            JSONArray rs=all.optJSONArray("loanRequests");
            if(rs!=null) for(int i=0;i<rs.length();i++){ JSONObject o=rs.getJSONObject(i); LoanRequest r=new LoanRequest(o.optString("requesterUid"),o.optString("name"),o.optString("phone"),o.optDouble("amount"),o.optInt("days"),o.optString("reason")); r.id=o.optString("id",r.id); r.clientId=o.optString("clientId",""); r.status=o.optString("status","EN_ATTENTE"); r.date=o.optLong("date",r.date); r.updatedAt=o.optLong("updatedAt",r.date); loanRequests.add(r); }
            JSONArray ts=all.optJSONArray("transfers");
            if(ts!=null) for(int i=0;i<ts.length();i++){ JSONObject o=ts.getJSONObject(i); Transfer t=new Transfer(o.optString("currency","FC"),o.optString("senderName"),o.optString("senderPhone"),o.optString("senderNetwork"),o.optString("beneficiaryName"),o.optString("beneficiaryPhone"),o.optString("beneficiaryNetwork"),o.optDouble("amount"),o.optDouble("fees"),o.optString("reason")); t.id=o.optString("id",t.id); t.status=o.optString("status","EN_COURS"); t.apiStatus=o.optString("apiStatus","SIMULATION"); t.providerReference=o.optString("providerReference",""); t.requesterUid=o.optString("requesterUid",""); t.clientInitiated=o.optBoolean("clientInitiated",false); t.date=o.optLong("date",t.date); transfersList.add(t); }
            if(clients.isEmpty()) seedIfEmpty();
        } catch(Exception e){ clients.clear(); loans.clear(); payments.clear(); seedIfEmpty(); }
    }

    private static String makeId(String value){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] out=md.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb=new StringBuilder();
            for(byte q:out) sb.append(String.format(Locale.US,"%02x",q));
            return sb.toString();
        }catch(Exception e){ return UUID.randomUUID().toString().replace("-",""); }
    }

    private void startCloudSync(){
        if(cloudSyncStarted){
            if(clientMode){
                if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
                if(firestore==null) firestore=FirebaseFirestore.getInstance();
                if(firebaseAuth.getCurrentUser()==null){
                    firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                        if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                            clientUid=firebaseAuth.getCurrentUser().getUid();
                            setupNotifications();
                            attachClientRequestsListener();
                        }else{
                            Toast.makeText(this,"Firebase : connexion client indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
                        }
                    });
                }else{
                    clientUid=firebaseAuth.getCurrentUser().getUid();
                    attachClientRequestsListener();
                }
            }else if(adminSession){
                attachClientsListener();
                attachBureauRequestsListener();
            }
            return;
        }
        cloudSyncStarted=true;
        try{
            firebaseAuth=FirebaseAuth.getInstance();
            firestore=FirebaseFirestore.getInstance();

            // L'espace client utilise l'authentification anonyme.
            // Si un compte email Admin est encore connecté, on le remplace par l'anonyme.
            if(clientMode){
                if(firebaseAuth.getCurrentUser()!=null && firebaseAuth.getCurrentUser().getEmail()!=null){
                    firebaseAuth.signOut();
                }
                if(firebaseAuth.getCurrentUser()==null){
                    firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                        if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                            clientUid=firebaseAuth.getCurrentUser().getUid();
                            setupNotifications();
                            attachClientRequestsListener();
                        }else{
                            Toast.makeText(this,"Firebase : connexion client indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                clientUid=firebaseAuth.getCurrentUser().getUid();
                attachClientRequestsListener();
                return;
            }

            // Le Bureau ne doit plus utiliser un compte anonyme : il doit être
            // authentifié avec le compte Firebase Admin au moment de l'accès Bureau.
            if(adminSession && firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                attachClientsListener();
                attachBureauRequestsListener();
            }
        }catch(Exception e){
            Toast.makeText(this,"Firebase : démarrage impossible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
        }
    }

    private void startBureauCloudSync(){
        clientMode=false;
        try{
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();

            if(firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                setupNotifications();
                attachClientsListener();
                attachBureauRequestsListener();
            }else{
                Toast.makeText(this,"Connexion Firebase du Bureau requise. Ouvrez l'espace Bureau et reconnectez-vous.",Toast.LENGTH_LONG).show();
            }
        }catch(Exception e){
            Toast.makeText(this,"Firebase : connexion Bureau indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
        }
    }

    private void attachClientsListener(){
        if(firestore==null || clientsListener!=null) return;
        clientsListener=firestore.collection("yb_clients").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudClient(d);
            retryPendingCloudLoans();
            if(!initialCloudClientsDone){
                initialCloudClientsDone=true;
                uploadAllClients();
                attachLoansListener();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachLoansListener(){
        if(firestore==null || loansListener!=null) return;
        loansListener=firestore.collection("yb_loans").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoan(d);
            retryPendingCloudPayments();
            if(!initialCloudLoansDone){
                initialCloudLoansDone=true;
                uploadAllLoans();
                attachPaymentsListener();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachPaymentsListener(){
        if(firestore==null || paymentsListener!=null) return;
        paymentsListener=firestore.collection("yb_payments").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudPayment(d);
            if(!initialCloudPaymentsDone){
                initialCloudPaymentsDone=true;
                uploadAllPayments();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachClientRequestsListener(){
        if(firestore==null || clientUid==null || clientUid.isEmpty()) return;
        if(loanRequestsListener!=null && loanRequestsListenerIsClient) return;
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        loanRequestsListenerIsClient=true;
        loanRequestsListener=firestore.collection("yb_loan_requests")
            .whereEqualTo("requesterUid", clientUid)
            .addSnapshotListener((snap,error)->{
                if(error!=null){
                    Toast.makeText(this,"Firebase : lecture de vos demandes impossible. Vérifiez la connexion.",Toast.LENGTH_LONG).show();
                    return;
                }
                if(snap==null) return;
                for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoanRequest(d);
                initialCloudRequestsDone=true;
                refreshAfterCloudChange();
            });
    }

    private void attachBureauRequestsListener(){
        if(firestore==null) return;
        if(loanRequestsListener!=null && !loanRequestsListenerIsClient) return;
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        loanRequestsListenerIsClient=false;
        loanRequestsListener=firestore.collection("yb_loan_requests")
            .addSnapshotListener((snap,error)->{
                if(error!=null){
                    Toast.makeText(this,"Firebase : le Bureau ne peut pas recevoir les demandes client. Vérifiez l'accès Firestore.",Toast.LENGTH_LONG).show();
                    return;
                }
                if(snap==null) return;
                for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoanRequest(d);
                initialCloudRequestsDone=true;
                refreshAfterCloudChange();
            });
    }

    private void mergeCloudLoanRequest(DocumentSnapshot d){
        String id=d.getId(); String uid=d.getString("requesterUid");
        String name=d.getString("name"); if(name==null) return;
        LoanRequest existing=null; for(LoanRequest r:loanRequests) if(r.id.equals(id)){ existing=r; break; }
        boolean wasNew=(existing==null);
        if(existing==null){ existing=new LoanRequest(uid==null?"":uid,name,d.getString("phone")==null?"":d.getString("phone"),number(d.get("amount")),(int)number(d.get("days")),d.getString("reason")==null?"":d.getString("reason")); existing.id=id; loanRequests.add(existing); }
        String oldStatus=existing.status;
        existing.requesterUid=uid==null?existing.requesterUid:uid; existing.clientId=d.getString("clientId")==null?existing.clientId:d.getString("clientId");
        existing.name=name; existing.phone=d.getString("phone")==null?"":d.getString("phone"); existing.amount=number(d.get("amount")); existing.days=(int)number(d.get("days")); existing.reason=d.getString("reason")==null?"":d.getString("reason"); existing.status=d.getString("status")==null?"EN_ATTENTE":d.getString("status"); existing.date=longNumber(d.get("date")); existing.updatedAt=longNumber(d.get("updatedAt")); saveData();
        if(clientMode && existing!=null && !oldStatus.equals(existing.status) && ("APPROUVEE".equals(existing.status) || "REFUSEE".equals(existing.status))){
            localNotification("Mise à jour de votre demande", "Votre demande de prêt est maintenant : "+existing.status);
        }
        if(adminSession && wasNew && initialCloudRequestsDone){
            localNotification("Nouvelle demande client", existing.name+" a envoyé une demande de prêt de "+fmt(existing.amount)+" FBu.");
        }
    }

    private void uploadLoanRequest(LoanRequest r){
        if(firestore==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",r.id); m.put("requesterUid",r.requesterUid); m.put("clientId",r.clientId); m.put("name",r.name); m.put("phone",r.phone); m.put("amount",r.amount); m.put("days",r.days); m.put("reason",r.reason); m.put("status",r.status); m.put("date",r.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_loan_requests").document(r.id).set(m)
            .addOnSuccessListener(v->{
                // La demande est maintenant confirmée dans Firestore.
            })
            .addOnFailureListener(e->{
                Toast.makeText(this,"Échec de synchronisation de la demande vers Firebase : "+e.getMessage(),Toast.LENGTH_LONG).show();
            });
    }

    private void mergeCloudClient(DocumentSnapshot d){
        String id=d.getId();
        String name=d.getString("name");
        String phone=d.getString("phone");
        if(name==null) return;
        for(Client c:clients) if(c.id.equals(id)){ c.name=name; c.phone=phone==null?"":phone; return; }
        clients.add(new Client(id,name,phone==null?"":phone));
        saveData();
    }

    private void mergeCloudLoan(DocumentSnapshot d){
        String id=d.getId();
        String clientId=d.getString("clientId");
        if(clientId==null || clientId.isEmpty()) return;
        Client c=findClient(clientId);
        // Important : un prêt peut arriver avant le document client sur un autre téléphone.
        // Le document du prêt contient donc aussi le nom/téléphone du client comme secours.
        if(c==null){
            String cloudName=d.getString("clientName");
            String cloudPhone=d.getString("clientPhone");
            if(cloudName!=null && !cloudName.trim().isEmpty()){
                c=new Client(clientId,cloudName.trim(),cloudPhone==null?"":cloudPhone);
                clients.add(c);
                saveData();
            } else {
                pendingCloudLoans.put(id,d);
                return;
            }
        }
        double principal=number(d.get("principal"));
        double rate=number(d.get("rate"));
        int days=(int)number(d.get("days"));
        long when=longNumber(d.get("date"));
        for(Loan l:loans) if(l.id.equals(id)){ l.c=c; l.principal=principal; l.rate=rate; l.days=days; l.date=when; return; }
        Loan l=new Loan(c,principal,rate,days,when); l.id=id; loans.add(l); saveData();
    }

    private void retryPendingCloudLoans(){
        if(pendingCloudLoans.isEmpty()) return;
        ArrayList<DocumentSnapshot> waiting=new ArrayList<>(pendingCloudLoans.values());
        pendingCloudLoans.clear();
        for(DocumentSnapshot d:waiting) mergeCloudLoan(d);
    }

    private void mergeCloudPayment(DocumentSnapshot d){
        String id=d.getId();
        String loanId=d.getString("loanId");
        if(loanId==null || loanId.isEmpty()) return;
        Loan l=findLoan(loanId);
        // Même protection pour un remboursement reçu avant le prêt correspondant.
        if(l==null){
            pendingCloudPayments.put(id,d);
            return;
        }
        double amount=number(d.get("amount"));
        long when=longNumber(d.get("date"));
        for(Payment p:payments) if(p.id.equals(id)){ p.loan=l; p.amount=amount; p.date=when; return; }
        Payment p=new Payment(l,amount,when); p.id=id; payments.add(p); saveData();
    }

    private void retryPendingCloudPayments(){
        if(pendingCloudPayments.isEmpty()) return;
        ArrayList<DocumentSnapshot> waiting=new ArrayList<>(pendingCloudPayments.values());
        pendingCloudPayments.clear();
        for(DocumentSnapshot d:waiting) mergeCloudPayment(d);
    }

    private double number(Object value){ return value instanceof Number ? ((Number)value).doubleValue() : 0; }
    private long longNumber(Object value){ return value instanceof Number ? ((Number)value).longValue() : System.currentTimeMillis(); }

    private Client findClient(String id){ for(Client c:clients) if(c.id.equals(id)) return c; return null; }
    private Loan findLoan(String id){ for(Loan l:loans) if(l.id.equals(id)) return l; return null; }

    private void uploadAllClients(){ for(Client c:clients) uploadClient(c); }
    private void uploadAllLoans(){ for(Loan l:loans) uploadLoan(l); }
    private void uploadAllPayments(){ for(Payment p:payments) uploadPayment(p); }
    private void uploadAllLoanRequests(){ for(LoanRequest r:loanRequests) uploadLoanRequest(r); }

    private void uploadClient(Client c){
        if(firestore==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",c.id); m.put("name",c.name); m.put("phone",c.phone); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_clients").document(c.id).set(m);
    }

    private void uploadLoan(Loan l){
        if(firestore==null || l.c==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",l.id); m.put("clientId",l.c.id); m.put("clientName",l.c.name); m.put("clientPhone",l.c.phone); m.put("principal",l.principal); m.put("rate",l.rate); m.put("days",l.days); m.put("date",l.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_loans").document(l.id).set(m);
    }

    private void uploadPayment(Payment p){
        if(firestore==null || p.loan==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",p.id); m.put("loanId",p.loan.id); m.put("amount",p.amount); m.put("date",p.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_payments").document(p.id).set(m);
    }

    private void refreshAfterCloudChange(){
        runOnUiThread(()->{
            if(clientMode && loanRequestsListener!=null){
                clientRequestsPage();
            } else if(adminSession && loanRequestsListener!=null){
                bureauRequestsPage();
            } else if(body!=null){
                body.invalidate();
            }
        });
    }

    void base(String name,int color){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),0,dp(8),0); bar.setBackgroundColor(color);
        TextView back=tv("‹",30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->home());
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(60)));
        TextView title=tv(name,19); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(60),1)); root.addView(bar);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(18));
        ScrollView sv=new ScrollView(this); sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showSplash(){
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        clientMode=false;
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this); im.setImageResource(R.drawable.logo_youngests_business); im.setScaleType(ImageView.ScaleType.CENTER_INSIDE); im.setPadding(dp(18),dp(18),dp(18),dp(8));
        root.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        TextView intro=tv("Choisissez votre espace",18); intro.setGravity(Gravity.CENTER); intro.setTypeface(null,Typeface.BOLD); root.addView(intro);
        Button bureau=btn("🏢 ESPACE BUREAU",NAVY); bureau.setOnClickListener(v->requireAdmin(()->{ clientMode=false; startBureauCloudSync(); home(); })); root.addView(bureau,new LinearLayout.LayoutParams(-1,dp(58)));
        Button client=btn("👤 ESPACE CLIENT",GREEN); client.setOnClickListener(v->{ clientMode=true; startCloudSync(); clientHome(); }); root.addView(client,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView note=tv("L’espace client est en phase pilote. Une authentification client renforcée et des règles serveur dédiées seront nécessaires avant ouverture publique.",12); note.setGravity(Gravity.CENTER); root.addView(note);
        setContentView(root);
    }

    void home(){
        base("YOUNGEST'S BUSINESS",NAVY);

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(20),dp(4),dp(20),dp(4));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(105)));

        TextView welcome=tv("Bienvenue 👋\nGestion des prêts et services financiers",19);
        welcome.setTypeface(null,Typeface.BOLD);
        body.addView(welcome);

        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","🔄 TRANSFERTS","💵 REMBOURSEMENTS","👤 CLIENTS","🔐 ADMINISTRATION","📞 CONTACTEZ-NOUS","ℹ️ À PROPOS DE NOUS"};
        int[] cs={RED,GREEN,BLUE,PURPLE,GOLD,NAVY,NAVY,PURPLE};
        for(int i=0;i<names.length;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{
                if(k==0) requireAdmin(()->loanForm());
                else if(k==1) services();
                else if(k==2) transfers();
                else if(k==3) requireAdmin(()->repay());
                else if(k==4) requireAdmin(()->clientsPage());
                else if(k==5) requireAdmin(()->adminDash());
                else if(k==6) contactPage();
                else aboutPage();
            });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(78); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g);

        Button pay=btn("💳 PAIEMENT",PURPLE); pay.setOnClickListener(v->requireAdmin(()->paymentPage()));
        body.addView(pay,new LinearLayout.LayoutParams(-1,dp(54)));
        Button dash=btn("📊 TABLEAU DE BORD — ADMIN",NAVY); dash.setOnClickListener(v->requireAdmin(()->dashboard()));
        body.addView(dash,new LinearLayout.LayoutParams(-1,dp(52)));
        Button notifications=btn("🔔 NOTIFICATIONS",BLUE); notifications.setOnClickListener(v->showNotificationsPage());
        body.addView(notifications,new LinearLayout.LayoutParams(-1,dp(52)));
        int pendingRequests=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingRequests++;
        Button requests=btn("📥 DEMANDES CLIENTS — "+pendingRequests+" EN ATTENTE",GREEN); requests.setOnClickListener(v->requireAdmin(()->bureauRequestsPage()));
        body.addView(requests,new LinearLayout.LayoutParams(-1,dp(54)));
        body.addView(tv("🔒 Les données de gestion sont protégées par l’accès administrateur.\nCette version utilise une authentification locale ; une sécurité serveur sera nécessaire avant tout déploiement financier réel.",14));
    }

    void clientHome(){
        base("ESPACE CLIENT",GREEN);
        if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(28),dp(2),dp(28),dp(2));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(100)));

        TextView welcome=tv("Bienvenue dans votre espace client 👋",20);
        welcome.setTypeface(null,Typeface.BOLD); body.addView(welcome);
        body.addView(tv("Que souhaitez-vous faire aujourd’hui ?",15));

        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","🔄 TRANSFERTS","💵 MES REMBOURSEMENTS","👤 MON COMPTE","📞 NOUS CONTACTER"};
        int[] cs={RED,GREEN,BLUE,PURPLE,NAVY,NAVY};
        for(int i=0;i<names.length;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{
                if(k==0) clientRequestForm();
                else if(k==1) services();
                else if(k==2) clientTransferPage();
                else if(k==3) clientRequestsPage();
                else if(k==4) clientProfilePage();
                else contactPage();
            });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(78); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g);

        Button requests=btn("📋 MES DEMANDES",NAVY);
        requests.setOnClickListener(v->clientRequestsPage());
        body.addView(requests,new LinearLayout.LayoutParams(-1,dp(52)));

        Button history=btn("📜 MES TRANSFERTS",BLUE);
        history.setOnClickListener(v->clientTransferHistoryPage());
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(52)));
        Button notifications=btn("🔔 NOTIFICATIONS",BLUE); notifications.setOnClickListener(v->showNotificationsPage());
        body.addView(notifications,new LinearLayout.LayoutParams(-1,dp(52)));

        Button about=btn("ℹ️ À PROPOS DE NOUS",PURPLE);
        about.setOnClickListener(v->aboutPage());
        body.addView(about,new LinearLayout.LayoutParams(-1,dp(54)));

        body.addView(tv("L'espace client initie les transferts. Le bureau les supervise sans validation manuelle.",14));
        Button back=btn("← RETOUR",NAVY); back.setOnClickListener(v->showSplash()); body.addView(back);
    }

    void contactPage(){
        base("CONTACTEZ-NOUS",NAVY);
        body.addView(tv("📞 SERVICE CLIENT",21));
        body.addView(tv("Notre équipe est à votre disposition pour vous accompagner.",15));
        body.addView(tv("📱 +257 66 79 66 15\n📱 +257 67 15 64 14\n📱 +243 817 447 127",18));
        body.addView(tv("Vous pouvez nous contacter pour les prêts, les services Mobile Money, les transferts et toute question concernant votre compte.",15));
    }

    void aboutPage(){
        base("À PROPOS DE NOUS",PURPLE);
        body.addView(tv("ℹ️ YOUNGEST’S BUSINESS",21));
        body.addView(tv("YOUNGEST’S BUSINESS est un service basé dans le domaine du Mobile Money, dédié à l’accompagnement financier de ses clients à travers des solutions de prêt adaptées à leurs besoins.\n\nNous accordons une importance particulière à la responsabilité, la transparence, la discipline financière et au respect des engagements.\n\nNotre objectif est d'offrir un service sérieux, confidentiel et accessible, tout en accompagnant nos clients dans une gestion financière responsable.",15));
    }

    void clientProfilePage(){
        base("MON PROFIL CLIENT",GREEN);
        body.addView(tv("👤 Vos informations",19));
        body.addView(tv("Ces informations sont utilisées pour préremplir vos prochaines demandes de prêt.",15));
        EditText n=input("Nom complet",InputType.TYPE_CLASS_TEXT);
        EditText ph=input("Téléphone du portefeuille",InputType.TYPE_CLASS_PHONE);
        Spinner walletNetwork=new Spinner(this);
        walletNetwork.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"M-Pesa","Airtel Money","Orange Money","Afrimoney"}));
        String savedNet=savedClientWalletNetwork();
        if(!savedNet.isEmpty()){
            for(int i=0;i<walletNetwork.getAdapter().getCount();i++) if(savedNet.equals(walletNetwork.getAdapter().getItem(i))) { walletNetwork.setSelection(i); break; }
        }
        n.setText(savedClientName());
        ph.setText(savedClientPhone());
        body.addView(n); body.addView(ph);
        body.addView(tv("📱 PORTEFEUILLE MOBILE MONEY ASSOCIÉ",15));
        body.addView(walletNetwork);

        Button save=btn("💾 ENREGISTRER MON PROFIL",GREEN);
        save.setOnClickListener(v->{
            String name=n.getText().toString().trim(), phone=ph.getText().toString().trim();
            if(name.isEmpty()||phone.isEmpty()){
                Toast.makeText(this,"Veuillez renseigner le nom et le téléphone.",Toast.LENGTH_SHORT).show();
                return;
            }
            String walletNet=walletNetwork.getSelectedItem()==null?"":walletNetwork.getSelectedItem().toString();
            prefs.edit().putString(clientPref("name"),name).putString(clientPref("phone"),phone).putString(clientPref("wallet_network"),walletNet).apply();
            Toast.makeText(this,"Profil enregistré.",Toast.LENGTH_SHORT).show();
            clientHome();
        });
        body.addView(save);

        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back);
    }

    private void ensureClientAuth(Runnable afterReady){
        try{
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();
            if(firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                if(clientMode) attachClientRequestsListener();
                afterReady.run();
                return;
            }
            Toast.makeText(this,"Connexion sécurisée en cours…",Toast.LENGTH_SHORT).show();
            firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                    clientUid=firebaseAuth.getCurrentUser().getUid();
                    if(clientMode) attachClientRequestsListener();
                    afterReady.run();
                }else{
                    Toast.makeText(this,"Connexion client à Firebase impossible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
                }
            });
        }catch(Exception e){
            Toast.makeText(this,"Firebase est indisponible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
        }
    }


    private void autoFillWalletName(EditText phone, EditText name, TextView result, Spinner network){
        String p=phone.getText().toString().trim();
        if(normalizePhone(p).length()<8){ name.setText(""); result.setText("🔎 Saisissez le numéro du portefeuille."); return; }
        String net=network.getSelectedItem()==null?"":network.getSelectedItem().toString();
        WalletVerification r=verifyWalletSimulation(p,net);
        if(r.verified){
            name.setText(r.holderName);
            result.setText("✅ NOM AUTOMATIQUE : "+r.holderName+"\nPortefeuille : "+net+" — "+p+"\nSource : "+r.source);
        }else{
            name.setText("");
            result.setText("🔎 Numéro non trouvé dans le registre local.\nEn attente de l'API officielle du réseau pour une identification réelle.");
        }
    }

    void clientTransferPage(){
        base("ENVOYER DE L'ARGENT",BLUE);
        body.addView(tv("💸 TRANSFERT MOBILE MONEY — YOUNGEST'S BUSINESS",19));
        body.addView(tv("Le transfert B2C envoie l'argent depuis la caisse YOUNGEST'S BUSINESS vers le portefeuille Mobile Money du bénéficiaire. Réseaux : M-Pesa, Airtel Money, Orange Money et Afrimoney. Devises : CDF ou USD.",14));
        body.addView(tv("🔐 Sécurité : aucun PIN Mobile Money n'est demandé ni enregistré dans YOUNGEST'S BUSINESS. La clé WonyaPay reste côté serveur sécurisé.",14));

        final String[] networks={"M-Pesa","Airtel Money","Orange Money","Afrimoney"};
        final String[] currencies={"CDF — Franc congolais","USD — Dollar américain"};

        body.addView(tv("📲 RÉSEAU DU BÉNÉFICIAIRE",17));
        Spinner network=new Spinner(this);
        network.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,networks));
        body.addView(network);

        body.addView(tv("📱 NUMÉRO DU BÉNÉFICIAIRE",17));
        EditText beneficiaryPhone=input("Numéro Mobile Money (10 chiffres)",InputType.TYPE_CLASS_PHONE);
        body.addView(beneficiaryPhone);
        body.addView(tv("Le numéro est transmis à WonyaPay comme MobileMoney pour l'action B2C. Aucun PIN n'est demandé.",13));

        body.addView(tv("💰 MONTANT",17));
        Spinner currency=new Spinner(this);
        currency.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,currencies));
        EditText amount=input("Montant à envoyer",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView fee=tv("Frais estimés (2 %) : —",17);
        TextView total=tv("Total estimé à débiter : —",18);
        body.addView(currency); body.addView(amount); body.addView(fee); body.addView(total);
        TextWatcher tw=new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ updateTransferTotal(amount,fee,total,currency); }
            public void afterTextChanged(Editable e){}
        };
        amount.addTextChangedListener(tw);
        currency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ updateTransferTotal(amount,fee,total,currency); }
        });

        body.addView(tv("👤 NOM DU BÉNÉFICIAIRE (FACULTATIF)",17));
        EditText beneficiaryName=input("Nom du bénéficiaire (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        body.addView(beneficiaryName);

        body.addView(tv("📋 MOTIF / DESCRIPTION",17));
        EditText reason=input("Motif du transfert (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.addView(reason);
        body.addView(tv("⚙️ API WonyaPay : POST /payment — Action B2C. La référence de transaction est générée automatiquement côté serveur pour éviter les doublons.",13));

        Button confirm=btn("💸 ENVOYER VIA WONYA PAY",GREEN);
        confirm.setOnClickListener(v->{
            try{
                String bp=normalizePhone(beneficiaryPhone.getText().toString().trim());
                double a=Double.parseDouble(amount.getText().toString().trim());
                String net=network.getSelectedItem().toString();
                String cur=currency.getSelectedItemPosition()==1?"USD":"CDF";
                if(bp.length()!=10 || !bp.matches("[0-9]{10}") || a<=0) throw new Exception();
                double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
                Transfer t=new Transfer(cur,"YOUNGEST'S BUSINESS","","CAISSE WONYA PAY",beneficiaryName.getText().toString().trim(),bp,net,a,f,reason.getText().toString().trim());
                t.clientInitiated=true;
                t.requesterUid=clientUid==null?"":clientUid;
                t.apiStatus="PREPARATION";
                transfersList.add(t); saveData();
                submitWonyaPayTransfer(t, ()->clientTransferReceipt(t));
            }catch(Exception e){ Toast.makeText(this,"Vérifiez le réseau, le numéro à 10 chiffres et le montant.",Toast.LENGTH_LONG).show(); }
        });
        body.addView(confirm,new LinearLayout.LayoutParams(-1,dp(60)));

        Button history=btn("📜 MES TRANSFERTS",BLUE); history.setOnClickListener(v->clientTransferHistoryPage());
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(54)));
        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    private void submitWonyaPayTransfer(Transfer t, Runnable after){
        t.apiStatus="ENVOI_VERS_WONYAPAY";
        saveData();
        Map<String,Object> data=new HashMap<>();
        data.put("network",t.beneficiaryNetwork);
        data.put("mobileMoney",normalizePhone(t.beneficiaryPhone));
        data.put("amount",t.amount);
        data.put("currency",t.currency);
        data.put("reason",t.reason.isEmpty()?"Transfert YOUNGEST'S BUSINESS":t.reason);
        data.put("clientInitiated",t.clientInitiated);
        FirebaseFunctions.getInstance().getHttpsCallable("createWonyaPayTransfer").call(data)
            .addOnSuccessListener(result->{
                try{
                    Map<?,?> rootData=(Map<?,?>)result.getData();
                    boolean success=Boolean.TRUE.equals(rootData.get("success"));
                    Object d=rootData.get("data");
                    Map<?,?> out=d instanceof Map?(Map<?,?>)d:Collections.emptyMap();
                    Object statusValue=out.get("status");
                    t.apiStatus=statusValue==null?"pending":String.valueOf(statusValue);
                    Object txValue=out.get("refTransa");
                    if(txValue==null) txValue=out.get("transactionId");
                    t.providerReference=txValue==null?"":String.valueOf(txValue);
                    Object apiFee=out.get("frais");
                    if(apiFee instanceof Number) t.fees=((Number)apiFee).doubleValue();
                    if(success && isTerminalTransferStatus(t.apiStatus)) t.status="TERMINE";
                    else if(success) t.status="EN_COURS";
                    else t.status="ANNULE";
                    saveData();
                    Toast.makeText(this, success?"Transfert envoyé à WonyaPay : "+transferStatusLabel(t.status):"WonyaPay a refusé le transfert.",Toast.LENGTH_LONG).show();
                    after.run();
                }catch(Exception e){
                    t.status="EN_COURS"; t.apiStatus="REPONSE_API_INCOMPRISE"; saveData();
                    Toast.makeText(this,"Réponse WonyaPay reçue mais non interprétée. Vérifiez l'historique.",Toast.LENGTH_LONG).show();
                    after.run();
                }
            })
            .addOnFailureListener(e->{
                t.status="ANNULE"; t.apiStatus="ERREUR_API: "+(e.getMessage()==null?"inconnue":e.getMessage()); saveData();
                Toast.makeText(this,"Échec de l'envoi WonyaPay. Aucun PIN n'a été demandé.",Toast.LENGTH_LONG).show();
                after.run();
            });
    }

    private boolean isTerminalTransferStatus(String s){
        if(s==null) return false;
        String x=s.toLowerCase(Locale.US);
        return x.contains("success") || x.contains("complete") || x.contains("completed") || x.contains("successful") || x.contains("paid") || x.equals("done") || x.equals("success");
    }

    private void refreshWonyaPayStatus(Transfer t){
        if(t.providerReference==null || t.providerReference.trim().isEmpty()){
            Toast.makeText(this,"Référence WonyaPay indisponible.",Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this,"Vérification du statut WonyaPay…",Toast.LENGTH_SHORT).show();
        Map<String,Object> data=new HashMap<>();
        data.put("refTransa",t.providerReference);
        FirebaseFunctions.getInstance().getHttpsCallable("getWonyaPayStatus").call(data)
            .addOnSuccessListener(result->{
                try{
                    Map<?,?> rootData=(Map<?,?>)result.getData();
                    Object d=rootData.get("data");
                    Map<?,?> out=d instanceof Map?(Map<?,?>)d:Collections.emptyMap();
                    Object statusValue=out.get("status");
                    t.apiStatus=statusValue==null?t.apiStatus:String.valueOf(statusValue);
                    Object apiFee=out.get("frais");
                    if(apiFee instanceof Number) t.fees=((Number)apiFee).doubleValue();
                    if(isTerminalTransferStatus(t.apiStatus)) t.status="TERMINE";
                    saveData();
                    Toast.makeText(this,"Statut : "+transferStatusLabel(t.status),Toast.LENGTH_LONG).show();
                    showTransferReceipt(t);
                }catch(Exception e){ Toast.makeText(this,"Réponse de statut non reconnue.",Toast.LENGTH_LONG).show(); }
            })
            .addOnFailureListener(e->Toast.makeText(this,"Impossible de vérifier le statut : "+(e.getMessage()==null?"erreur":e.getMessage()),Toast.LENGTH_LONG).show());
    }

    void clientTransferHistoryPage(){
        base("MES TRANSFERTS",BLUE);
        String myPhone=normalizePhone(savedClientPhone());
        body.addView(tv("📜 HISTORIQUE DES TRANSFERTS INITIÉS DEPUIS VOTRE ESPACE CLIENT",19));
        int count=0;
        for(int i=transfersList.size()-1;i>=0;i--){
            Transfer t=transfersList.get(i);
            if(!t.clientInitiated || (clientUid!=null && !clientUid.isEmpty() && !clientUid.equals(t.requesterUid))) continue;
            count++;
            body.addView(tv(t.id+"  •  "+transferStatusLabel(t.status)+"\n"+t.senderNetwork+" — "+t.senderPhone+"\n→ "+t.beneficiaryNetwork+" — "+t.beneficiaryPhone+"\nMontant : "+money(t.amount,t.currency)+"\nFrais : "+money(t.fees,t.currency)+"\nTotal : "+money(t.total(),t.currency)+"\nAPI : "+t.apiStatus,14));
        }
        if(count==0) body.addView(tv("Aucun transfert client enregistré pour ce portefeuille.",15));
        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back);
    }

    void clientTransferReceipt(Transfer t){ showTransferReceipt(t); }


    void clientRequestForm(){
        base("DEMANDE DE PRÊT",GREEN);
        body.addView(tv("Remplissez votre demande",19));
        EditText n=input("Nom complet",InputType.TYPE_CLASS_TEXT);
        EditText ph=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        EditText a=input("Montant souhaité (FBu)",InputType.TYPE_CLASS_NUMBER);
        EditText d=input("Durée souhaitée (jours)",InputType.TYPE_CLASS_NUMBER);
        EditText r=input("Motif de la demande",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        n.setText(savedClientName());
        ph.setText(savedClientPhone());
        body.addView(n); body.addView(ph); body.addView(a); body.addView(d); body.addView(r);

        Button send=btn("ENVOYER LA DEMANDE",GREEN);
        send.setOnClickListener(v->{
            try{
                String name=n.getText().toString().trim(), phone=ph.getText().toString().trim(), reason=r.getText().toString().trim();
                double amount=Double.parseDouble(a.getText().toString().trim());
                int days=Integer.parseInt(d.getText().toString().trim());
                if(name.isEmpty()||phone.isEmpty()||amount<=0||days<=0||reason.isEmpty()) throw new Exception();

                final double requestAmount=amount;
                final int requestDays=days;
                final String requestName=name, requestPhone=phone, requestReason=reason;

                ensureClientAuth(()->{
                    if(clientUid==null||clientUid.isEmpty()){
                        Toast.makeText(this,"Connexion client à Firebase impossible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs.edit().putString(clientPref("name"),requestName).putString(clientPref("phone"),requestPhone).apply();
                    LoanRequest q=new LoanRequest(clientUid,requestName,requestPhone,requestAmount,requestDays,requestReason);
                    q.clientId=clientUid;
                    loanRequests.add(q);
                    saveData();
                    uploadLoanRequest(q);
                    localNotification("Demande de prêt", "Votre demande a été envoyée au bureau pour étude.");
                    Toast.makeText(this,"Demande envoyée au bureau.",Toast.LENGTH_LONG).show();
                    clientRequestsPage();
                });
            }catch(Exception e){
                Toast.makeText(this,"Veuillez remplir correctement les champs : nom, téléphone, montant, durée et motif.",Toast.LENGTH_LONG).show();
            }
        });
        body.addView(send);

        Button my=btn("📋 VOIR MES DEMANDES",NAVY);
        my.setOnClickListener(v->clientRequestsPage());
        body.addView(my);

        Button profile=btn("👤 MODIFIER MON PROFIL",NAVY);
        profile.setOnClickListener(v->clientProfilePage());
        body.addView(profile);

        Button back=btn("← ESPACE CLIENT",NAVY);
        back.setOnClickListener(v->clientHome());
        body.addView(back);
    }

    void clientRequestsPage(){
        base("MES DEMANDES",GREEN);
        if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();

        body.addView(tv("📋 SUIVI DE VOS DEMANDES",19));
        body.addView(tv("Retrouvez ici toutes les demandes envoyées depuis ce compte client. Appuyez sur une demande pour consulter ses détails et son statut.",15));
        int totalRequests=0, pendingRequests=0, approvedRequests=0, refusedRequests=0;
        for(LoanRequest q:loanRequests){
            if(clientUid!=null && clientUid.equals(q.requesterUid)){
                totalRequests++;
                if("EN_ATTENTE".equals(q.status)) pendingRequests++;
                else if("APPROUVEE".equals(q.status)) approvedRequests++;
                else if("REFUSEE".equals(q.status)) refusedRequests++;
            }
        }
        body.addView(tv("📊 Total : "+totalRequests+"   🟡 En attente : "+pendingRequests+"   🟢 Approuvées : "+approvedRequests+"   🔴 Refusées : "+refusedRequests,14));

        boolean found=false;
        for(LoanRequest q:loanRequests){
            if(clientUid!=null && clientUid.equals(q.requesterUid)){
                found=true;
                String statusLabel=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE");
                int statusColor=q.status.equals("APPROUVEE")?GREEN:(q.status.equals("REFUSEE")?RED:NAVY);
                String subtitle=fmt(q.amount)+" FBu • "+q.days+" jours\n"+date(q.date);
                Button b=btn(statusLabel+"\n"+subtitle,statusColor);
                b.setOnClickListener(v->clientRequestDetails(q));
                body.addView(b,new LinearLayout.LayoutParams(-1,dp(92)));
            }
        }

        if(!found){
            body.addView(tv("Aucune demande enregistrée pour ce compte client.\n\nAppuyez sur « DEMANDER UN PRÊT » pour envoyer votre première demande au bureau.",16));
        }

        Button refresh=btn("🔄 ACTUALISER MES DEMANDES",NAVY);
        refresh.setOnClickListener(v->{
            if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();
            clientRequestsPage();
        });
        body.addView(refresh);

        Button newRequest=btn("📝 NOUVELLE DEMANDE DE PRÊT",GREEN);
        newRequest.setOnClickListener(v->clientRequestForm());
        body.addView(newRequest);

        Button back=btn("← ESPACE CLIENT",NAVY);
        back.setOnClickListener(v->clientHome());
        body.addView(back);
    }

    void clientRequestDetails(LoanRequest q){
        String status=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE");
        StringBuilder details=new StringBuilder();
        details.append("Statut : ").append(status)
            .append("\n\nMontant demandé : ").append(fmt(q.amount)).append(" FBu")
            .append("\nDurée souhaitée : ").append(q.days).append(" jours")
            .append("\nDate de la demande : ").append(date(q.date))
            .append("\nDernière mise à jour : ").append(date(q.updatedAt))
            .append("\nTéléphone : ").append(q.phone.isEmpty()?"Non renseigné":q.phone)
            .append("\nMotif : ").append(q.reason.isEmpty()?"Non précisé":q.reason);

        if("APPROUVEE".equals(q.status)){
            Loan approved=null;
            for(Loan l:loans){
                if(l.c!=null && q.clientId.equals(l.c.id) && Math.abs(l.principal-q.amount)<0.01 && l.days==q.days){ approved=l; break; }
            }
            if(approved!=null){
                double paid=approved.paid(payments), balance=approved.balance(payments);
                details.append("\n\n💰 MONTANT ACCORDÉ : ").append(fmt(approved.principal)).append(" FBu")
                    .append("\n📈 INTÉRÊT : ").append(fmt(approved.interest())).append(" FBu")
                    .append("\n💵 TOTAL À REMBOURSER : ").append(fmt(approved.total())).append(" FBu")
                    .append("\n📅 ÉCHÉANCE : ").append(date(approved.dueDate()))
                    .append("\n💳 DÉJÀ PAYÉ : ").append(fmt(paid)).append(" FBu")
                    .append("\n⏳ SOLDE RESTANT : ").append(fmt(balance)).append(" FBu");
            }
        }

        new AlertDialog.Builder(this)
            .setTitle("📋 DÉTAIL DE LA DEMANDE")
            .setMessage(details.toString())
            .setPositiveButton("FERMER",null)
            .show();
    }

    void dashboard(){
        base("TABLEAU DE BORD",NAVY);
        double capital=0,intt=0,paid=0; int late=0,active=0;
        for(Loan l:loans){ capital+=l.principal; intt+=l.interest(); paid+=l.paid(payments); if(l.balance(payments)>0){active++; if(System.currentTimeMillis()>l.dueDate())late++;} }
        body.addView(tv("SITUATION RÉELLE DE L'ACTIVITÉ",19));
        body.addView(tv("👥 Clients : "+clients.size()+"\n📋 Prêts : "+loans.size()+"\n🟢 Prêts actifs : "+active+"\n🔴 Échéances dépassées : "+late+"\n💰 Capital prêté : "+fmt(capital)+" FBu\n📈 Intérêts prévus : "+fmt(intt)+" FBu\n💵 Total à récupérer : "+fmt(capital+intt)+" FBu\n🔄 Total encaissé : "+fmt(paid)+" FBu\n⏳ Solde à récupérer : "+fmt(capital+intt-paid)+" FBu",17));
        int pendingRequests=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingRequests++;
        body.addView(tv("📥 DEMANDES DE PRÊT CLIENT\n🟡 En attente : "+pendingRequests,17));
        Button requests=btn("📥 OUVRIR LES DEMANDES CLIENTS",GREEN); requests.setOnClickListener(v->bureauRequestsPage()); body.addView(requests,new LinearLayout.LayoutParams(-1,dp(54)));
        Button journal=btn("📋 JOURNAL DES PRÊTS",NAVY); journal.setOnClickListener(v->loanJournal()); body.addView(journal);
    }

    void loanJournal(){
        base("JOURNAL DES PRÊTS",NAVY); body.addView(tv("Historique des prêts",19));
        if(loans.isEmpty()){body.addView(tv("Aucun prêt enregistré.",16)); return;}
        for(Loan l:loans){
            double paid=l.paid(payments), bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(l.c.name+"\n"+fmt(l.principal)+" FBu • Total "+fmt(l.total())+" FBu\n"+status+" • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(88)));
        }
    }

    void loanDetails(Loan l){
        base("DÉTAIL DU PRÊT",RED);
        double paid=l.paid(payments), bal=l.balance(payments);
        body.addView(tv("CLIENT\n"+l.c.name+(l.c.phone.isEmpty()?"":"\n"+l.c.phone),17));
        body.addView(tv("MONTANT : "+fmt(l.principal)+" FBu\nTAUX : "+fmt(l.rate)+" %\nDURÉE : "+l.days+" jours\nINTÉRÊT : "+fmt(l.interest())+" FBu\nTOTAL : "+fmt(l.total())+" FBu\nDÉJÀ PAYÉ : "+fmt(paid)+" FBu\nSOLDE : "+fmt(bal)+" FBu\nÉCHÉANCE : "+date(l.dueDate()),17));
        Button p=btn("💵 ENREGISTRER UN REMBOURSEMENT",PURPLE); p.setOnClickListener(v->paymentForm(l)); body.addView(p);
    }

    void loanForm(){ loanForm(null); }

    void loanForm(Client preselected){
        base("NOUVEAU PRÊT",RED); body.addView(tv("Enregistrer un prêt",19));
        Spinner sp=new Spinner(this); ArrayList<String> ns=new ArrayList<>(); int selected=-1;
        for(int i=0;i<clients.size();i++){ Client c=clients.get(i); ns.add(c.name); if(c==preselected) selected=i; }
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ns));
        if(selected>=0) sp.setSelection(selected);
        body.addView(sp);
        EditText amt=input("Montant prêté (FBu)",InputType.TYPE_CLASS_NUMBER), rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL), days=input("Durée en jours",InputType.TYPE_CLASS_NUMBER);
        body.addView(amt); body.addView(rate); body.addView(days); TextView calc=tv("Intérêt : —\nTotal à récupérer : —",16); body.addView(calc);
        TextWatcher w=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){calculate(amt,rate,calc);} public void afterTextChanged(Editable e){}};
        amt.addTextChangedListener(w); rate.addTextChangedListener(w);
        Button save=btn("ENREGISTRER LE PRÊT",RED); save.setOnClickListener(v->{
            try{ if(clients.isEmpty())throw new Exception(); double a=Double.parseDouble(amt.getText().toString()),r=Double.parseDouble(rate.getText().toString()); int d=Integer.parseInt(days.getText().toString());
                if(a<=0||r<0||d<=0)throw new Exception(); Loan l=new Loan(clients.get(sp.getSelectedItemPosition()),a,r,d); loans.add(l); saveData(); uploadLoan(l); Toast.makeText(this,"Prêt enregistré avec succès",Toast.LENGTH_LONG).show(); loanJournal();
            }catch(Exception e){Toast.makeText(this,"Veuillez remplir correctement les champs",Toast.LENGTH_SHORT).show();}
        }); body.addView(save);
    }

    EditText input(String hint,int type){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); return e; }
    void calculate(EditText a,EditText r,TextView out){ try{double x=Double.parseDouble(a.getText().toString()),y=Double.parseDouble(r.getText().toString()); out.setText("Intérêt : "+fmt(x*y/100)+" FBu\nTotal à récupérer : "+fmt(x+x*y/100)+" FBu");}catch(Exception ignored){out.setText("Intérêt : —\nTotal à récupérer : —");} }

    void clientsPage(){
        base("CLIENTS",NAVY); body.addView(tv("CLIENTS ENREGISTRÉS : "+clients.size(),19));
        for(Client c:clients){ Button b=btn("👤 "+c.name+(c.phone.isEmpty()?"":" — "+c.phone),NAVY); b.setOnClickListener(v->clientDetails(c)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(56))); }
        Button add=btn("＋ AJOUTER UN CLIENT",NAVY); add.setOnClickListener(v->addClient()); body.addView(add);
    }

    void clientDetails(Client c){
        base("FICHE CLIENT",NAVY); body.addView(tv("👤 "+c.name+"\n📱 "+(c.phone.isEmpty()?"Non renseigné":c.phone),19));
        int n=0; double total=0,paid=0; for(Loan l:loans)if(l.c==c){n++;total+=l.total();paid+=l.paid(payments);}
        body.addView(tv("Prêts : "+n+"\nTotal à récupérer : "+fmt(total)+" FBu\nTotal payé : "+fmt(paid)+" FBu\nSolde : "+fmt(total-paid)+" FBu",17));
        Button addLoan=btn("＋ AJOUTER UN PRÊT À CE CLIENT",RED); addLoan.setOnClickListener(v->loanForm(c)); body.addView(addLoan);
        body.addView(tv("HISTORIQUE DES PRÊTS",18));
        boolean found=false;
        for(Loan l:loans) if(l.c==c){
            found=true; double bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(fmt(l.principal)+" FBu • "+status+"\nTotal "+fmt(l.total())+" FBu • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(82)));
        }
        if(!found) body.addView(tv("Aucun prêt pour ce client.",15));
    }

    void addClient(){
        final EditText n=input("Nom et post-nom",InputType.TYPE_CLASS_TEXT), p=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("Nouveau client").setView(box).setPositiveButton("ENREGISTRER",(d,w)->{if(n.getText().length()>0){Client c=new Client(n.getText().toString().trim(),p.getText().toString().trim()); clients.add(c); saveData(); uploadClient(c); clientsPage();}}).setNegativeButton("ANNULER",null).show();
    }

    void paymentPage(){
        base("PAIEMENT",PURPLE);
        body.addView(tv("💳 ENREGISTRER UN PAIEMENT",19));
        body.addView(tv("Sélectionnez le prêt concerné puis saisissez le montant réellement reçu. Le paiement sera enregistré localement et synchronisé avec Firebase lorsqu'une connexion est disponible.",15));
        boolean found=false;
        for(Loan l:loans){
            double bal=l.balance(payments);
            if(bal>0){
                found=true;
                Button b=btn("💳 "+l.c.name+"\nSolde : "+fmt(bal)+" FBu",PURPLE);
                b.setOnClickListener(v->paymentForm(l));
                body.addView(b,new LinearLayout.LayoutParams(-1,dp(72)));
            }
        }
        if(!found) body.addView(tv("Aucun solde à payer.",16));
    }

    void repay(){
        base("REMBOURSEMENTS",PURPLE); body.addView(tv("Choisissez un prêt puis enregistrez le paiement",18));
        for(Loan l:loans){ double bal=l.balance(payments); if(bal>0){ Button b=btn(l.c.name+" — Solde "+fmt(bal)+" FBu",PURPLE); b.setOnClickListener(v->paymentForm(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(62))); } }
    }

    void paymentForm(Loan l){
        EditText a=input("Montant du paiement (FBu)",InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("💳 Paiement — "+l.c.name).setView(a).setPositiveButton("ENCAISSER",(d,w)->{
            try{double x=Double.parseDouble(a.getText().toString()); if(x<=0||x>l.balance(payments))throw new Exception(); Payment p=new Payment(l,x); payments.add(p); saveData(); uploadPayment(p); Toast.makeText(this,"Remboursement enregistré",Toast.LENGTH_SHORT).show(); loanDetails(l);}
            catch(Exception e){Toast.makeText(this,"Montant invalide",Toast.LENGTH_SHORT).show();}
        }).setNegativeButton("ANNULER",null).show();
    }

    void adminDash(){
        base("ADMINISTRATION",NAVY);
        body.addView(tv("🔐 ESPACE ADMINISTRATEUR",20));
        body.addView(tv("Accès réservé à la gestion interne de YOUNGEST’S BUSINESS.",16));
        Button d=btn("📊 TABLEAU DE BORD",NAVY); d.setOnClickListener(v->dashboard()); body.addView(d);
        Button c=btn("👥 GESTION DES CLIENTS",GOLD); c.setOnClickListener(v->clientsPage()); body.addView(c);
        Button l=btn("💰 GESTION DES PRÊTS",RED); l.setOnClickListener(v->loanJournal()); body.addView(l);
        Button r=btn("💵 REMBOURSEMENTS",PURPLE); r.setOnClickListener(v->repay()); body.addView(r);
        Button requests=btn("📥 DEMANDES DE PRÊTS CLIENTS",GREEN); requests.setOnClickListener(v->bureauRequestsPage()); body.addView(requests);
        Button backup=btn("💾 SAUVEGARDER LES DONNÉES",GREEN); backup.setOnClickListener(v->exportData()); body.addView(backup);
        Button restore=btn("📥 RESTAURER LES DONNÉES",BLUE); restore.setOnClickListener(v->confirmRestore()); body.addView(restore);
        Button out=btn("🚪 SE DÉCONNECTER",BLUE); out.setOnClickListener(v->{adminSession=false; home();}); body.addView(out);
    }

    void bureauRequestsPage(){
        base("DEMANDES CLIENTS",GREEN);
        startBureauCloudSync();
        int pendingCount=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingCount++;
        body.addView(tv("📥 Demandes reçues\n🟡 En attente : "+pendingCount+"\n\nAppuyez sur une demande pour voir les détails et la valider ou la refuser.",16));
        boolean found=false;
        for(LoanRequest q:loanRequests){ found=true; String status=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE"); Button b=btn(status+"\n"+q.name+" • "+fmt(q.amount)+" FBu\n"+q.days+" jours • "+(q.reason.isEmpty()?"Motif non précisé":q.reason), q.status.equals("APPROUVEE")?GREEN:(q.status.equals("REFUSEE")?RED:NAVY)); b.setOnClickListener(v->reviewLoanRequest(q)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(100))); }
        if(!found) body.addView(tv("Aucune demande client pour le moment.",16));
        Button back=btn("← ADMINISTRATION",NAVY); back.setOnClickListener(v->adminDash()); body.addView(back);
    }

    void reviewLoanRequest(LoanRequest q){
        String details="Client : "+q.name+"\nTéléphone : "+q.phone+"\nMontant : "+fmt(q.amount)+" FBu\nDurée : "+q.days+" jours\nMotif : "+(q.reason.isEmpty()?"Non précisé":q.reason)+"\nStatut : "+q.status;
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("📥 Demande de prêt").setMessage(details);
        if("EN_ATTENTE".equals(q.status)){ b.setPositiveButton("APPROUVER",(d,w)->approveLoanRequest(q)); b.setNegativeButton("REFUSER",(d,w)->refuseLoanRequest(q)); } else b.setPositiveButton("FERMER",null);
        b.show();
    }

    private void refuseLoanRequest(LoanRequest q){ q.status="REFUSEE"; q.updatedAt=System.currentTimeMillis(); saveData(); uploadLoanRequest(q); localNotification("Demande refusée", "La demande de "+q.name+" a été refusée."); Toast.makeText(this,"Demande refusée.",Toast.LENGTH_LONG).show(); bureauRequestsPage(); }

    private void approveLoanRequest(LoanRequest q){
        final EditText rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        rate.setText("30");
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(rate);
        new AlertDialog.Builder(this).setTitle("✅ Approuver le prêt").setMessage("Définissez le taux avant de créer le prêt. Durée demandée : "+q.days+" jours.").setView(box).setPositiveButton("CRÉER LE PRÊT",(d,w)->{
            try{ double r=Double.parseDouble(rate.getText().toString()); if(r<0) throw new Exception(); Client c=findClient(q.clientId); if(c==null){ c=new Client(q.clientId,q.name,q.phone); clients.add(c); uploadClient(c); } Loan l=new Loan(c,q.amount,r,q.days); loans.add(l); q.status="APPROUVEE"; q.updatedAt=System.currentTimeMillis(); saveData(); uploadLoan(l); uploadLoanRequest(q); localNotification("Prêt approuvé", "Le prêt de "+q.name+" a été créé avec succès."); Toast.makeText(this,"Demande approuvée et prêt créé.",Toast.LENGTH_LONG).show(); bureauRequestsPage(); }catch(Exception e){ Toast.makeText(this,"Taux invalide.",Toast.LENGTH_LONG).show(); }
        }).setNegativeButton("ANNULER",null).show();
    }

    private void exportData(){
        try{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"youngest_business_sauvegarde.json"); startActivityForResult(i,9001);
        }catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void confirmRestore(){
        new AlertDialog.Builder(this)
            .setTitle("📥 Restaurer les données ?")
            .setMessage("La restauration remplacera les clients, prêts et remboursements actuellement enregistrés sur cet appareil. Continuez uniquement avec une sauvegarde fiable.")
            .setPositiveButton("CHOISIR LA SAUVEGARDE",(d,w)->{
                try{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,9002); }
                catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir le sélecteur de fichier.",Toast.LENGTH_LONG).show();}
            })
            .setNegativeButton("ANNULER",null).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if(requestCode==9001) writeBackup(uri); else if(requestCode==9002) readBackup(uri);
    }

    private String buildBackup(){
        try{
            JSONObject all=new JSONObject(); JSONArray cs=new JSONArray(),ls=new JSONArray(),ps=new JSONArray();
            for(Client c:clients){JSONObject o=new JSONObject();o.put("name",c.name);o.put("phone",c.phone);cs.put(o);}
            for(Loan l:loans){JSONObject o=new JSONObject();o.put("client",clients.indexOf(l.c));o.put("principal",l.principal);o.put("rate",l.rate);o.put("days",l.days);o.put("date",l.date);ls.put(o);}
            for(Payment p:payments){JSONObject o=new JSONObject();o.put("loan",loans.indexOf(p.loan));o.put("amount",p.amount);o.put("date",p.date);ps.put(o);}
            all.put("app","YOUNGEST’S BUSINESS"); all.put("backup_version",1); all.put("created_at",System.currentTimeMillis()); all.put("clients",cs); all.put("loans",ls); all.put("payments",ps); return all.toString(2);
        }catch(Exception e){return null;}
    }

    private void writeBackup(Uri uri){
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            String raw=buildBackup(); if(raw==null)throw new Exception(); out.write(raw.getBytes("UTF-8")); out.flush(); Toast.makeText(this,"Sauvegarde créée avec succès.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Échec de la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void readBackup(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri)){
            java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) buffer.write(b,0,n);
            JSONObject all=new JSONObject(new String(buffer.toByteArray(),"UTF-8"));
            if(!"YOUNGEST’S BUSINESS".equals(all.optString("app")) && !"YOUNGEST'S BUSINESS".equals(all.optString("app"))) throw new Exception();
            JSONArray cs=all.optJSONArray("clients"),ls=all.optJSONArray("loans"),ps=all.optJSONArray("payments");
            if(cs==null||ls==null||ps==null)throw new Exception();
            ArrayList<Client> newClients=new ArrayList<>(); ArrayList<Loan> newLoans=new ArrayList<>(); ArrayList<Payment> newPayments=new ArrayList<>();
            for(int i=0;i<cs.length();i++){JSONObject o=cs.getJSONObject(i);newClients.add(new Client(o.optString("name"),o.optString("phone")));}
            for(int i=0;i<ls.length();i++){JSONObject o=ls.getJSONObject(i);int ci=o.optInt("client",-1);if(ci<0||ci>=newClients.size())throw new Exception();Loan l=new Loan(newClients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days"));l.date=o.optLong("date",l.date);newLoans.add(l);}
            for(int i=0;i<ps.length();i++){JSONObject o=ps.getJSONObject(i);int li=o.optInt("loan",-1);if(li<0||li>=newLoans.size())throw new Exception();Payment p=new Payment(newLoans.get(li),o.optDouble("amount"));p.date=o.optLong("date",p.date);newPayments.add(p);}
            clients.clear();clients.addAll(newClients);loans.clear();loans.addAll(newLoans);payments.clear();payments.addAll(newPayments);saveData(); uploadAllClients(); uploadAllLoans(); uploadAllPayments(); Toast.makeText(this,"Données restaurées avec succès.",Toast.LENGTH_LONG).show(); adminDash();
        }catch(Exception e){Toast.makeText(this,"Fichier de sauvegarde invalide ou incompatible.",Toast.LENGTH_LONG).show();}
    }

    private void requireAdmin(Runnable action){
        if(adminSession){ action.run(); return; }
        showAdminLogin(action);
    }

    private void showAdminLogin(Runnable after){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20),0,dp(20),0);

        EditText email=input("Email Firebase Admin",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setText(FIREBASE_ADMIN_EMAIL);
        email.setEnabled(false);
        EditText password=input("Mot de passe Firebase",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(email);
        box.addView(password);

        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("🔐 Connexion Bureau / Admin")
            .setMessage("Connectez-vous avec le compte Firebase autorisé à gérer les demandes clients.")
            .setView(box)
            .setPositiveButton("SE CONNECTER",null)
            .setNegativeButton("ANNULER",null)
            .create();

        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String pass=password.getText().toString();
            if(pass.isEmpty()){
                Toast.makeText(this,"Veuillez saisir le mot de passe Firebase.",Toast.LENGTH_SHORT).show();
                return;
            }
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();

            // Si l'application était connectée anonymement, on ferme cette session
            // avant de connecter le compte Bureau avec son vrai UID Firebase.
            firebaseAuth.signOut();
            Toast.makeText(this,"Connexion Firebase du Bureau en cours…",Toast.LENGTH_SHORT).show();
            firebaseAuth.signInWithEmailAndPassword(FIREBASE_ADMIN_EMAIL,pass)
                .addOnCompleteListener(task->{
                    if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                        clientUid=firebaseAuth.getCurrentUser().getUid();
                        adminSession=true;
                        initialCloudRequestsDone=false;
                        initialCloudClientsDone=false;
                        dlg.dismiss();
                        after.run();
                    }else{
                        Toast.makeText(this,"Connexion Firebase refusée. Vérifiez le mot de passe du compte Admin.",Toast.LENGTH_LONG).show();
                    }
                });
        }));
        dlg.show();
    }

    private String hash(String value){
        try{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] out=md.digest(value.getBytes("UTF-8")); StringBuilder sb=new StringBuilder(); for(byte q:out) sb.append(String.format(Locale.US,"%02x",q)); return sb.toString(); }catch(Exception e){ return ""; }
    }


    void services(){
        base("SERVICES FINANCIERS",GREEN);
        body.addView(tv("MOBILE MONEY\nRecevez vos paiements directement sur les numéros privés de YOUNGEST’S BUSINESS.",17));
        body.addView(tv("Choisissez le réseau utilisé par le client, puis copiez le numéro et le nom du bénéficiaire.",15));

        mobileReceiver("📱 M-Pesa", "+243 817 447 127", "MUTABESHA MUSHAGALUSA ELISHA");
        mobileReceiver("📱 Airtel Money", "+243 994 565 534", "ELISHA MUTABESHA");
        mobileReceiver("📱 Orange Money", "+243 840 890 183", "ELISHA MUTABESHA");
        mobileReceiver("📱 Afrimoney", "+243 907 751 352", "ELISHA MUSHAGALUSA");

        body.addView(tv("ℹ️ Cette version affiche les coordonnées de réception. Le paiement réel reste effectué dans le service Mobile Money de l’opérateur.",14));
    }

    void mobileReceiver(String network, String number, String name){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(8),dp(12),dp(8));
        card.setBackground(bg(GREEN,14));
        TextView title=tv(network,17); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        TextView info=tv("Numéro : "+number+"\nNom : "+name,15); info.setTextColor(Color.WHITE);
        card.addView(title); card.addView(info);
        Button copy=btn("📋 COPIER LE NUMÉRO",NAVY);
        copy.setOnClickListener(v->{
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Numéro "+network, number.replace(" ","")));
            Toast.makeText(this,"Numéro copié : "+number,Toast.LENGTH_SHORT).show();
        });
        card.addView(copy);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(150));
        cp.setMargins(0,dp(5),0,dp(5));
        body.addView(card,cp);
    }

    // WonyaSoft indique actuellement 2 % sur les transactions sortantes en production.
    // Le backend reste la source de vérité pour les frais réellement retournés par WonyaPay.
    static final double TRANSFER_FEE_RATE = 0.02;

    String money(double x, String currency){
        return fmt(x) + ("USD".equals(currency) ? " $" : " FC");
    }

    void transfers(){
        base("TRANSFERT MOBILE MONEY",BLUE);
        body.addView(tv("💸 TRANSFERTS WONYAPAY B2C",19));
        body.addView(tv("Réseaux : M-Pesa • Airtel Money • Orange Money • Afrimoney\nDevises : CDF • USD\nFrais sortants affichés à titre indicatif : 2 %. Le montant/frais réellement retournés par WonyaPay font foi.",14));

        Button b=btn("➕ NOUVEAU TRANSFERT",GREEN); b.setOnClickListener(v->newTransferPage());
        body.addView(b,new LinearLayout.LayoutParams(-1,dp(58)));
        Button in=btn("🟠 EN COURS",GOLD); in.setOnClickListener(v->transferListPage("EN_COURS"));
        Button done=btn("✅ TERMINÉS",GREEN); done.setOnClickListener(v->transferListPage("TERMINE"));
        Button cancelled=btn("❌ ANNULÉS / ÉCHECS",RED); cancelled.setOnClickListener(v->transferListPage("ANNULE"));
        Button history=btn("📜 HISTORIQUE COMPLET",NAVY); history.setOnClickListener(v->transferListPage("HISTORIQUE"));
        body.addView(in,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(done,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(cancelled,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(52)));

        double fc=0, usd=0, feesFc=0, feesUsd=0; int count=0;
        for(Transfer t:transfersList){
            if("TERMINE".equals(t.status)){
                count++;
                if("USD".equals(t.currency)){ usd+=t.amount; feesUsd+=t.fees; }
                else { fc+=t.amount; feesFc+=t.fees; }
            }
        }
        body.addView(tv("📊 RÉSUMÉ DES TRANSFERTS TERMINÉS\nOpérations : "+count+"\nCDF : "+money(fc,"CDF")+" | Frais : "+money(feesFc,"CDF")+"\nUSD : "+money(usd,"USD")+" | Frais : "+money(feesUsd,"USD"),15));
    }

    void newTransferPage(){
        base("NOUVEAU TRANSFERT",BLUE);
        body.addView(tv("💸 TRANSFERT B2C — WONYAPAY",19));
        body.addView(tv("Ce formulaire correspond au format B2C de l'API WonyaPay : réseau/caisse, numéro bénéficiaire, montant, devise, motif. La référence API est générée côté serveur.",14));

        final String[] networks={"M-Pesa","Airtel Money","Orange Money","Afrimoney"};
        final String[] currencies={"CDF — Franc congolais","USD — Dollar américain"};
        body.addView(tv("📲 RÉSEAU DU BÉNÉFICIAIRE",17));
        Spinner network=new Spinner(this);
        network.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,networks));
        body.addView(network);

        body.addView(tv("📱 BÉNÉFICIAIRE",17));
        EditText bp=input("Numéro Mobile Money (10 chiffres)",InputType.TYPE_CLASS_PHONE);
        EditText bn=input("Nom du bénéficiaire (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        body.addView(bp); body.addView(bn);

        body.addView(tv("💰 MONTANT",17));
        Spinner currencySpinner=new Spinner(this);
        currencySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,currencies));
        body.addView(currencySpinner);
        EditText amount=input("Montant à transférer",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView fee=tv("Frais estimés (2 %) : —",17);
        TextView total=tv("Total estimé à débiter : —",18);
        body.addView(amount); body.addView(fee); body.addView(total);
        TextWatcher tw=new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ updateTransferTotal(amount,fee,total,currencySpinner); }
            public void afterTextChanged(Editable e){}
        };
        amount.addTextChangedListener(tw);
        currencySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ updateTransferTotal(amount,fee,total,currencySpinner); }
        });

        EditText reason=input("Motif / description (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.addView(tv("📋 MOTIF",17)); body.addView(reason);
        body.addView(tv("🔐 La clé API WonyaPay n'est pas stockée dans l'APK. L'application appelle une fonction Firebase sécurisée qui porte le token côté serveur.",13));

        Button confirm=btn("💸 ENVOYER VIA WONYA PAY",GREEN);
        confirm.setOnClickListener(v->{
            try{
                String beneficiaryPhone=normalizePhone(bp.getText().toString().trim());
                double a=Double.parseDouble(amount.getText().toString().trim());
                String br=network.getSelectedItem().toString();
                if(beneficiaryPhone.length()!=10 || !beneficiaryPhone.matches("[0-9]{10}") || a<=0) throw new Exception();
                String cur=currencySpinner.getSelectedItemPosition()==1?"USD":"CDF";
                double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
                Transfer t=new Transfer(cur,"YOUNGEST'S BUSINESS","","CAISSE WONYA PAY",bn.getText().toString().trim(),beneficiaryPhone,br,a,f,reason.getText().toString().trim());
                t.clientInitiated=false;
                t.apiStatus="PREPARATION";
                transfersList.add(t); saveData();
                submitWonyaPayTransfer(t, ()->showTransferReceipt(t));
            }catch(Exception e){ Toast.makeText(this,"Veuillez vérifier le numéro à 10 chiffres et le montant.",Toast.LENGTH_LONG).show(); }
        });
        body.addView(confirm,new LinearLayout.LayoutParams(-1,dp(60)));
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    void updateTransferTotal(EditText amount,TextView fee,TextView total,Spinner currencySpinner){
        try{
            double a=Double.parseDouble(amount.getText().toString().trim());
            String cur=currencySpinner.getSelectedItemPosition()==1?"USD":"CDF";
            double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
            fee.setText("Frais estimés (2 %) : "+money(f,cur));
            total.setText("Total estimé à débiter : "+money(a+f,cur));
        }catch(Exception e){ fee.setText("Frais estimés (2 %) : —"); total.setText("Total estimé à débiter : —"); }
    }

    String transferStatusLabel(String s){
        if("TERMINE".equals(s)) return "TERMINÉ";
        if("ANNULE".equals(s)) return "ANNULÉ / ÉCHEC";
        return "EN COURS";
    }

    void transferListPage(String filter){
        String title="HISTORIQUE DES TRANSFERTS";
        if("EN_COURS".equals(filter)) title="TRANSFERTS EN COURS";
        else if("TERMINE".equals(filter)) title="TRANSFERTS TERMINÉS";
        else if("ANNULE".equals(filter)) title="TRANSFERTS ANNULÉS / ÉCHECS";
        base(title,BLUE);
        if(transfersList.isEmpty()) body.addView(tv("Aucun transfert enregistré.",16));
        int shown=0;
        for(int i=transfersList.size()-1;i>=0;i--){
            Transfer t=transfersList.get(i);
            if(!"HISTORIQUE".equals(filter) && !filter.equals(t.status)) continue;
            shown++;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10),dp(8),dp(10),dp(8)); card.setBackground(bg(LIGHT,12));
            TextView head=tv(t.id+"  •  "+transferStatusLabel(t.status),17); head.setTypeface(null,Typeface.BOLD); card.addView(head);
            String beneficiary=t.beneficiaryName.isEmpty()?"Bénéficiaire":t.beneficiaryName;
            card.addView(tv(beneficiary+"\n"+t.beneficiaryNetwork+" — "+t.beneficiaryPhone+"\n"+money(t.amount,t.currency)+"  |  Frais : "+money(t.fees,t.currency)+"\nTotal : "+money(t.total(),t.currency)+"\nAPI : "+t.apiStatus+(t.providerReference.isEmpty()?"":"\nRéf. prestataire : "+t.providerReference)+"\n"+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t.date)),14));
            if(!t.reason.isEmpty()) card.addView(tv("Motif : "+t.reason,13));
            body.addView(card,new LinearLayout.LayoutParams(-1,dp(205)));
        }
        if(shown==0) body.addView(tv("Aucun transfert dans cette rubrique.",16));
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    void showTransferReceipt(Transfer t){
        base("REÇU DU TRANSFERT",GREEN);
        body.addView(tv("📄 TRANSFERT — "+transferStatusLabel(t.status),20));
        String beneficiary=t.beneficiaryName.isEmpty()?"Non renseigné":t.beneficiaryName;
        StringBuilder s=new StringBuilder();
        s.append("Référence YOUNGEST'S BUSINESS : ").append(t.id)
         .append("\nBénéficiaire : ").append(beneficiary)
         .append("\nRéseau : ").append(t.beneficiaryNetwork)
         .append("\nNuméro : ").append(t.beneficiaryPhone)
         .append("\n\nMontant : ").append(money(t.amount,t.currency))
         .append("\nFrais : ").append(money(t.fees,t.currency))
         .append("\nTotal : ").append(money(t.total(),t.currency))
         .append("\n\nStatut : ").append(transferStatusLabel(t.status))
         .append("\nAPI : ").append(t.apiStatus);
        if(!t.providerReference.isEmpty()) s.append("\nRéférence prestataire : ").append(t.providerReference);
        s.append("\nDate : ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t.date)));
        if(!t.reason.isEmpty()) s.append("\nMotif : ").append(t.reason);
        body.addView(tv(s.toString(),15));
        if("EN_COURS".equals(t.status)) {
            body.addView(tv("⏳ La transaction est en attente. Ne relancez pas le même transfert tant que son statut n'est pas connu afin d'éviter un doublon.",14));
            Button check=btn("🔄 VÉRIFIER LE STATUT WONYAPAY",BLUE);
            check.setOnClickListener(v->refreshWonyaPayStatus(t));
            body.addView(check,new LinearLayout.LayoutParams(-1,dp(56)));
        }
        if("TERMINE".equals(t.status)) body.addView(tv("✅ WonyaPay a accepté le transfert. La référence prestataire est conservée dans l'historique.",14));
        Button history=btn("📜 HISTORIQUE",BLUE); history.setOnClickListener(v->transferListPage("HISTORIQUE")); body.addView(history);
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back);
    }

    @Override protected void onDestroy(){
        if(clientsListener!=null) clientsListener.remove();
        if(loansListener!=null) loansListener.remove();
        if(paymentsListener!=null) paymentsListener.remove();
        if(loanRequestsListener!=null) loanRequestsListener.remove();
        super.onDestroy();
    }

    String date(long time){return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date(time));}
    String fmt(double x){return String.format(Locale.US,"%,.0f",x).replace(',',' ');}
}
