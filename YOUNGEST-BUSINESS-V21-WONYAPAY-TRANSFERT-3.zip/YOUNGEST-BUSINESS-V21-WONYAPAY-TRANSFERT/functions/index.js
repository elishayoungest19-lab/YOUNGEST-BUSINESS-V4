const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

const BASE_URL = "https://app-api.wonyasoft.com";

// Un couple Token + RefPartenaire est prévu par réseau/caisse.
// Si plusieurs réseaux utilisent la même caisse, on peut renseigner le même secret.
const SECRETS = {
  "M-Pesa": {
    token: defineSecret("WONYAPAY_TOKEN_MPESA"),
    ref: defineSecret("WONYAPAY_REF_MPESA")
  },
  "Airtel Money": {
    token: defineSecret("WONYAPAY_TOKEN_AIRTEL"),
    ref: defineSecret("WONYAPAY_REF_AIRTEL")
  },
  "Orange Money": {
    token: defineSecret("WONYAPAY_TOKEN_ORANGE"),
    ref: defineSecret("WONYAPAY_REF_ORANGE")
  },
  "Afrimoney": {
    token: defineSecret("WONYAPAY_TOKEN_AFRIMONEY"),
    ref: defineSecret("WONYAPAY_REF_AFRIMONEY")
  }
};

const allowedCurrencies = new Set(["CDF", "USD"]);
const allowedNetworks = new Set(Object.keys(SECRETS));

function normalizePhone(value) {
  let n = String(value || "").replace(/\D/g, "");
  if (n.startsWith("243") && n.length === 12) n = "0" + n.slice(3);
  return n;
}

function makeRef() {
  const now = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `YB${now}${random}`.slice(0, 20);
}

function jsonData(response) {
  return response.json().catch(() => ({}));
}

function normalizeApiResult(body) {
  const data = body && body.data && typeof body.data === "object" ? body.data : {};
  return {
    success: body && body.success === true,
    message: body && body.message ? String(body.message) : "",
    data: {
      refTransa: data.refTransa || "",
      transactionId: data.transactionId || "",
      montant: data.montant,
      devise: data.devise,
      frais: data.frais,
      commission: data.commission,
      network: data.network || "",
      action: data.action || "B2C",
      status: data.status || "pending"
    }
  };
}

exports.createWonyaPayTransfer = onCall(
  { secrets: Object.values(SECRETS).flatMap(x => [x.token, x.ref]) },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");

    const input = request.data || {};
    const network = String(input.network || "").trim();
    const currency = String(input.currency || "").trim().toUpperCase();
    const mobileMoney = normalizePhone(input.mobileMoney);
    const amount = Number(input.amount);
    const reason = String(input.reason || "Transfert YOUNGEST'S BUSINESS").trim().slice(0, 120);

    if (!allowedNetworks.has(network)) throw new HttpsError("invalid-argument", "Réseau Mobile Money non supporté.");
    if (!allowedCurrencies.has(currency)) throw new HttpsError("invalid-argument", "Devise invalide. Utilisez CDF ou USD.");
    if (!/^\d{10}$/.test(mobileMoney)) throw new HttpsError("invalid-argument", "Le numéro Mobile Money doit contenir 10 chiffres.");
    if (!Number.isFinite(amount) || amount <= 0) throw new HttpsError("invalid-argument", "Montant invalide.");

    const cfg = SECRETS[network];
    const token = cfg.token.value();
    const refPartenaire = cfg.ref.value();
    if (!token || !refPartenaire) {
      throw new HttpsError("failed-precondition", `Configuration WonyaPay absente pour ${network}.`);
    }

    const refTransa = makeRef();
    const payload = {
      RefPartenaire: refPartenaire,
      RefTransa: refTransa,
      Montant: amount,
      Devise: currency,
      Action: "B2C",
      MobileMoney: mobileMoney,
      Motif: reason
    };

    const response = await fetch(`${BASE_URL}/payment`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    const body = await jsonData(response);
    const result = normalizeApiResult(body);

    await db.collection("yb_transfers").doc(refTransa).set({
      refTransa,
      uid: request.auth.uid,
      network,
      mobileMoney,
      amount,
      currency,
      action: "B2C",
      reason,
      success: result.success,
      httpStatus: response.status,
      providerTransactionId: result.data.transactionId,
      providerStatus: result.data.status,
      fee: result.data.frais ?? null,
      commission: result.data.commission ?? null,
      message: result.message,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    if (!response.ok || !result.success) {
      return {
        success: false,
        message: result.message || `WonyaPay a répondu avec le code ${response.status}.`,
        data: { ...result.data, refTransa }
      };
    }

    return {
      success: true,
      message: result.message || "Transaction B2C initiée avec succès",
      data: { ...result.data, refTransa }
    };
  }
);

exports.getWonyaPayStatus = onCall(
  { secrets: Object.values(SECRETS).flatMap(x => [x.token, x.ref]) },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Connexion Firebase requise.");
    const refTransa = String((request.data || {}).refTransa || "").trim();
    if (!refTransa) throw new HttpsError("invalid-argument", "Référence de transaction manquante.");

    const snap = await db.collection("yb_transfers").doc(refTransa).get();
    if (!snap.exists) throw new HttpsError("not-found", "Transaction introuvable.");
    const saved = snap.data();
    const isAdmin = request.auth.uid === "StxrZBDeUodj7YVPmXRA2AbWcUF2";
    if (saved.uid !== request.auth.uid && !isAdmin) throw new HttpsError("permission-denied", "Accès refusé.");

    const cfg = SECRETS[saved.network];
    if (!cfg) throw new HttpsError("failed-precondition", "Réseau de la transaction inconnu.");
    const token = cfg.token.value();
    if (!token) throw new HttpsError("failed-precondition", "Token WonyaPay absent.");

    const response = await fetch(`${BASE_URL}/transaction-status/status/${encodeURIComponent(refTransa)}`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const body = await jsonData(response);
    const result = normalizeApiResult(body);

    await snap.ref.update({
      providerStatus: result.data.status,
      providerTransactionId: result.data.transactionId || saved.providerTransactionId || "",
      fee: result.data.frais ?? saved.fee ?? null,
      commission: result.data.commission ?? saved.commission ?? null,
      message: result.message || saved.message || "",
      httpStatus: response.status,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    return { success: response.ok && result.success, message: result.message, data: result.data };
  }
);
