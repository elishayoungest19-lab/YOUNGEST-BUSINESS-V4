# YOUNGEST'S BUSINESS — V21 TRANSFERT WONYAPAY B2C

## Objectif
Cette version reconstruit **uniquement le module TRANSFERT** à partir de la documentation WonyaPay fournie par le propriétaire du compte API.

Les autres modules de YOUNGEST'S BUSINESS (Prêts, Mobile Money, Remboursements, Clients, Administration, etc.) ne sont pas redessinés par cette modification.

## Flux retenu
L'application utilise le mode **B2C (Business → bénéficiaire)** de WonyaPay :

`YOUNGEST'S BUSINESS → Firebase Functions sécurisé → https://app-api.wonyasoft.com/payment → Mobile Money bénéficiaire`

### Réseaux
- M-Pesa
- Airtel Money
- Orange Money
- Afrimoney

### Devises
- CDF
- USD

### Champs envoyés à WonyaPay
- `RefPartenaire`
- `RefTransa`
- `Montant`
- `Devise`
- `Action: B2C`
- `MobileMoney`
- `Motif`

La référence `RefTransa` est générée côté serveur afin d'éviter les doublons.

## Sécurité
Le token WonyaPay **n'est pas inclus dans l'APK**. Il doit être stocké comme secret Firebase Functions.

Secrets prévus :
- `WONYAPAY_TOKEN_MPESA`
- `WONYAPAY_REF_MPESA`
- `WONYAPAY_TOKEN_AIRTEL`
- `WONYAPAY_REF_AIRTEL`
- `WONYAPAY_TOKEN_ORANGE`
- `WONYAPAY_REF_ORANGE`
- `WONYAPAY_TOKEN_AFRIMONEY`
- `WONYAPAY_REF_AFRIMONEY`

Si plusieurs réseaux utilisent la même caisse WonyaPay, le même token/référence peut être configuré pour les réseaux concernés.

## Déploiement du backend
Depuis le dossier racine du projet :

```bash
firebase login
firebase use youngestsbusiness
firebase functions:secrets:set WONYAPAY_TOKEN_MPESA
firebase functions:secrets:set WONYAPAY_REF_MPESA
firebase functions:secrets:set WONYAPAY_TOKEN_AIRTEL
firebase functions:secrets:set WONYAPAY_REF_AIRTEL
firebase functions:secrets:set WONYAPAY_TOKEN_ORANGE
firebase functions:secrets:set WONYAPAY_REF_ORANGE
firebase functions:secrets:set WONYAPAY_TOKEN_AFRIMONEY
firebase functions:secrets:set WONYAPAY_REF_AFRIMONEY
firebase deploy --only functions,firestore:rules
```

**Ne mettez jamais le token dans `MainActivity.java`, dans `google-services.json`, dans GitHub ou dans l'APK.**

## Statut d'une transaction
Le backend conserve la référence `RefTransa` dans `yb_transfers` et expose une seconde fonction `getWonyaPayStatus` qui appelle :

`GET /transaction-status/status/:refTransa`

L'application affiche le statut et permet de demander une vérification lorsque la transaction reste en attente.

## Frais
L'interface affiche **2 % à titre indicatif** pour les sorties, conformément aux conditions publiées par WonyaSoft au moment de cette version. Le montant/frais retourné réellement par WonyaPay reste la valeur de référence.

## Important avant le premier vrai transfert
1. Configurer les secrets Firebase.
2. Vérifier les `RefPartenaire` des caisses concernées.
3. Déployer les Functions.
4. Tester avec l'environnement de test WonyaPay avant toute opération réelle.
5. Vérifier le statut avant de relancer une transaction restée en attente afin d'éviter un doublon.
