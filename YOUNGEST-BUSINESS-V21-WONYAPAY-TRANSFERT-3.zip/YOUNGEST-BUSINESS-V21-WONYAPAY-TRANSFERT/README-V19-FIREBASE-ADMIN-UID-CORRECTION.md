# V19 — Correction Firebase Bureau/Admin

Cette version conserve l'authentification anonyme pour l'espace client, mais l'espace Bureau/Admin se connecte au compte Firebase `elishayoungest19@gmail.com` avec `signInWithEmailAndPassword`.

Le mot de passe n'est pas stocké dans le code. Il est saisi au moment de l'ouverture de l'espace Bureau.

Les Rules incluses utilisent l'UID administrateur déjà configuré dans Firebase.
