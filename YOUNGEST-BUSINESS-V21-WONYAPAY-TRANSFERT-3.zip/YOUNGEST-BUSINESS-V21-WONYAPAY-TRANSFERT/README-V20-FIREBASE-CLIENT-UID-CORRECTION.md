# YOUNGEST’S BUSINESS — V20

## Correction Firebase Client → Bureau

Cette version corrige la transmission des demandes de prêt depuis l’espace Client vers Firestore et le Bureau.

### Corrections incluses
- Le Client utilise son UID Firebase anonyme comme `clientId`.
- `requesterUid` et `clientId` doivent correspondre à `request.auth.uid` lors de la création.
- Le statut initial réel de l’application est `EN_ATTENTE`, et les Rules utilisent le même statut.
- La lecture Client utilise `requesterUid == request.auth.uid`, compatible avec la requête Firestore de l’application.
- Le Bureau utilise le compte Firebase Email/Password `elishayoungest19@gmail.com`.
- Les Rules Bureau utilisent le véritable UID Admin : `StxrZBDeUodj7YVPmXRA2AbWcUF2`.
- Le Bureau conserve la lecture globale et la validation/refus des demandes.

## Flux attendu
Client → Auth Firebase anonyme → Firestore `yb_loan_requests` → Bureau/Admin

## Test recommandé
1. Installer V20 sur un téléphone Client.
2. Envoyer une nouvelle demande.
3. Vérifier la confirmation d’envoi.
4. Ouvrir le Bureau/Admin et vérifier l’apparition de la demande.
5. Tester ensuite l’approbation et le refus.
