# YOUNGEST'S BUSINESS V46 — Rappels automatiques d’échéances

## Ce qui est ajouté
- Fonction planifiée Firebase `processLoanDueRemindersV46`, tous les jours à 07:00, fuseau `Africa/Kinshasa`.
- Rappels pour échéances dans 3 jours, 2 jours, demain, aujourd’hui et retards.
- Solde calculé à partir du montant total dû et des paiements reliés au prêt par `loanId`, `loan.id` ou `loanRef`.
- Prêts soldés exclus; dossiers sans date d’échéance reconnus exclus; aucun calendrier intermédiaire inventé.
- Identifiant déterministe par prêt/jour/type pour éviter les doublons.
- Historique visible dans « Alertes des échéances » via `yb_admin_due_notifications`.
- Envoi FCM facultatif si un jeton valide est déjà enregistré pour le compte administrateur.

## À savoir avant le déploiement
1. Le premier déploiement de Cloud Functions planifiées peut demander d’activer Cloud Scheduler / les API nécessaires et un plan de facturation Firebase/Google Cloud compatible. Vérifier les coûts avant d’activer la facturation.
2. Le rappel automatique dans Firestore fonctionne sans clé Web Push; une notification visible quand le navigateur est fermé exige en plus l’inscription FCM Web, un service worker et une clé VAPID. Ce ZIP ne prétend pas que cette inscription Web est déjà configurée.
3. L’horaire est 07:00 heure de Kinshasa. Les alertes sont générées côté serveur, même si l’interface admin est fermée.
4. Les données existantes ne sont pas migrées ni modifiées par ce traitement; il ajoute uniquement les documents de notification.

## Collections utilisées
`yb_loans`, `yb_payments`, `yb_admin_due_notifications`, et facultativement `yb_notification_tokens`.
