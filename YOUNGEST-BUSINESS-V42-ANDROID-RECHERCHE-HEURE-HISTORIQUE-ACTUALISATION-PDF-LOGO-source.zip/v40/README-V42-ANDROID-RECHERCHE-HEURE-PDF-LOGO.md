# YOUNGEST'S BUSINESS Android V42 — recherche, heure et PDF avec logo

Modifications basées sur la source V41 :
- Recherche par nom du bénéficiaire ou numéro dans le Journal des envois et le Journal LUMICASH.
- Les journaux s'ouvrent par défaut sur tout l'historique; les filtres journalier, mensuel et date restent disponibles.
- Enregistrement et affichage de l'heure locale (HH:mm:ss) des nouvelles transactions; reprise de l'heure à partir de `createdAt` pour les anciennes entrées lorsque disponible.
- Export PDF avec le logo officiel YOUNGEST'S BUSINESS en en-tête.
- Synchronisation Firebase conservée, avec champ `time` ajouté aux nouvelles entrées. Les anciennes données ne sont pas supprimées.

Version Android : `versionCode 42`, `versionName 1.35.0`.
