package com.aistudio.youngestbiz.mbkz;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.util.*;

/**
 * YOUNGEST'S BUSINESS - V8.
 * Local persistent prototype with admin protection and manual data backup/restore.
 * Local persistent prototype: clients, loans and payments survive app restart.
 * This is not yet a production financial backend; server authentication/payment
 * integration must be added before real-money deployment.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "youngest_business_data";
    private static final String KEY_DATA = "data";
    private static final String KEY_ADMIN_HASH = "admin_password_hash";
    private boolean adminSession = false;

    final int NAVY = Color.rgb(6,43,99), GREEN = Color.rgb(47,143,20), GOLD = Color.rgb(217,165,27);
    final int RED = Color.rgb(198,40,40), PURPLE = Color.rgb(112,55,180), BLUE = Color.rgb(25,100,210);
    final int LIGHT = Color.rgb(245,247,250);

    LinearLayout root, body;
    final ArrayList<Client> clients = new ArrayList<>();
    final ArrayList<Loan> loans = new ArrayList<>();
    final ArrayList<Payment> payments = new ArrayList<>();
    SharedPreferences prefs;

    static class Client {
        String name, phone;
        Client(String n, String p) { name=n; phone=p; }
    }

    static class Loan {
        Client c; double principal, rate; int days; long date;
        Loan(Client c, double p, double r, int d) {
            this.c=c; principal=p; rate=r; days=d; date=System.currentTimeMillis();
        }
        double interest(){ return principal * rate / 100.0; }
        double total(){ return principal + interest(); }
        long dueDate(){ return date + days * 24L * 60L * 60L * 1000L; }
        double paid(ArrayList<Payment> ps){ double x=0; for(Payment p:ps) if(p.loan==this) x+=p.amount; return x; }
        double balance(ArrayList<Payment> ps){ return Math.max(0, total()-paid(ps)); }
    }

    static class Payment {
        Loan loan; double amount; long date;
        Payment(Loan l, double a){ loan=l; amount=a; date=System.currentTimeMillis(); }
    }

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(14),dp(10),dp(14),dp(10)); return t;
    }

    GradientDrawable bg(int c,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    Button btn(String s,int c){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(bg(c,14)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        loadData();
        showSplash();
    }

    private void seedIfEmpty(){
        if(!clients.isEmpty()) return;
        clients.add(new Client("KIEUERECI KALAY",""));
        clients.add(new Client("MUKOSA CHRISTIAN",""));
        clients.add(new Client("NZAGIRE VALENTINE",""));
        loans.add(new Loan(clients.get(0),350000,30,30));
        loans.add(new Loan(clients.get(1),350000,20,14));
        loans.add(new Loan(clients.get(2),100000,10,7));
        saveData();
    }

    private void saveData(){
        try {
            JSONObject all=new JSONObject();
            JSONArray cs=new JSONArray();
            for(Client c:clients){ JSONObject o=new JSONObject(); o.put("name",c.name); o.put("phone",c.phone); cs.put(o); }
            JSONArray ls=new JSONArray();
            for(Loan l:loans){ JSONObject o=new JSONObject(); o.put("client",clients.indexOf(l.c)); o.put("principal",l.principal); o.put("rate",l.rate); o.put("days",l.days); o.put("date",l.date); ls.put(o); }
            JSONArray ps=new JSONArray();
            for(Payment p:payments){ JSONObject o=new JSONObject(); o.put("loan",loans.indexOf(p.loan)); o.put("amount",p.amount); o.put("date",p.date); ps.put(o); }
            all.put("clients",cs); all.put("loans",ls); all.put("payments",ps);
            prefs.edit().putString(KEY_DATA,all.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void loadData(){
        String raw=prefs.getString(KEY_DATA,null);
        if(raw==null){ seedIfEmpty(); return; }
        try {
            JSONObject all=new JSONObject(raw);
            JSONArray cs=all.optJSONArray("clients");
            JSONArray ls=all.optJSONArray("loans");
            JSONArray ps=all.optJSONArray("payments");
            if(cs!=null) for(int i=0;i<cs.length();i++){ JSONObject o=cs.getJSONObject(i); clients.add(new Client(o.optString("name"),o.optString("phone"))); }
            if(ls!=null) for(int i=0;i<ls.length();i++){ JSONObject o=ls.getJSONObject(i); int ci=o.optInt("client",-1); if(ci>=0&&ci<clients.size()){ Loan l=new Loan(clients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days")); l.date=o.optLong("date",l.date); loans.add(l); } }
            if(ps!=null) for(int i=0;i<ps.length();i++){ JSONObject o=ps.getJSONObject(i); int li=o.optInt("loan",-1); if(li>=0&&li<loans.size()){ Payment p=new Payment(loans.get(li),o.optDouble("amount")); p.date=o.optLong("date",p.date); payments.add(p); } }
            if(clients.isEmpty()) seedIfEmpty();
        } catch(Exception e){ clients.clear(); loans.clear(); payments.clear(); seedIfEmpty(); }
    }

    void base(String name,int color){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),0,dp(8),0); bar.setBackgroundColor(color);
        TextView back=tv("‹",30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->home());
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(60)));
        TextView title=tv(name,19); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(60),1)); root.addView(bar);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(18));
        ScrollView sv=new ScrollView(this); sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showSplash(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this); im.setImageResource(R.drawable.logo_youngests_business); im.setScaleType(ImageView.ScaleType.CENTER_INSIDE); im.setPadding(dp(18),dp(18),dp(18),dp(8));
        root.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        Button b=btn("ENTRER DANS L'APPLICATION",NAVY); b.setOnClickListener(v->home()); root.addView(b,new LinearLayout.LayoutParams(-1,dp(58))); setContentView(root);
    }

    void home(){
        base("YOUNGEST'S BUSINESS",NAVY);
        body.addView(tv("Bienvenue 👋\nGestion des prêts et services financiers",20));
        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","🔄 TRANSFERTS","💵 REMBOURSEMENTS","👤 CLIENTS","🔐 ADMINISTRATION"};
        int[] cs={RED,GREEN,BLUE,PURPLE,GOLD,NAVY};
        for(int i=0;i<6;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{ if(k==0)requireAdmin(()->loanForm()); else if(k==1)services(); else if(k==2)transfers(); else if(k==3)requireAdmin(()->repay()); else if(k==4)requireAdmin(()->clientsPage()); else requireAdmin(()->adminDash()); });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=dp(82); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g); Button dash=btn("📊 TABLEAU DE BORD — ADMIN",NAVY); dash.setOnClickListener(v->requireAdmin(()->dashboard())); body.addView(dash,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(tv("🔒 Les données de gestion sont protégées par l’accès administrateur.\nCette version utilise une authentification locale ; une sécurité serveur sera nécessaire avant tout déploiement financier réel.",14));
    }

    void dashboard(){
        base("TABLEAU DE BORD",NAVY);
        double capital=0,intt=0,paid=0; int late=0,active=0;
        for(Loan l:loans){ capital+=l.principal; intt+=l.interest(); paid+=l.paid(payments); if(l.balance(payments)>0){active++; if(System.currentTimeMillis()>l.dueDate())late++;} }
        body.addView(tv("SITUATION RÉELLE DE L'ACTIVITÉ",19));
        body.addView(tv("👥 Clients : "+clients.size()+"\n📋 Prêts : "+loans.size()+"\n🟢 Prêts actifs : "+active+"\n🔴 Échéances dépassées : "+late+"\n💰 Capital prêté : "+fmt(capital)+" FBu\n📈 Intérêts prévus : "+fmt(intt)+" FBu\n💵 Total à récupérer : "+fmt(capital+intt)+" FBu\n🔄 Total encaissé : "+fmt(paid)+" FBu\n⏳ Solde à récupérer : "+fmt(capital+intt-paid)+" FBu",17));
        Button journal=btn("📋 JOURNAL DES PRÊTS",NAVY); journal.setOnClickListener(v->loanJournal()); body.addView(journal);
    }

    void loanJournal(){
        base("JOURNAL DES PRÊTS",NAVY); body.addView(tv("Historique des prêts",19));
        if(loans.isEmpty()){body.addView(tv("Aucun prêt enregistré.",16)); return;}
        for(Loan l:loans){
            double paid=l.paid(payments), bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(l.c.name+"\n"+fmt(l.principal)+" FBu • Total "+fmt(l.total())+" FBu\n"+status+" • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(88)));
        }
    }

    void loanDetails(Loan l){
        base("DÉTAIL DU PRÊT",RED);
        double paid=l.paid(payments), bal=l.balance(payments);
        body.addView(tv("CLIENT\n"+l.c.name+(l.c.phone.isEmpty()?"":"\n"+l.c.phone),17));
        body.addView(tv("MONTANT : "+fmt(l.principal)+" FBu\nTAUX : "+fmt(l.rate)+" %\nDURÉE : "+l.days+" jours\nINTÉRÊT : "+fmt(l.interest())+" FBu\nTOTAL : "+fmt(l.total())+" FBu\nDÉJÀ PAYÉ : "+fmt(paid)+" FBu\nSOLDE : "+fmt(bal)+" FBu\nÉCHÉANCE : "+date(l.dueDate()),17));
        Button p=btn("💵 ENREGISTRER UN REMBOURSEMENT",PURPLE); p.setOnClickListener(v->paymentForm(l)); body.addView(p);
    }

    void loanForm(){ loanForm(null); }

    void loanForm(Client preselected){
        base("NOUVEAU PRÊT",RED); body.addView(tv("Enregistrer un prêt",19));
        Spinner sp=new Spinner(this); ArrayList<String> ns=new ArrayList<>(); int selected=-1;
        for(int i=0;i<clients.size();i++){ Client c=clients.get(i); ns.add(c.name); if(c==preselected) selected=i; }
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ns));
        if(selected>=0) sp.setSelection(selected);
        body.addView(sp);
        EditText amt=input("Montant prêté (FBu)",InputType.TYPE_CLASS_NUMBER), rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL), days=input("Durée en jours",InputType.TYPE_CLASS_NUMBER);
        body.addView(amt); body.addView(rate); body.addView(days); TextView calc=tv("Intérêt : —\nTotal à récupérer : —",16); body.addView(calc);
        TextWatcher w=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){calculate(amt,rate,calc);} public void afterTextChanged(Editable e){}};
        amt.addTextChangedListener(w); rate.addTextChangedListener(w);
        Button save=btn("ENREGISTRER LE PRÊT",RED); save.setOnClickListener(v->{
            try{ if(clients.isEmpty())throw new Exception(); double a=Double.parseDouble(amt.getText().toString()),r=Double.parseDouble(rate.getText().toString()); int d=Integer.parseInt(days.getText().toString());
                if(a<=0||r<0||d<=0)throw new Exception(); loans.add(new Loan(clients.get(sp.getSelectedItemPosition()),a,r,d)); saveData(); Toast.makeText(this,"Prêt enregistré avec succès",Toast.LENGTH_LONG).show(); loanJournal();
            }catch(Exception e){Toast.makeText(this,"Veuillez remplir correctement les champs",Toast.LENGTH_SHORT).show();}
        }); body.addView(save);
    }

    EditText input(String hint,int type){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); return e; }
    void calculate(EditText a,EditText r,TextView out){ try{double x=Double.parseDouble(a.getText().toString()),y=Double.parseDouble(r.getText().toString()); out.setText("Intérêt : "+fmt(x*y/100)+" FBu\nTotal à récupérer : "+fmt(x+x*y/100)+" FBu");}catch(Exception ignored){out.setText("Intérêt : —\nTotal à récupérer : —");} }

    void clientsPage(){
        base("CLIENTS",NAVY); body.addView(tv("CLIENTS ENREGISTRÉS : "+clients.size(),19));
        for(Client c:clients){ Button b=btn("👤 "+c.name+(c.phone.isEmpty()?"":" — "+c.phone),NAVY); b.setOnClickListener(v->clientDetails(c)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(56))); }
        Button add=btn("＋ AJOUTER UN CLIENT",NAVY); add.setOnClickListener(v->addClient()); body.addView(add);
    }

    void clientDetails(Client c){
        base("FICHE CLIENT",NAVY); body.addView(tv("👤 "+c.name+"\n📱 "+(c.phone.isEmpty()?"Non renseigné":c.phone),19));
        int n=0; double total=0,paid=0; for(Loan l:loans)if(l.c==c){n++;total+=l.total();paid+=l.paid(payments);}
        body.addView(tv("Prêts : "+n+"\nTotal à récupérer : "+fmt(total)+" FBu\nTotal payé : "+fmt(paid)+" FBu\nSolde : "+fmt(total-paid)+" FBu",17));
        Button addLoan=btn("＋ AJOUTER UN PRÊT À CE CLIENT",RED); addLoan.setOnClickListener(v->loanForm(c)); body.addView(addLoan);
        body.addView(tv("HISTORIQUE DES PRÊTS",18));
        boolean found=false;
        for(Loan l:loans) if(l.c==c){
            found=true; double bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(fmt(l.principal)+" FBu • "+status+"\nTotal "+fmt(l.total())+" FBu • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(82)));
        }
        if(!found) body.addView(tv("Aucun prêt pour ce client.",15));
    }

    void addClient(){
        final EditText n=input("Nom et post-nom",InputType.TYPE_CLASS_TEXT), p=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("Nouveau client").setView(box).setPositiveButton("ENREGISTRER",(d,w)->{if(n.getText().length()>0){clients.add(new Client(n.getText().toString().trim(),p.getText().toString().trim()));saveData();clientsPage();}}).setNegativeButton("ANNULER",null).show();
    }

    void repay(){
        base("REMBOURSEMENTS",PURPLE); body.addView(tv("Choisissez un prêt puis enregistrez le paiement",18));
        for(Loan l:loans){ double bal=l.balance(payments); if(bal>0){ Button b=btn(l.c.name+" — Solde "+fmt(bal)+" FBu",PURPLE); b.setOnClickListener(v->paymentForm(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(62))); } }
    }

    void paymentForm(Loan l){
        EditText a=input("Montant du paiement (FBu)",InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("Paiement — "+l.c.name).setView(a).setPositiveButton("ENCAISSER",(d,w)->{
            try{double x=Double.parseDouble(a.getText().toString()); if(x<=0||x>l.balance(payments))throw new Exception(); payments.add(new Payment(l,x)); saveData(); Toast.makeText(this,"Remboursement enregistré",Toast.LENGTH_SHORT).show(); loanDetails(l);}
            catch(Exception e){Toast.makeText(this,"Montant invalide",Toast.LENGTH_SHORT).show();}
        }).setNegativeButton("ANNULER",null).show();
    }

    void adminDash(){
        base("ADMINISTRATION",NAVY);
        body.addView(tv("🔐 ESPACE ADMINISTRATEUR",20));
        body.addView(tv("Accès réservé à la gestion interne de YOUNGEST’S BUSINESS.",16));
        Button d=btn("📊 TABLEAU DE BORD",NAVY); d.setOnClickListener(v->dashboard()); body.addView(d);
        Button c=btn("👥 GESTION DES CLIENTS",GOLD); c.setOnClickListener(v->clientsPage()); body.addView(c);
        Button l=btn("💰 GESTION DES PRÊTS",RED); l.setOnClickListener(v->loanJournal()); body.addView(l);
        Button r=btn("💵 REMBOURSEMENTS",PURPLE); r.setOnClickListener(v->repay()); body.addView(r);
        Button backup=btn("💾 SAUVEGARDER LES DONNÉES",GREEN); backup.setOnClickListener(v->exportData()); body.addView(backup);
        Button restore=btn("📥 RESTAURER LES DONNÉES",BLUE); restore.setOnClickListener(v->confirmRestore()); body.addView(restore);
        Button out=btn("🚪 SE DÉCONNECTER",BLUE); out.setOnClickListener(v->{adminSession=false; home();}); body.addView(out);
    }

    private void exportData(){
        try{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"youngest_business_sauvegarde.json"); startActivityForResult(i,9001);
        }catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void confirmRestore(){
        new AlertDialog.Builder(this)
            .setTitle("📥 Restaurer les données ?")
            .setMessage("La restauration remplacera les clients, prêts et remboursements actuellement enregistrés sur cet appareil. Continuez uniquement avec une sauvegarde fiable.")
            .setPositiveButton("CHOISIR LA SAUVEGARDE",(d,w)->{
                try{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,9002); }
                catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir le sélecteur de fichier.",Toast.LENGTH_LONG).show();}
            })
            .setNegativeButton("ANNULER",null).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if(requestCode==9001) writeBackup(uri); else if(requestCode==9002) readBackup(uri);
    }

    private String buildBackup(){
        try{
            JSONObject all=new JSONObject(); JSONArray cs=new JSONArray(),ls=new JSONArray(),ps=new JSONArray();
            for(Client c:clients){JSONObject o=new JSONObject();o.put("name",c.name);o.put("phone",c.phone);cs.put(o);}
            for(Loan l:loans){JSONObject o=new JSONObject();o.put("client",clients.indexOf(l.c));o.put("principal",l.principal);o.put("rate",l.rate);o.put("days",l.days);o.put("date",l.date);ls.put(o);}
            for(Payment p:payments){JSONObject o=new JSONObject();o.put("loan",loans.indexOf(p.loan));o.put("amount",p.amount);o.put("date",p.date);ps.put(o);}
            all.put("app","YOUNGEST’S BUSINESS"); all.put("backup_version",1); all.put("created_at",System.currentTimeMillis()); all.put("clients",cs); all.put("loans",ls); all.put("payments",ps); return all.toString(2);
        }catch(Exception e){return null;}
    }

    private void writeBackup(Uri uri){
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            String raw=buildBackup(); if(raw==null)throw new Exception(); out.write(raw.getBytes("UTF-8")); out.flush(); Toast.makeText(this,"Sauvegarde créée avec succès.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Échec de la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void readBackup(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri)){
            java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) buffer.write(b,0,n);
            JSONObject all=new JSONObject(new String(buffer.toByteArray(),"UTF-8"));
            if(!"YOUNGEST’S BUSINESS".equals(all.optString("app")) && !"YOUNGEST'S BUSINESS".equals(all.optString("app"))) throw new Exception();
            JSONArray cs=all.optJSONArray("clients"),ls=all.optJSONArray("loans"),ps=all.optJSONArray("payments");
            if(cs==null||ls==null||ps==null)throw new Exception();
            ArrayList<Client> newClients=new ArrayList<>(); ArrayList<Loan> newLoans=new ArrayList<>(); ArrayList<Payment> newPayments=new ArrayList<>();
            for(int i=0;i<cs.length();i++){JSONObject o=cs.getJSONObject(i);newClients.add(new Client(o.optString("name"),o.optString("phone")));}
            for(int i=0;i<ls.length();i++){JSONObject o=ls.getJSONObject(i);int ci=o.optInt("client",-1);if(ci<0||ci>=newClients.size())throw new Exception();Loan l=new Loan(newClients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days"));l.date=o.optLong("date",l.date);newLoans.add(l);}
            for(int i=0;i<ps.length();i++){JSONObject o=ps.getJSONObject(i);int li=o.optInt("loan",-1);if(li<0||li>=newLoans.size())throw new Exception();Payment p=new Payment(newLoans.get(li),o.optDouble("amount"));p.date=o.optLong("date",p.date);newPayments.add(p);}
            clients.clear();clients.addAll(newClients);loans.clear();loans.addAll(newLoans);payments.clear();payments.addAll(newPayments);saveData(); Toast.makeText(this,"Données restaurées avec succès.",Toast.LENGTH_LONG).show(); adminDash();
        }catch(Exception e){Toast.makeText(this,"Fichier de sauvegarde invalide ou incompatible.",Toast.LENGTH_LONG).show();}
    }

    private void requireAdmin(Runnable action){
        if(adminSession){ action.run(); return; }
        String saved=prefs.getString(KEY_ADMIN_HASH,null);
        if(saved==null){ setupAdminPassword(action); } else { showAdminLogin(action); }
    }

    private void setupAdminPassword(Runnable after){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0);
        EditText p1=input("Créer un mot de passe administrateur",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText p2=input("Confirmer le mot de passe",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(p1); box.addView(p2);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔐 Première configuration")
            .setMessage("Créez le mot de passe qui protégera l’espace de gestion sur cet appareil. Minimum 6 caractères.")
            .setView(box).setPositiveButton("CRÉER",null).setNegativeButton("ANNULER",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String a=p1.getText().toString(), b=p2.getText().toString();
            if(a.length()<6 || !a.equals(b)){ Toast.makeText(this,"Mot de passe invalide ou différent.",Toast.LENGTH_LONG).show(); return; }
            prefs.edit().putString(KEY_ADMIN_HASH,hash(a)).apply(); adminSession=true; dlg.dismiss(); after.run();
        })); dlg.show();
    }

    private void showAdminLogin(Runnable after){
        EditText p=input("Mot de passe administrateur",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔐 Connexion administrateur").setMessage("Accès réservé à la gestion de l’entreprise.").setView(p).setPositiveButton("SE CONNECTER",null).setNegativeButton("ANNULER",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(hash(p.getText().toString()).equals(prefs.getString(KEY_ADMIN_HASH,""))){ adminSession=true; dlg.dismiss(); after.run(); }
            else Toast.makeText(this,"Mot de passe incorrect.",Toast.LENGTH_SHORT).show();
        })); dlg.show();
    }

    private String hash(String value){
        try{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] out=md.digest(value.getBytes("UTF-8")); StringBuilder sb=new StringBuilder(); for(byte q:out) sb.append(String.format(Locale.US,"%02x",q)); return sb.toString(); }catch(Exception e){ return ""; }
    }


    void services(){
        base("SERVICES FINANCIERS",GREEN); body.addView(tv("MOBILE MONEY\nM-Pesa • Airtel Money • Orange Money • Afrimoney",17));
        for(String s:new String[]{"Dépôt d'argent","Retrait d'argent","Transfert d'argent"}){Button b=btn(s+" ›",GREEN); b.setOnClickListener(v->Toast.makeText(this,"Cette fonction sera connectée au service partenaire dans une prochaine version.",Toast.LENGTH_LONG).show()); body.addView(b);}
    }

    void transfers(){
        base("TRANSFERTS",BLUE); body.addView(tv("Transfert d'argent\nChoisissez le service et le bénéficiaire.",18));
        Button b=btn("NOUVEAU TRANSFERT",BLUE); b.setOnClickListener(v->Toast.makeText(this,"Module de transfert en préparation.",Toast.LENGTH_LONG).show()); body.addView(b);
    }

    String date(long time){return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date(time));}
    String fmt(double x){return String.format(Locale.US,"%,.0f",x).replace(',',' ');}
}
