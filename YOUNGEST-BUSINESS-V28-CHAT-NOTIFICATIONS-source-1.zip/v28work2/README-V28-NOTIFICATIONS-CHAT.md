# YOUNGEST'S BUSINESS V28 — Chat et notifications

Cette version part du code source V27 fourni et ajoute :
- rendre la zone de saisie du chat client clairement visible ;
- conserver les messages en temps réel via Firestore ;
- envoyer une notification push au client quand un message de l'administrateur est créé ;
- enregistrer le jeton FCM du compte client authentifié par téléphone.

## Déploiement requis

La compilation Android ne déploie pas les Cloud Functions. Après avoir publié le ZIP source et compilé l'APK, déployer la fonction serveur depuis la racine du projet avec Firebase CLI : `firebase deploy --only functions:notifyClientOnAdminChatReply`. Vérifier également que le compte Firebase utilise un plan autorisant les fonctions nécessaires, que les notifications Android sont autorisées et que le client ouvre une fois le chat pour enregistrer son jeton FCM.

La notification push n'est pas garantie tant que le déploiement de la fonction et le test sur appareil réel n'ont pas été effectués.
