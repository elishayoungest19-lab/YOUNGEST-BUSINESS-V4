package com.aistudio.youngestbiz.mbkz;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.Manifest;
import android.content.pm.PackageManager;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.functions.FirebaseFunctions;

/**
 * YOUNGEST'S BUSINESS - V18. Transfert Mobile Money direct client + API authorization architecture + Firebase.
 * Local persistent application with admin protection, Firebase/Firestore synchronization and manual data backup/restore.
 * Local persistent prototype: clients, loans and payments survive app restart.
 * This is not yet a production financial backend; real Mobile Money debit/credit requires
 * authorized operator/payment APIs and legal approvals before real-money deployment.
 */
public class MainActivity extends Activity {
    private static final int CREATE_JOURNAL_PDF = 2468;
    private static final int CREATE_REPORT_PDF = 2469;
    private String pendingJournalPdfText = "";
    private String pendingJournalPdfName = "Rapport_Journal.pdf";
    private String pendingReportPdfText = "";
    private String pendingReportPdfName = "Rapport_Mensuel.pdf";
    private static final String PREFS = "youngest_business_data";
    private static final String KEY_DATA = "data";
    private static final String KEY_ADMIN_HASH = "admin_password_hash";
    // Compte Firebase utilisé uniquement par l'espace Bureau/Admin.
    // Le mot de passe n'est jamais stocké dans le code : il est saisi à la connexion.
    private static final String FIREBASE_ADMIN_EMAIL = "elishayoungest19@gmail.com";
    private static final String KEY_TRANSFERS = "transfers";
    private static final String KEY_PENDING_CHAT_DRAFT = "pending_chat_draft";
    private static final String KEY_PENDING_CHAT_PHONE = "pending_chat_phone";
    private boolean adminSession = false;

    // Synchronisation centrale Firebase/Firestore
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private ListenerRegistration clientsListener;
    private ListenerRegistration loansListener;
    private ListenerRegistration paymentsListener;
    private ListenerRegistration loanRequestsListener;
    private ListenerRegistration chatMessagesListener;
    private ListenerRegistration chatListListener;
    private String activeChatConversationId = "";
    private String pendingChatDraft = "";
    private String pendingChatPhone = "";
    private String pendingPhoneVerificationId = "";
    private PhoneAuthProvider.ForceResendingToken pendingPhoneResendToken;
    private boolean loanRequestsListenerIsClient = false;
    private boolean cloudSyncStarted = false;
    private boolean initialCloudClientsDone = false;
    private boolean initialCloudLoansDone = false;
    private boolean initialCloudPaymentsDone = false;
    private boolean initialCloudRequestsDone = false;
    private boolean clientMode = false;
    private String clientUid = "";
    // Files reçus avant leur dépendance (client/loan) : on les conserve puis on les rejoue.
    private final Map<String,DocumentSnapshot> pendingCloudLoans = new HashMap<>();
    private final Map<String,DocumentSnapshot> pendingCloudPayments = new HashMap<>();

    final int NAVY = Color.rgb(6,43,99), GREEN = Color.rgb(47,143,20), GOLD = Color.rgb(217,165,27);
    final int RED = Color.rgb(198,40,40), PURPLE = Color.rgb(112,55,180), BLUE = Color.rgb(25,100,210);
    final int LIGHT = Color.rgb(245,247,250);

    LinearLayout root, body;
    final ArrayList<Client> clients = new ArrayList<>();
    final ArrayList<Loan> loans = new ArrayList<>();
    final ArrayList<Payment> payments = new ArrayList<>();
    final ArrayList<LoanRequest> loanRequests = new ArrayList<>();
    final ArrayList<Transfer> transfersList = new ArrayList<>();
    SharedPreferences prefs;

    static class Client {
        String id, name, phone;
        Client(String n, String p) { this(makeId(n + "|" + p), n, p); }
        Client(String i, String n, String p) { id=i; name=n; phone=p; }
    }

    static class Loan {
        String id; Client c; double principal, rate; int days; long date;
        Loan(Client c, double p, double r, int d) {
            this(c, p, r, d, System.currentTimeMillis());
        }
        Loan(Client c, double p, double r, int d, long when) {
            this.c=c; principal=p; rate=r; days=d; date=when;
            id=makeId(c.id + "|" + p + "|" + r + "|" + d + "|" + date);
        }
        double interest(){ return principal * rate / 100.0; }
        double total(){ return principal + interest(); }
        long dueDate(){ return date + days * 24L * 60L * 60L * 1000L; }
        double paid(ArrayList<Payment> ps){ double x=0; for(Payment p:ps) if(p.loan==this) x+=p.amount; return x; }
        double balance(ArrayList<Payment> ps){ return Math.max(0, total()-paid(ps)); }
    }

    static class Payment {
        String id; Loan loan; double amount; long date;
        Payment(Loan l, double a){ this(l, a, System.currentTimeMillis()); }
        Payment(Loan l, double a, long when){ loan=l; amount=a; date=when; id=makeId(l.id + "|" + a + "|" + date); }
    }

    static class LoanRequest {
        String id, requesterUid, clientId, name, phone, reason, status;
        double amount; int days; long date, updatedAt;
        LoanRequest(String uid, String n, String p, double a, int d, String r){
            requesterUid=uid; name=n; phone=p; amount=a; days=d; reason=r;
            status="EN_ATTENTE"; date=System.currentTimeMillis(); updatedAt=date;
            id=makeId(uid + "|" + name + "|" + phone + "|" + amount + "|" + date);
        }
    }

    static class Transfer {
        String id, currency, senderName, senderPhone, senderNetwork, beneficiaryName, beneficiaryPhone, beneficiaryNetwork, reason, status, apiStatus, providerReference, requesterUid;
        boolean clientInitiated;
        double amount, fees; long date;
        Transfer(String cur,String sn,String sp,String sr,String bn,String bp,String br,double a,double f,String rs){
            currency=cur; senderName=sn; senderPhone=sp; senderNetwork=sr; beneficiaryName=bn; beneficiaryPhone=bp; beneficiaryNetwork=br; amount=a; fees=f; reason=rs;
            status="EN_COURS"; apiStatus="SIMULATION"; providerReference=""; requesterUid=""; clientInitiated=false; date=System.currentTimeMillis();
            id="TRF-"+makeId(senderPhone+"|"+beneficiaryPhone+"|"+amount+"|"+date).substring(0,10).toUpperCase(Locale.US);
        }
        double total(){ return amount+fees; }
    }

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }

    private String clientPref(String suffix){ return "client_" + (clientUid==null?"":clientUid) + "_" + suffix; }
    private String savedClientName(){ return clientUid==null?"":prefs.getString(clientPref("name"),""); }
    private String savedClientPhone(){ return clientUid==null?"":prefs.getString(clientPref("phone"),""); }
    private String savedClientWalletNetwork(){ return clientUid==null?"":prefs.getString(clientPref("wallet_network"),""); }

    private void setupNotifications(){
        AppNotificationService.createChannel(this);
        if(android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            if(token!=null && !token.isEmpty()) prefs.edit().putString("fcm_token",token).apply();
            uploadNotificationToken(token);
        });
    }

    private void uploadNotificationToken(String token){
        if(token==null || token.isEmpty() || firestore==null || clientUid==null || clientUid.isEmpty()) return;
        Map<String,Object> m=new HashMap<>();
        m.put("token",token);
        m.put("uid",clientUid);
        m.put("clientMode",clientMode);
        m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_notification_tokens").document(clientUid).set(m);
    }

    private void localNotification(String title,String message){
        AppNotificationService.notifyLocal(this,title,message);
    }

    private void showNotificationsPage(){
        base("NOTIFICATIONS",BLUE);
        body.addView(tv("🔔 CENTRE DE NOTIFICATIONS",21));
        String raw=prefs.getString("app_notifications","[]");
        try{
            JSONArray a=new JSONArray(raw);
            if(a.length()==0) body.addView(tv("Aucune notification pour le moment.",15));
            for(int i=a.length()-1;i>=0;i--){
                JSONObject o=a.getJSONObject(i);
                body.addView(tv("🔔 "+o.optString("title")+"\n"+o.optString("message")+"\n"+o.optString("date"),15));
            }
        }catch(Exception e){ body.addView(tv("Aucune notification pour le moment.",15)); }
        Button clear=btn("🗑️ EFFACER LES NOTIFICATIONS",RED);
        clear.setOnClickListener(v->{ prefs.edit().remove("app_notifications").apply(); showNotificationsPage(); });
        body.addView(clear);
        Button back=btn("← RETOUR",NAVY); back.setOnClickListener(v->{ if(clientMode) clientHome(); else home(); }); body.addView(back);
    }

    private String normalizePhone(String phone){
        if(phone==null) return "";
        String n=phone.replaceAll("[^0-9+]","");
        if(n.startsWith("+243")) n="0"+n.substring(4);
        else if(n.startsWith("243") && n.length()>9) n="0"+n.substring(3);
        return n;
    }

    static class WalletVerification {
        boolean verified; String network, phone, holderName, source;
        WalletVerification(boolean ok,String net,String ph,String holder,String src){ verified=ok; network=net; phone=ph; holderName=holder; source=src; }
    }

    private WalletVerification verifyWalletSimulation(String phone, String network){
        String n=normalizePhone(phone);
        String net=network==null?"":network.trim();
        if(n.isEmpty() || net.isEmpty()) return new WalletVerification(false,net,phone,"","AUCUNE_VERIFICATION");

        // Phase pilote : on ne lit pas la SIM. On recherche automatiquement le numéro
        // dans le portefeuille client déjà enregistré dans l'application.
        String saved=normalizePhone(savedClientPhone());
        String savedNet=savedClientWalletNetwork();
        if(!saved.isEmpty() && saved.equals(n) && net.equalsIgnoreCase(savedNet) && !savedClientName().trim().isEmpty()) {
            return new WalletVerification(true,net,phone,savedClientName().trim(),"PROFIL PORTEFEUILLE VÉRIFIÉ");
        }

        // Si le numéro existe déjà dans les fiches clients, son nom est repris
        // automatiquement pendant le pilote. La vérification opérateur réelle
        // sera remplacée par l'API officielle dès que l'autorisation sera obtenue.
        Client match=null;
        for(Client c:clients){
            if(!normalizePhone(c.phone).isEmpty() && normalizePhone(c.phone).equals(n)){
                if(match!=null && !match.name.equalsIgnoreCase(c.name)) return new WalletVerification(false,net,phone,"","PLUSIEURS_PROFILS");
                match=c;
            }
        }
        if(match!=null && !match.name.trim().isEmpty()){
            return new WalletVerification(true,net,phone,match.name.trim(),"REGISTRE CLIENT YOUNGEST'S BUSINESS");
        }

        return new WalletVerification(false,net,phone,"","API_OFFICIELLE_REQUISE");
    }

    private String findVerifiedWalletName(String phone, String network){
        WalletVerification r=verifyWalletSimulation(phone,network);
        return r.verified?r.holderName:"";
    }


    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(14),dp(10),dp(14),dp(10)); return t;
    }

    GradientDrawable bg(int c,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    Button btn(String s,int c){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(bg(c,14)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        pendingChatDraft=prefs.getString(KEY_PENDING_CHAT_DRAFT,"");
        pendingChatPhone=prefs.getString(KEY_PENDING_CHAT_PHONE,"");
        loadData();
        showSplash();
        setupNotifications();
        startCloudSync();
    }

    private void seedIfEmpty(){
        if(!clients.isEmpty()) return;
        clients.add(new Client("KIEUERECI KALAY",""));
        clients.add(new Client("MUKOSA CHRISTIAN",""));
        clients.add(new Client("NZAGIRE VALENTINE",""));
        loans.add(new Loan(clients.get(0),350000,30,30));
        loans.add(new Loan(clients.get(1),350000,20,14));
        loans.add(new Loan(clients.get(2),100000,10,7));
        saveData();
    }

    private void saveData(){
        try {
            JSONObject all=new JSONObject();
            JSONArray cs=new JSONArray();
            for(Client c:clients){ JSONObject o=new JSONObject(); o.put("id",c.id); o.put("name",c.name); o.put("phone",c.phone); cs.put(o); }
            JSONArray ls=new JSONArray();
            for(Loan l:loans){ JSONObject o=new JSONObject(); o.put("id",l.id); o.put("client",clients.indexOf(l.c)); o.put("clientId",l.c.id); o.put("principal",l.principal); o.put("rate",l.rate); o.put("days",l.days); o.put("date",l.date); ls.put(o); }
            JSONArray ps=new JSONArray();
            for(Payment p:payments){ JSONObject o=new JSONObject(); o.put("id",p.id); o.put("loan",loans.indexOf(p.loan)); o.put("loanId",p.loan.id); o.put("amount",p.amount); o.put("date",p.date); ps.put(o); }
            JSONArray rs=new JSONArray();
            for(LoanRequest r:loanRequests){ JSONObject o=new JSONObject(); o.put("id",r.id); o.put("requesterUid",r.requesterUid); o.put("clientId",r.clientId); o.put("name",r.name); o.put("phone",r.phone); o.put("amount",r.amount); o.put("days",r.days); o.put("reason",r.reason); o.put("status",r.status); o.put("date",r.date); o.put("updatedAt",r.updatedAt); rs.put(o); }
            JSONArray ts=new JSONArray();
            for(Transfer t:transfersList){ JSONObject o=new JSONObject(); o.put("id",t.id); o.put("currency",t.currency); o.put("senderName",t.senderName); o.put("senderPhone",t.senderPhone); o.put("senderNetwork",t.senderNetwork); o.put("beneficiaryName",t.beneficiaryName); o.put("beneficiaryPhone",t.beneficiaryPhone); o.put("beneficiaryNetwork",t.beneficiaryNetwork); o.put("amount",t.amount); o.put("fees",t.fees); o.put("reason",t.reason); o.put("status",t.status); o.put("apiStatus",t.apiStatus); o.put("providerReference",t.providerReference); o.put("requesterUid",t.requesterUid); o.put("clientInitiated",t.clientInitiated); o.put("date",t.date); ts.put(o); }
            all.put("clients",cs); all.put("loans",ls); all.put("payments",ps); all.put("loanRequests",rs); all.put("transfers",ts);
            prefs.edit().putString(KEY_DATA,all.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void loadData(){
        String raw=prefs.getString(KEY_DATA,null);
        if(raw==null){ seedIfEmpty(); return; }
        try {
            JSONObject all=new JSONObject(raw);
            JSONArray cs=all.optJSONArray("clients");
            JSONArray ls=all.optJSONArray("loans");
            JSONArray ps=all.optJSONArray("payments");
            if(cs!=null) for(int i=0;i<cs.length();i++){ JSONObject o=cs.getJSONObject(i); String n=o.optString("name"), ph=o.optString("phone"); String id=o.optString("id",makeId(n+"|"+ph)); clients.add(new Client(id,n,ph)); }
            if(ls!=null) for(int i=0;i<ls.length();i++){ JSONObject o=ls.getJSONObject(i); int ci=o.optInt("client",-1); if(ci>=0&&ci<clients.size()){ long when=o.optLong("date",System.currentTimeMillis()); Loan l=new Loan(clients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days"),when); l.id=o.optString("id",l.id); loans.add(l); } }
            if(ps!=null) for(int i=0;i<ps.length();i++){ JSONObject o=ps.getJSONObject(i); int li=o.optInt("loan",-1); if(li>=0&&li<loans.size()){ long when=o.optLong("date",System.currentTimeMillis()); Payment p=new Payment(loans.get(li),o.optDouble("amount"),when); p.id=o.optString("id",p.id); payments.add(p); } }
            JSONArray rs=all.optJSONArray("loanRequests");
            if(rs!=null) for(int i=0;i<rs.length();i++){ JSONObject o=rs.getJSONObject(i); LoanRequest r=new LoanRequest(o.optString("requesterUid"),o.optString("name"),o.optString("phone"),o.optDouble("amount"),o.optInt("days"),o.optString("reason")); r.id=o.optString("id",r.id); r.clientId=o.optString("clientId",""); r.status=o.optString("status","EN_ATTENTE"); r.date=o.optLong("date",r.date); r.updatedAt=o.optLong("updatedAt",r.date); loanRequests.add(r); }
            JSONArray ts=all.optJSONArray("transfers");
            if(ts!=null) for(int i=0;i<ts.length();i++){ JSONObject o=ts.getJSONObject(i); Transfer t=new Transfer(o.optString("currency","FC"),o.optString("senderName"),o.optString("senderPhone"),o.optString("senderNetwork"),o.optString("beneficiaryName"),o.optString("beneficiaryPhone"),o.optString("beneficiaryNetwork"),o.optDouble("amount"),o.optDouble("fees"),o.optString("reason")); t.id=o.optString("id",t.id); t.status=o.optString("status","EN_COURS"); t.apiStatus=o.optString("apiStatus","SIMULATION"); t.providerReference=o.optString("providerReference",""); t.requesterUid=o.optString("requesterUid",""); t.clientInitiated=o.optBoolean("clientInitiated",false); t.date=o.optLong("date",t.date); transfersList.add(t); }
            if(clients.isEmpty()) seedIfEmpty();
        } catch(Exception e){ clients.clear(); loans.clear(); payments.clear(); seedIfEmpty(); }
    }

    private static String makeId(String value){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] out=md.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb=new StringBuilder();
            for(byte q:out) sb.append(String.format(Locale.US,"%02x",q));
            return sb.toString();
        }catch(Exception e){ return UUID.randomUUID().toString().replace("-",""); }
    }

    private void startCloudSync(){
        if(cloudSyncStarted){
            if(clientMode){
                if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
                if(firestore==null) firestore=FirebaseFirestore.getInstance();
                if(firebaseAuth.getCurrentUser()==null){
                    firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                        if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                            clientUid=firebaseAuth.getCurrentUser().getUid();
                            setupNotifications();
                            attachClientRequestsListener();
                        }else{
                            Toast.makeText(this,"Firebase : connexion client indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
                        }
                    });
                }else{
                    clientUid=firebaseAuth.getCurrentUser().getUid();
                    attachClientRequestsListener();
                }
            }else if(adminSession){
                attachClientsListener();
                attachBureauRequestsListener();
            }
            return;
        }
        cloudSyncStarted=true;
        try{
            firebaseAuth=FirebaseAuth.getInstance();
            firestore=FirebaseFirestore.getInstance();

            // L'espace client utilise l'authentification anonyme.
            // Si un compte email Admin est encore connecté, on le remplace par l'anonyme.
            if(clientMode){
                if(firebaseAuth.getCurrentUser()!=null && firebaseAuth.getCurrentUser().getEmail()!=null){
                    firebaseAuth.signOut();
                }
                if(firebaseAuth.getCurrentUser()==null){
                    firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                        if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                            clientUid=firebaseAuth.getCurrentUser().getUid();
                            setupNotifications();
                            attachClientRequestsListener();
                        }else{
                            Toast.makeText(this,"Firebase : connexion client indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                clientUid=firebaseAuth.getCurrentUser().getUid();
                attachClientRequestsListener();
                return;
            }

            // Le Bureau ne doit plus utiliser un compte anonyme : il doit être
            // authentifié avec le compte Firebase Admin au moment de l'accès Bureau.
            if(adminSession && firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                attachClientsListener();
                attachBureauRequestsListener();
            }
        }catch(Exception e){
            Toast.makeText(this,"Firebase : démarrage impossible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
        }
    }

    private void startBureauCloudSync(){
        clientMode=false;
        try{
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();

            if(firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                setupNotifications();
                attachClientsListener();
                attachBureauRequestsListener();
            }else{
                Toast.makeText(this,"Connexion Firebase du Bureau requise. Ouvrez l'espace Bureau et reconnectez-vous.",Toast.LENGTH_LONG).show();
            }
        }catch(Exception e){
            Toast.makeText(this,"Firebase : connexion Bureau indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
        }
    }

    private void attachClientsListener(){
        if(firestore==null || clientsListener!=null) return;
        clientsListener=firestore.collection("yb_clients").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudClient(d);
            retryPendingCloudLoans();
            if(!initialCloudClientsDone){
                initialCloudClientsDone=true;
                uploadAllClients();
                attachLoansListener();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachLoansListener(){
        if(firestore==null || loansListener!=null) return;
        loansListener=firestore.collection("yb_loans").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoan(d);
            retryPendingCloudPayments();
            if(!initialCloudLoansDone){
                initialCloudLoansDone=true;
                uploadAllLoans();
                attachPaymentsListener();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachPaymentsListener(){
        if(firestore==null || paymentsListener!=null) return;
        paymentsListener=firestore.collection("yb_payments").addSnapshotListener((snap,error)->{
            if(error!=null || snap==null) return;
            for(DocumentSnapshot d:snap.getDocuments()) mergeCloudPayment(d);
            if(!initialCloudPaymentsDone){
                initialCloudPaymentsDone=true;
                uploadAllPayments();
            }
            refreshAfterCloudChange();
        });
    }

    private void attachClientRequestsListener(){
        if(firestore==null || clientUid==null || clientUid.isEmpty()) return;
        if(loanRequestsListener!=null && loanRequestsListenerIsClient) return;
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        loanRequestsListenerIsClient=true;
        loanRequestsListener=firestore.collection("yb_loan_requests")
            .whereEqualTo("requesterUid", clientUid)
            .addSnapshotListener((snap,error)->{
                if(error!=null){
                    Toast.makeText(this,"Firebase : lecture de vos demandes impossible. Vérifiez la connexion.",Toast.LENGTH_LONG).show();
                    return;
                }
                if(snap==null) return;
                for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoanRequest(d);
                initialCloudRequestsDone=true;
                refreshAfterCloudChange();
            });
    }

    private void attachBureauRequestsListener(){
        if(firestore==null) return;
        if(loanRequestsListener!=null && !loanRequestsListenerIsClient) return;
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        loanRequestsListenerIsClient=false;
        loanRequestsListener=firestore.collection("yb_loan_requests")
            .addSnapshotListener((snap,error)->{
                if(error!=null){
                    Toast.makeText(this,"Firebase : le Bureau ne peut pas recevoir les demandes client. Vérifiez l'accès Firestore.",Toast.LENGTH_LONG).show();
                    return;
                }
                if(snap==null) return;
                for(DocumentSnapshot d:snap.getDocuments()) mergeCloudLoanRequest(d);
                initialCloudRequestsDone=true;
                refreshAfterCloudChange();
            });
    }

    private void mergeCloudLoanRequest(DocumentSnapshot d){
        String id=d.getId(); String uid=d.getString("requesterUid");
        String name=d.getString("name"); if(name==null) return;
        LoanRequest existing=null; for(LoanRequest r:loanRequests) if(r.id.equals(id)){ existing=r; break; }
        boolean wasNew=(existing==null);
        if(existing==null){ existing=new LoanRequest(uid==null?"":uid,name,d.getString("phone")==null?"":d.getString("phone"),number(d.get("amount")),(int)number(d.get("days")),d.getString("reason")==null?"":d.getString("reason")); existing.id=id; loanRequests.add(existing); }
        String oldStatus=existing.status;
        existing.requesterUid=uid==null?existing.requesterUid:uid; existing.clientId=d.getString("clientId")==null?existing.clientId:d.getString("clientId");
        existing.name=name; existing.phone=d.getString("phone")==null?"":d.getString("phone"); existing.amount=number(d.get("amount")); existing.days=(int)number(d.get("days")); existing.reason=d.getString("reason")==null?"":d.getString("reason"); existing.status=d.getString("status")==null?"EN_ATTENTE":d.getString("status"); existing.date=longNumber(d.get("date")); existing.updatedAt=longNumber(d.get("updatedAt")); saveData();
        if(clientMode && existing!=null && !oldStatus.equals(existing.status) && ("APPROUVEE".equals(existing.status) || "REFUSEE".equals(existing.status))){
            localNotification("Mise à jour de votre demande", "Votre demande de prêt est maintenant : "+existing.status);
        }
        if(adminSession && wasNew && initialCloudRequestsDone){
            localNotification("Nouvelle demande client", existing.name+" a envoyé une demande de prêt de "+fmt(existing.amount)+" FBu.");
        }
    }

    private void uploadLoanRequest(LoanRequest r){
        if(firestore==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",r.id); m.put("requesterUid",r.requesterUid); m.put("clientId",r.clientId); m.put("name",r.name); m.put("phone",r.phone); m.put("amount",r.amount); m.put("days",r.days); m.put("reason",r.reason); m.put("status",r.status); m.put("date",r.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_loan_requests").document(r.id).set(m)
            .addOnSuccessListener(v->{
                // La demande est maintenant confirmée dans Firestore.
            })
            .addOnFailureListener(e->{
                Toast.makeText(this,"Échec de synchronisation de la demande vers Firebase : "+e.getMessage(),Toast.LENGTH_LONG).show();
            });
    }

    private void mergeCloudClient(DocumentSnapshot d){
        String id=d.getId();
        String name=d.getString("name");
        String phone=d.getString("phone");
        if(name==null) return;
        for(Client c:clients) if(c.id.equals(id)){ c.name=name; c.phone=phone==null?"":phone; return; }
        clients.add(new Client(id,name,phone==null?"":phone));
        saveData();
    }

    private void mergeCloudLoan(DocumentSnapshot d){
        String id=d.getId();
        String clientId=d.getString("clientId");
        if(clientId==null || clientId.isEmpty()) return;
        Client c=findClient(clientId);
        // Important : un prêt peut arriver avant le document client sur un autre téléphone.
        // Le document du prêt contient donc aussi le nom/téléphone du client comme secours.
        if(c==null){
            String cloudName=d.getString("clientName");
            String cloudPhone=d.getString("clientPhone");
            if(cloudName!=null && !cloudName.trim().isEmpty()){
                c=new Client(clientId,cloudName.trim(),cloudPhone==null?"":cloudPhone);
                clients.add(c);
                saveData();
            } else {
                pendingCloudLoans.put(id,d);
                return;
            }
        }
        double principal=number(d.get("principal"));
        double rate=number(d.get("rate"));
        int days=(int)number(d.get("days"));
        long when=longNumber(d.get("date"));
        for(Loan l:loans) if(l.id.equals(id)){ l.c=c; l.principal=principal; l.rate=rate; l.days=days; l.date=when; return; }
        Loan l=new Loan(c,principal,rate,days,when); l.id=id; loans.add(l); saveData();
    }

    private void retryPendingCloudLoans(){
        if(pendingCloudLoans.isEmpty()) return;
        ArrayList<DocumentSnapshot> waiting=new ArrayList<>(pendingCloudLoans.values());
        pendingCloudLoans.clear();
        for(DocumentSnapshot d:waiting) mergeCloudLoan(d);
    }

    private void mergeCloudPayment(DocumentSnapshot d){
        String id=d.getId();
        String loanId=d.getString("loanId");
        if(loanId==null || loanId.isEmpty()) return;
        Loan l=findLoan(loanId);
        // Même protection pour un remboursement reçu avant le prêt correspondant.
        if(l==null){
            pendingCloudPayments.put(id,d);
            return;
        }
        double amount=number(d.get("amount"));
        long when=longNumber(d.get("date"));
        for(Payment p:payments) if(p.id.equals(id)){ p.loan=l; p.amount=amount; p.date=when; return; }
        Payment p=new Payment(l,amount,when); p.id=id; payments.add(p); saveData();
    }

    private void retryPendingCloudPayments(){
        if(pendingCloudPayments.isEmpty()) return;
        ArrayList<DocumentSnapshot> waiting=new ArrayList<>(pendingCloudPayments.values());
        pendingCloudPayments.clear();
        for(DocumentSnapshot d:waiting) mergeCloudPayment(d);
    }

    private double number(Object value){ return value instanceof Number ? ((Number)value).doubleValue() : 0; }
    private long longNumber(Object value){ return value instanceof Number ? ((Number)value).longValue() : System.currentTimeMillis(); }

    private Client findClient(String id){ for(Client c:clients) if(c.id.equals(id)) return c; return null; }
    private Loan findLoan(String id){ for(Loan l:loans) if(l.id.equals(id)) return l; return null; }

    private void uploadAllClients(){ for(Client c:clients) uploadClient(c); }
    private void uploadAllLoans(){ for(Loan l:loans) uploadLoan(l); }
    private void uploadAllPayments(){ for(Payment p:payments) uploadPayment(p); }
    private void uploadAllLoanRequests(){ for(LoanRequest r:loanRequests) uploadLoanRequest(r); }

    private void uploadClient(Client c){
        if(firestore==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",c.id); m.put("name",c.name); m.put("phone",c.phone); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_clients").document(c.id).set(m);
    }

    private void uploadLoan(Loan l){
        if(firestore==null || l.c==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",l.id); m.put("clientId",l.c.id); m.put("clientName",l.c.name); m.put("clientPhone",l.c.phone); m.put("principal",l.principal); m.put("rate",l.rate); m.put("days",l.days); m.put("date",l.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_loans").document(l.id).set(m);
    }

    private void uploadPayment(Payment p){
        if(firestore==null || p.loan==null) return;
        Map<String,Object> m=new HashMap<>(); m.put("id",p.id); m.put("loanId",p.loan.id); m.put("amount",p.amount); m.put("date",p.date); m.put("updatedAt",System.currentTimeMillis());
        firestore.collection("yb_payments").document(p.id).set(m);
    }

    private void refreshAfterCloudChange(){
        runOnUiThread(()->{
            if(clientMode && loanRequestsListener!=null){
                clientRequestsPage();
            } else if(adminSession && loanRequestsListener!=null){
                bureauRequestsPage();
            } else if(body!=null){
                body.invalidate();
            }
        });
    }

    void base(String name,int color){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),0,dp(8),0); bar.setBackgroundColor(color);
        TextView back=tv("‹",30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->home());
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(60)));
        TextView title=tv(name,19); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(60),1)); root.addView(bar);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(18));
        ScrollView sv=new ScrollView(this); sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showSplash(){
        if(loanRequestsListener!=null){ loanRequestsListener.remove(); loanRequestsListener=null; }
        clientMode=false;
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this); im.setImageResource(R.drawable.logo_youngests_business); im.setScaleType(ImageView.ScaleType.CENTER_INSIDE); im.setPadding(dp(18),dp(18),dp(18),dp(8));
        root.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        TextView intro=tv("Choisissez votre espace",18); intro.setGravity(Gravity.CENTER); intro.setTypeface(null,Typeface.BOLD); root.addView(intro);
        Button bureau=btn("🏢 ESPACE BUREAU",NAVY); bureau.setOnClickListener(v->requireAdmin(()->{ clientMode=false; startBureauCloudSync(); home(); })); root.addView(bureau,new LinearLayout.LayoutParams(-1,dp(58)));
        Button client=btn("👤 ESPACE CLIENT",GREEN); client.setOnClickListener(v->{ clientMode=true; startCloudSync(); clientHome(); }); root.addView(client,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView note=tv("L’espace client est en phase pilote. Une authentification client renforcée et des règles serveur dédiées seront nécessaires avant ouverture publique.",12); note.setGravity(Gravity.CENTER); root.addView(note);
        setContentView(root);
    }

    void home(){
        base("YOUNGEST'S BUSINESS",NAVY);

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(20),dp(4),dp(20),dp(4));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(105)));

        TextView welcome=tv("Bienvenue 👋\nGestion des prêts et services financiers",19);
        welcome.setTypeface(null,Typeface.BOLD);
        body.addView(welcome);

        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","📒 JOURNAL OPÉRATIONS","🔄 TRANSFERTS","💵 REMBOURSEMENTS","👤 CLIENTS","🔐 ADMINISTRATION","📒 JOURNAL LUMICASH","📞 CONTACTEZ-NOUS","ℹ️ À PROPOS DE NOUS"};
        int[] cs={RED,GREEN,BLUE,BLUE,PURPLE,GOLD,NAVY,BLUE,NAVY,PURPLE};
        for(int i=0;i<names.length;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{
                if(k==0) requireAdmin(()->loanForm());
                else if(k==1) services();
                else if(k==2) requireAdmin(()->journalPage());
                else if(k==3) transfers();
                else if(k==4) requireAdmin(()->repay());
                else if(k==5) requireAdmin(()->clientsPage());
                else if(k==6) requireAdmin(()->adminDash());
                else if(k==7) requireAdmin(()->lumicashJournalPage());
                else if(k==8) contactPage();
                else aboutPage();
            });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(78); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g);

        Button pay=btn("💳 PAIEMENT",PURPLE); pay.setOnClickListener(v->requireAdmin(()->paymentPage()));
        body.addView(pay,new LinearLayout.LayoutParams(-1,dp(54)));
        Button dash=btn("📊 TABLEAU DE BORD — ADMIN",NAVY); dash.setOnClickListener(v->requireAdmin(()->dashboard()));
        body.addView(dash,new LinearLayout.LayoutParams(-1,dp(52)));
        Button notifications=btn("🔔 NOTIFICATIONS",BLUE); notifications.setOnClickListener(v->showNotificationsPage());
        body.addView(notifications,new LinearLayout.LayoutParams(-1,dp(52)));
        int pendingRequests=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingRequests++;
        Button requests=btn("📥 DEMANDES CLIENTS — "+pendingRequests+" EN ATTENTE",GREEN); requests.setOnClickListener(v->requireAdmin(()->bureauRequestsPage()));
        body.addView(requests,new LinearLayout.LayoutParams(-1,dp(54)));
        body.addView(tv("🔒 Les données de gestion sont protégées par l’accès administrateur.\nCette version utilise une authentification locale ; une sécurité serveur sera nécessaire avant tout déploiement financier réel.",14));
    }

    // YOUNGEST'S B WIFI V53: branded configuration and tariff management; router actions remain disabled until secure integration.
    void wifiAdminPage(){
        base("YOUNGEST’S B WIFI",BLUE);
        ImageView wifiLogo=new ImageView(this);
        wifiLogo.setImageResource(R.drawable.youngests_b_wifi_logo);
        wifiLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        wifiLogo.setPadding(dp(24),dp(4),dp(24),dp(4));
        body.addView(wifiLogo,new LinearLayout.LayoutParams(-1,dp(150)));
        body.addView(tv("Gestion YOUNGEST’S B WIFI — V53",21));
        body.addView(tv("Configurez les forfaits et synchronisez-les avec Firebase. Sans MikroTik/API configuré, aucun vrai code d’accès n’est créé et aucune vente réelle n’est simulée.",14));
        EditText service=input("Nom du service",android.text.InputType.TYPE_CLASS_TEXT); service.setText("YOUNGEST'S B WIFI"); body.addView(service);
        EditText currency=input("Devise des tarifs (CDF ou USD)",android.text.InputType.TYPE_CLASS_TEXT); currency.setText("CDF"); body.addView(currency);
        EditText antenna=input("Emplacement / nom de l’antenne",android.text.InputType.TYPE_CLASS_TEXT); body.addView(antenna);
        EditText router=input("Adresse MikroTik (à configurer)",android.text.InputType.TYPE_CLASS_TEXT); body.addView(router);
        EditText ssid=input("Nom du réseau Wi-Fi (SSID)",android.text.InputType.TYPE_CLASS_TEXT); body.addView(ssid);
        EditText notes=input("Notes de configuration",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE); notes.setMinLines(2); body.addView(notes);
        body.addView(tv("FORFAITS ET TARIFS",19));
        EditText price4=input("4 heures — prix (défaut 2000 FC)",android.text.InputType.TYPE_CLASS_NUMBER); price4.setText("2000"); body.addView(price4);
        EditText price8=input("8 heures — prix (défaut 3500 FC)",android.text.InputType.TYPE_CLASS_NUMBER); price8.setText("3500"); body.addView(price8);
        EditText price12=input("12 heures — prix (défaut 5000 FC)",android.text.InputType.TYPE_CLASS_NUMBER); price12.setText("5000"); body.addView(price12);
        EditText price24=input("24 heures — prix (défaut 8000 FC)",android.text.InputType.TYPE_CLASS_NUMBER); price24.setText("8000"); body.addView(price24);
        Button save=btn("💾 ENREGISTRER CONFIGURATION",GREEN); body.addView(save,new LinearLayout.LayoutParams(-1,dp(54)));
        Button saveTariffs=btn("🎟️ ENREGISTRER LES FORFAITS DANS FIREBASE",BLUE); body.addView(saveTariffs,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView state=tv("État matériel : NON CONFIGURÉ — aucun coupon réel créé",16); state.setTextColor(RED); body.addView(state);
        body.addView(tv("La vente et l’activation de coupons réels nécessitent une intégration sécurisée avec MikroTik.",13));
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        firestore.collection("yb_wifi_config").document("main").get().addOnSuccessListener(d->{if(d.exists()){
            service.setText(d.getString("serviceName")!=null?d.getString("serviceName"):"YOUNGEST'S B WIFI");
            currency.setText(d.getString("currency")!=null?d.getString("currency"):"CDF");
            antenna.setText(d.getString("antennaLocation")!=null?d.getString("antennaLocation"):"");
            router.setText(d.getString("routerAddress")!=null?d.getString("routerAddress"):"");
            ssid.setText(d.getString("ssid")!=null?d.getString("ssid"):"");
            notes.setText(d.getString("notes")!=null?d.getString("notes"):"");
            state.setText("Configuration chargée — matériel NON CONFIGURÉ");
        }}).addOnFailureListener(e->Toast.makeText(this,"Lecture Wi-Fi : "+e.getMessage(),Toast.LENGTH_LONG).show());
        String[] ids={"4h","8h","12h","24h"};
        EditText[] prices={price4,price8,price12,price24};
        for(int i=0;i<ids.length;i++){final EditText field=prices[i];final String id=ids[i];firestore.collection("yb_wifi_profiles").document(id).get().addOnSuccessListener(d->{if(d.exists()&&d.get("price") instanceof Number)field.setText(String.valueOf(((Number)d.get("price")).longValue()));});}
        save.setOnClickListener(v->{java.util.Map<String,Object> m=new java.util.HashMap<>();
            m.put("serviceName",service.getText().toString().trim());
            m.put("currency",currency.getText().toString().trim().toUpperCase(java.util.Locale.ROOT));
            m.put("antennaLocation",antenna.getText().toString().trim());m.put("routerAddress",router.getText().toString().trim());
            m.put("ssid",ssid.getText().toString().trim());m.put("notes",notes.getText().toString().trim());
            m.put("hardwareReady",false);m.put("hardwareStatus","NOT_CONFIGURED");
            m.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
            m.put("updatedBy",firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getEmail():"admin");
            firestore.collection("yb_wifi_config").document("main").set(m,com.google.firebase.firestore.SetOptions.merge()).addOnSuccessListener(x->{state.setText("Configuration enregistrée — matériel NON CONFIGURÉ");Toast.makeText(this,"Configuration Wi-Fi synchronisée avec Firebase.",Toast.LENGTH_LONG).show();}).addOnFailureListener(e->Toast.makeText(this,"Échec d’enregistrement : "+e.getMessage(),Toast.LENGTH_LONG).show());
        });
        saveTariffs.setOnClickListener(v->{try{
            long[] values=new long[4];for(int i=0;i<4;i++){values[i]=Long.parseLong(prices[i].getText().toString().trim());if(values[i]<=0)throw new IllegalArgumentException("Les tarifs doivent être supérieurs à zéro.");}
            String cur=currency.getText().toString().trim().toUpperCase(java.util.Locale.ROOT);if(!cur.equals("CDF")&&!cur.equals("USD"))throw new IllegalArgumentException("Devise autorisée : CDF ou USD.");
            int[] hours={4,8,12,24};com.google.firebase.firestore.WriteBatch batch=firestore.batch();
            for(int i=0;i<ids.length;i++){java.util.Map<String,Object> profile=new java.util.HashMap<>();profile.put("id",ids[i]);profile.put("name",hours[i]+" heures");profile.put("durationHours",hours[i]);profile.put("price",values[i]);profile.put("currency",cur);profile.put("active",true);profile.put("singleUse",true);profile.put("shareable",false);profile.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());profile.put("updatedBy",firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getEmail():"admin");batch.set(firestore.collection("yb_wifi_profiles").document(ids[i]),profile,com.google.firebase.firestore.SetOptions.merge());}
            batch.commit().addOnSuccessListener(x->{state.setText("4 forfaits synchronisés — matériel NON CONFIGURÉ");Toast.makeText(this,"Les 4 forfaits ont été enregistrés dans Firebase.",Toast.LENGTH_LONG).show();}).addOnFailureListener(e->Toast.makeText(this,"Échec d’enregistrement des tarifs : "+e.getMessage(),Toast.LENGTH_LONG).show());
        }catch(Exception e){Toast.makeText(this,"Vérifiez les quatre tarifs et la devise : "+e.getMessage(),Toast.LENGTH_LONG).show();}});

        // V54: Android parity for Wi-Fi coupons, manual sales, audit trail, cash reconciliation and PDF reports.
        body.addView(tv("COUPONS — REGISTRE ET CRÉATION",19));
        EditText couponHours=input("Forfait du coupon (4, 8, 12 ou 24 heures)",android.text.InputType.TYPE_CLASS_NUMBER); couponHours.setText("4"); body.addView(couponHours);
        EditText couponQty=input("Nombre de coupons à préparer (1 à 50)",android.text.InputType.TYPE_CLASS_NUMBER); couponQty.setText("1"); body.addView(couponQty);
        EditText couponNote=input("Note / référence client (facultatif)",android.text.InputType.TYPE_CLASS_TEXT); body.addView(couponNote);
        TextView couponStatus=tv("Les coupons préparés ne sont pas des accès réseau tant que MikroTik n’est pas intégré.",13); body.addView(couponStatus);
        Button makeCoupons=btn("🎟️ PRÉPARER LES COUPONS UNIQUES",GREEN); body.addView(makeCoupons,new LinearLayout.LayoutParams(-1,dp(52)));
        makeCoupons.setOnClickListener(v->{try{
            int h=Integer.parseInt(couponHours.getText().toString().trim()); int qty=Integer.parseInt(couponQty.getText().toString().trim());
            if(!(h==4||h==8||h==12||h==24))throw new IllegalArgumentException("Forfait autorisé : 4, 8, 12 ou 24 heures.");
            if(qty<1||qty>50)throw new IllegalArgumentException("Choisissez entre 1 et 50 coupons par opération.");
            firestore.collection("yb_wifi_profiles").document(h+"h").get().addOnSuccessListener(profileDoc->{
                if(!profileDoc.exists()){Toast.makeText(this,"Enregistrez d’abord les tarifs Wi-Fi.",Toast.LENGTH_LONG).show();return;}
                long amount=profileDoc.get("price") instanceof Number?((Number)profileDoc.get("price")).longValue():0;
                String cur=profileDoc.getString("currency")==null?"CDF":profileDoc.getString("currency");
                com.google.firebase.firestore.WriteBatch batch=firestore.batch(); java.util.List<String> codes=new java.util.ArrayList<>();
                String actor=firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getEmail():"admin";
                for(int i=0;i<qty;i++){String code="YB"+h+"H-"+java.util.UUID.randomUUID().toString().replace("-","").substring(0,8).toUpperCase(java.util.Locale.ROOT);codes.add(code);
                    com.google.firebase.firestore.DocumentReference ref=firestore.collection("yb_wifi_coupons").document(); java.util.Map<String,Object> c=new java.util.HashMap<>();
                    c.put("code",code);c.put("profileId",h+"h");c.put("profileName",h+" heures");c.put("durationHours",h);c.put("price",amount);c.put("currency",cur);c.put("status","PREPARE_NON_ACTIVE");c.put("singleUse",true);c.put("shareable",false);c.put("networkActivated",false);c.put("note",couponNote.getText().toString().trim());c.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());c.put("createdBy",actor);batch.set(ref,c);
                    com.google.firebase.firestore.DocumentReference audit=firestore.collection("yb_wifi_audit_logs").document();java.util.Map<String,Object>a=new java.util.HashMap<>();a.put("action","COUPON_PREPARED");a.put("couponCode",code);a.put("profileId",h+"h");a.put("actor",actor);a.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.set(audit,a);
                }
                batch.commit().addOnSuccessListener(done->{couponStatus.setText("Création confirmée : "+codes.size()+" référence(s) préparée(s). Exemple : "+codes.get(0)+". Aucune activation réseau.");Toast.makeText(this,"Coupons enregistrés dans Firebase.",Toast.LENGTH_LONG).show();}).addOnFailureListener(err->Toast.makeText(this,"Création impossible : "+err.getMessage(),Toast.LENGTH_LONG).show());
            }).addOnFailureListener(err->Toast.makeText(this,"Lecture du forfait impossible : "+err.getMessage(),Toast.LENGTH_LONG).show());
        }catch(Exception ex){Toast.makeText(this,"Vérifiez le forfait et la quantité : "+ex.getMessage(),Toast.LENGTH_LONG).show();}});

        body.addView(tv("VENTE MANUELLE ET CONTRÔLE DU PAIEMENT",19));
        EditText saleCode=input("Code exact du coupon préparé",android.text.InputType.TYPE_CLASS_TEXT); body.addView(saleCode);
        EditText saleReceipt=input("Référence du paiement / reçu",android.text.InputType.TYPE_CLASS_TEXT); body.addView(saleReceipt);
        EditText saleNote=input("Note de vente (facultatif)",android.text.InputType.TYPE_CLASS_TEXT); body.addView(saleNote);
        Button sell=btn("💰 ENREGISTRER UNE VENTE REÇUE",BLUE); body.addView(sell,new LinearLayout.LayoutParams(-1,dp(52)));
        sell.setOnClickListener(v->{String code=saleCode.getText().toString().trim();String receipt=saleReceipt.getText().toString().trim();if(code.isEmpty()||receipt.isEmpty()){Toast.makeText(this,"Le code et la référence de paiement sont obligatoires.",Toast.LENGTH_LONG).show();return;}
            firestore.collection("yb_wifi_coupons").whereEqualTo("code",code).limit(1).get().addOnSuccessListener(found->{if(found.isEmpty()){Toast.makeText(this,"Coupon introuvable.",Toast.LENGTH_LONG).show();return;}com.google.firebase.firestore.DocumentSnapshot c=found.getDocuments().get(0);if(!"PREPARE_NON_ACTIVE".equals(c.getString("status"))){Toast.makeText(this,"Coupon déjà vendu ou indisponible : aucune vente créée.",Toast.LENGTH_LONG).show();return;}
                String actor=firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getEmail():"admin";String currencyValue=c.getString("currency")==null?"CDF":c.getString("currency");long amount=c.get("price") instanceof Number?((Number)c.get("price")).longValue():0;
                com.google.firebase.firestore.DocumentReference sale=firestore.collection("yb_wifi_sales").document();com.google.firebase.firestore.WriteBatch batch=firestore.batch();java.util.Map<String,Object> m=new java.util.HashMap<>();m.put("reference",receipt);m.put("couponId",c.getId());m.put("couponCode",code);m.put("profileId",c.getString("profileId"));m.put("profileName",c.getString("profileName"));m.put("durationHours",c.get("durationHours"));m.put("amount",amount);m.put("currency",currencyValue);m.put("status","CONFIRMEE");m.put("paymentConfirmedManually",true);m.put("networkActivated",false);m.put("note",saleNote.getText().toString().trim());m.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());m.put("createdBy",actor);batch.set(sale,m);
                batch.update(c.getReference(),"status","VENDU_NON_ACTIVE");batch.update(c.getReference(),"saleId",sale.getId());batch.update(c.getReference(),"soldAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(c.getReference(),"soldBy",actor);batch.update(c.getReference(),"networkActivated",false);
                com.google.firebase.firestore.DocumentReference audit=firestore.collection("yb_wifi_audit_logs").document();java.util.Map<String,Object>a=new java.util.HashMap<>();a.put("action","SALE_CONFIRMED_MANUALLY");a.put("couponCode",code);a.put("saleId",sale.getId());a.put("amount",amount);a.put("currency",currencyValue);a.put("actor",actor);a.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.set(audit,a);
                batch.commit().addOnSuccessListener(done->{Toast.makeText(this,"Vente enregistrée. Coupon vendu mais NON ACTIVÉ sur le réseau.",Toast.LENGTH_LONG).show();saleCode.setText("");saleReceipt.setText("");saleNote.setText("");}).addOnFailureListener(err->Toast.makeText(this,"Vente non enregistrée : "+err.getMessage(),Toast.LENGTH_LONG).show());
            }).addOnFailureListener(err->Toast.makeText(this,"Recherche du coupon impossible : "+err.getMessage(),Toast.LENGTH_LONG).show());
        });

        body.addView(tv("CAISSE, STATISTIQUES ET RAPPORT PDF",19));
        EditText cashReceived=input("Montant réellement remis par l’agent (chiffres)",android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); body.addView(cashReceived);
        EditText cashAgent=input("Nom / identifiant de l’agent",android.text.InputType.TYPE_CLASS_TEXT); body.addView(cashAgent);
        EditText cashNote=input("Note de rapprochement",android.text.InputType.TYPE_CLASS_TEXT); body.addView(cashNote);
        Button reconcile=btn("🧾 ENREGISTRER LE RAPPROCHEMENT DE CAISSE",PURPLE);body.addView(reconcile,new LinearLayout.LayoutParams(-1,dp(52)));
        reconcile.setOnClickListener(v->{try{double received=Double.parseDouble(cashReceived.getText().toString().trim());if(received<0)throw new IllegalArgumentException("Montant négatif interdit.");firestore.collection("yb_wifi_sales").whereEqualTo("status","CONFIRMEE").get().addOnSuccessListener(salesSnap->{double expected=0;for(com.google.firebase.firestore.DocumentSnapshot d:salesSnap.getDocuments()){String cur=d.getString("currency");String target=currency.getText().toString().trim().toUpperCase(java.util.Locale.ROOT);if(target.equals(cur)&&d.get("amount") instanceof Number)expected+=((Number)d.get("amount")).doubleValue();}
            double finalExpected=expected;String actor=firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getEmail():"admin";java.util.Map<String,Object> r=new java.util.HashMap<>();r.put("currency",currency.getText().toString().trim().toUpperCase(java.util.Locale.ROOT));r.put("expectedAmount",finalExpected);r.put("receivedAmount",received);r.put("difference",received-finalExpected);r.put("agent",cashAgent.getText().toString().trim());r.put("note",cashNote.getText().toString().trim());r.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());r.put("createdBy",actor);r.put("salesCount",salesSnap.size());firestore.collection("yb_wifi_cash_reconciliations").add(r).addOnSuccessListener(doc->{java.util.Map<String,Object>a=new java.util.HashMap<>();a.put("action","CASH_RECONCILIATION");a.put("reconciliationId",doc.getId());a.put("expectedAmount",finalExpected);a.put("receivedAmount",received);a.put("difference",received-finalExpected);a.put("actor",actor);a.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());firestore.collection("yb_wifi_audit_logs").add(a);Toast.makeText(this,"Caisse enregistrée. Attendu : "+finalExpected+" ; remis : "+received+" ; écart : "+(received-finalExpected)+". Vérifiez la période avant validation comptable.",Toast.LENGTH_LONG).show();}).addOnFailureListener(err->Toast.makeText(this,"Rapprochement non enregistré : "+err.getMessage(),Toast.LENGTH_LONG).show());
        }).addOnFailureListener(err->Toast.makeText(this,"Calcul de caisse impossible : "+err.getMessage(),Toast.LENGTH_LONG).show());}catch(Exception ex){Toast.makeText(this,"Montant invalide : "+ex.getMessage(),Toast.LENGTH_LONG).show();}});
        Button wifiStats=btn("📊 CALCULER LES STATISTIQUES ET EXPORTER PDF",NAVY);body.addView(wifiStats,new LinearLayout.LayoutParams(-1,dp(52)));
        wifiStats.setOnClickListener(v->{firestore.collection("yb_wifi_sales").get().addOnSuccessListener(snap->{StringBuilder report=new StringBuilder();report.append("RAPPORT YOUNGEST’S B WIFI — V54\nGénéré le : ").append(new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault()).format(new java.util.Date())).append("\nMatériel MikroTik : NON CONFIGURÉ / NON VALIDÉ\n\n");long total=0;int count=0;java.util.Map<Integer,Integer> byHour=new java.util.TreeMap<>();java.util.Map<Integer,Long> byPlan=new java.util.TreeMap<>();for(com.google.firebase.firestore.DocumentSnapshot d:snap.getDocuments()){if(!"CONFIRMEE".equals(d.getString("status")))continue;count++;if(d.get("amount") instanceof Number)total+=((Number)d.get("amount")).longValue();Object h=d.get("durationHours");int hours=h instanceof Number?((Number)h).intValue():0;byPlan.put(hours,byPlan.getOrDefault(hours,0L)+(d.get("amount") instanceof Number?((Number)d.get("amount")).longValue():0));Object created=d.get("createdAt");if(created instanceof com.google.firebase.Timestamp){int hour=((com.google.firebase.Timestamp)created).toDate().getHours();byHour.put(hour,byHour.getOrDefault(hour,0)+1);}}
            report.append("VENTES CONFIRMÉES (historique chargé) : ").append(count).append("\nRECETTES CONFIRMÉES (devises non converties) : ").append(total).append("\n\nRECETTES PAR FORFAIT :\n");for(java.util.Map.Entry<Integer,Long> e:byPlan.entrySet())report.append(e.getKey()).append(" h : ").append(e.getValue()).append("\n");report.append("\nNOMBRE DE VENTES PAR HEURE (historique chargé) :\n");for(java.util.Map.Entry<Integer,Integer> e:byHour.entrySet())report.append(String.format(java.util.Locale.ROOT,"%02dh : %d vente(s)\n",e.getKey(),e.getValue()));report.append("\nNOTE : rapport agrégé sur l'historique disponible ; séparer les devises et filtrer une période avant usage comptable officiel.\n");pendingReportPdfText=report.toString();Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");intent.putExtra(Intent.EXTRA_TITLE,"YB-WIFI-RAPPORT-V54.pdf");startActivityForResult(intent,CREATE_REPORT_PDF);
        }).addOnFailureListener(err->Toast.makeText(this,"Lecture des ventes impossible : "+err.getMessage(),Toast.LENGTH_LONG).show());});
        body.addView(tv("SÉCURITÉ ET ÉTAT RÉEL",16));
        body.addView(tv("Toutes les ventes ci-dessus sont saisies manuellement. Le coupon reste NON ACTIVÉ ; la connexion réelle, l’usage unique sur le réseau, les sessions et l’expiration automatique nécessitent l’intégration MikroTik via un backend sécurisé. Les statistiques de V54 ne doivent pas être considérées comme un audit comptable définitif avant tests et séparation des devises/périodes.",13));
    }

    void clientHome(){
        base("ESPACE CLIENT",GREEN);
        if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(28),dp(2),dp(28),dp(2));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(100)));

        TextView welcome=tv("Bienvenue dans votre espace client 👋",20);
        welcome.setTypeface(null,Typeface.BOLD); body.addView(welcome);
        body.addView(tv("Que souhaitez-vous faire aujourd’hui ?",15));

        GridLayout g=new GridLayout(this); g.setColumnCount(2);
        String[] names={"💰 PRÊTS","📱 MOBILE MONEY","🔄 TRANSFERTS","💵 MES REMBOURSEMENTS","👤 MON COMPTE","📞 NOUS CONTACTER"};
        int[] cs={RED,GREEN,BLUE,PURPLE,NAVY,NAVY};
        for(int i=0;i<names.length;i++){
            Button x=btn(names[i],cs[i]); final int k=i;
            x.setOnClickListener(v->{
                if(k==0) clientRequestForm();
                else if(k==1) services();
                else if(k==2) clientTransferPage();
                else if(k==3) clientRequestsPage();
                else if(k==4) clientProfilePage();
                else contactPage();
            });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(78); p.columnSpec=GridLayout.spec(i%2,1,1); p.rowSpec=GridLayout.spec(i/2);
            p.setMargins(dp(5),dp(5),dp(5),dp(5)); g.addView(x,p);
        }
        body.addView(g);

        Button requests=btn("📋 MES DEMANDES",NAVY);
        requests.setOnClickListener(v->clientRequestsPage());
        body.addView(requests,new LinearLayout.LayoutParams(-1,dp(52)));

        Button history=btn("📜 MES TRANSFERTS",BLUE);
        history.setOnClickListener(v->clientTransferHistoryPage());
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(52)));
        Button notifications=btn("🔔 NOTIFICATIONS",BLUE); notifications.setOnClickListener(v->showNotificationsPage());
        body.addView(notifications,new LinearLayout.LayoutParams(-1,dp(52)));

        Button about=btn("ℹ️ À PROPOS DE NOUS",PURPLE);
        about.setOnClickListener(v->aboutPage());
        body.addView(about,new LinearLayout.LayoutParams(-1,dp(54)));

        body.addView(tv("L'espace client initie les transferts. Le bureau les supervise sans validation manuelle.",14));
        Button back=btn("← RETOUR",NAVY); back.setOnClickListener(v->showSplash()); body.addView(back);
    }

    // CHAT V35 : conversation client -> administration persistante via Firestore.
    // L'identité technique du client utilise Firebase Anonymous Auth ; le numéro est stocké dans la conversation.
    private boolean isChatAdmin(){
        FirebaseUser u = firebaseAuth==null ? null : firebaseAuth.getCurrentUser();
        if(u==null) return false;
        String email=u.getEmail();
        return "StxrZBDeUodj7YVPmXRA2AbWcUF2".equals(u.getUid())
                || FIREBASE_ADMIN_EMAIL.equalsIgnoreCase(email==null?"":email.trim());
    }

    private void persistPendingChatDraft(String draft){
        pendingChatDraft=draft==null?"":draft.trim();
        prefs.edit().putString(KEY_PENDING_CHAT_DRAFT,pendingChatDraft).apply();
    }

    private void clearPendingChatDraft(){
        pendingChatDraft="";
        pendingChatPhone="";
        prefs.edit().remove(KEY_PENDING_CHAT_DRAFT).remove(KEY_PENDING_CHAT_PHONE).apply();
    }

    private void showChatDeliveryError(String action, Exception e){
        String detail=e==null?"erreur inconnue":e.getLocalizedMessage();
        if(detail==null || detail.trim().isEmpty()) detail=e==null?"erreur inconnue":e.getClass().getSimpleName();
        android.util.Log.e("YB_CHAT", action+" : "+detail, e);
        new AlertDialog.Builder(this)
            .setTitle("Chat — envoi impossible")
            .setMessage(action+"\n\n"+detail+"\n\nVotre message a été conservé. Vous pourrez réessayer sans le réécrire.")
            .setPositiveButton("OK",null).show();
    }

    private void sendClientMessageAtomic(String conversationId,String draft){
        FirebaseUser user=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
        if(user==null){
            persistPendingChatDraft(draft);
            showChatFirebaseError("Session client Firebase absente.",null);
            return;
        }
        String phone=pendingChatPhone==null?"":pendingChatPhone.trim();
        if(phone.isEmpty()){
            persistPendingChatDraft(draft);
            requestChatPhoneNumber();
            return;
        }
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        DocumentReference conversation=firestore.collection("yb_chat_conversations").document(conversationId);
        DocumentReference message=conversation.collection("messages").document();
        long now=System.currentTimeMillis();
        Map<String,Object> msg=new HashMap<>();
        msg.put("senderUid",user.getUid());
        msg.put("ownerUid",user.getUid());
        msg.put("senderRole","client");
        msg.put("text",draft);
        msg.put("createdAt",now);
        msg.put("phone",phone);
        Map<String,Object> update=new HashMap<>();
        update.put("lastMessage",draft);
        update.put("updatedAt",now);
        update.put("adminUnread",true);
        update.put("clientUnread",false);
        // V36 : ne plus utiliser de transaction pour l'envoi d'un message client.
        // Le message est écrit directement, puis la conversation est mise à jour.
        // Cela évite qu'une lecture/transaction sur le parent bloque l'écriture du message.
        message.set(msg)
            .addOnSuccessListener(ref->{
                firestore.collection("yb_chat_conversations")
                    .document(conversationId)
                    .update(update)
                    .addOnCompleteListener(t->{
                        clearPendingChatDraft();
                        openChatConversation(conversationId,false);
                        if(!t.isSuccessful()){
                            android.util.Log.e("YB_CHAT", "Message client enregistré, mais mise à jour de la conversation échouée", t.getException());
                        }
                    });
            })
            .addOnFailureListener(e->{
                persistPendingChatDraft(draft);
                openChatConversation(conversationId,false);
                showChatDeliveryError("Enregistrement du message impossible.",e);
            });
    }

    private void createConversationAndSendDraft(FirebaseUser user,String draft){
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        DocumentReference conversation=firestore.collection("yb_chat_conversations").document();
        DocumentReference message=conversation.collection("messages").document();
        long now=System.currentTimeMillis();
        Map<String,Object> c=new HashMap<>();
        c.put("ownerUid",user.getUid());
        c.put("phone",pendingChatPhone==null?"":pendingChatPhone);
        c.put("status","OPEN");
        c.put("createdAt",now);
        c.put("updatedAt",now);
        c.put("lastMessage",draft.isEmpty()?"Conversation ouverte":draft);
        c.put("adminUnread",!draft.isEmpty());
        c.put("clientUnread",false);
        // CORRECTION CRITIQUE : créer d'abord le document parent.
        // Les règles des messages utilisent get(parentConversation()), donc le
        // premier message ne doit pas être créé dans la même transaction que son parent.
        conversation.set(c)
            .addOnSuccessListener(v->{
                if(draft.isEmpty()){
                    clearPendingChatDraft();
                    activeChatConversationId=conversation.getId();
                    openChatConversation(conversation.getId(),false);
                    return;
                }

                Map<String,Object> msg=new HashMap<>();
                msg.put("senderUid",user.getUid());
                msg.put("ownerUid",user.getUid());
                msg.put("senderRole","client");
                msg.put("text",draft);
                msg.put("createdAt",System.currentTimeMillis());
                msg.put("phone",pendingChatPhone==null?"":pendingChatPhone);

                message.set(msg)
                    .addOnSuccessListener(ref->{
                        clearPendingChatDraft();
                        activeChatConversationId=conversation.getId();
                        openChatConversation(conversation.getId(),false);
                    })
                    .addOnFailureListener(e->{
                        persistPendingChatDraft(draft);
                        activeChatConversationId=conversation.getId();
                        openChatConversation(conversation.getId(),false);
                        showChatDeliveryError("Conversation créée, mais message non enregistré.",e);
                    });
            })
            .addOnFailureListener(e->{
                persistPendingChatDraft(draft);
                showChatDeliveryError("Création de la conversation impossible.",e);
            });
    }

    private void openChatEntry(){
        try{
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();
            FirebaseUser user=firebaseAuth.getCurrentUser();
            if(user!=null && isChatAdmin()){ adminChatInbox(); return; }
            if(user==null){
                firebaseAuth.signInAnonymously().addOnCompleteListener(this,task->{
                    if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                        clientUid=firebaseAuth.getCurrentUser().getUid();
                        requestChatPhoneNumber();
                    }else{
                        showChatFirebaseError("Connexion client impossible.",task.getException());
                    }
                });
                return;
            }
            clientUid=user.getUid();
            requestChatPhoneNumber();
        }catch(Exception e){
            showChatFirebaseError("Ouverture du chat impossible.",e);
        }
    }

    private void requestChatPhoneNumber(){
        EditText phone=new EditText(this);
        phone.setSingleLine(true);
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        phone.setHint("Ex. +243812345678");
        if(pendingChatPhone!=null && !pendingChatPhone.isEmpty()) phone.setText(pendingChatPhone);
        new AlertDialog.Builder(this).setTitle("💬 Accéder au chat")
            .setMessage("Entrez votre numéro international. Il sera associé à votre conversation client.")
            .setView(phone).setNegativeButton("ANNULER",(d,w)->showSplash())
            .setPositiveButton("ACCÉDER AU CHAT",(d,w)->{
                String number=phone.getText().toString().trim().replace(" ","").replace("-","");
                if(!number.matches("^\\+[1-9][0-9]{7,14}$")){
                    Toast.makeText(this,"Utilisez le format international, par exemple +243…",Toast.LENGTH_LONG).show();
                    requestChatPhoneNumber(); return;
                }
                pendingChatPhone=number;
                prefs.edit().putString(KEY_PENDING_CHAT_PHONE,number).apply();
                openOrCreateClientConversation();
            }).show();
    }

    private void sendChatVerificationCode(String number){
        // V35 : le Chat client ne dépend plus de Phone Authentication.
        // L'identité Firebase anonyme existante est utilisée pour garantir la livraison.
        pendingChatPhone=number==null?"":number.trim();
        prefs.edit().putString(KEY_PENDING_CHAT_PHONE,pendingChatPhone).apply();
        openOrCreateClientConversation();
    }

    private void requestChatSmsCode(){
        // Conservé pour compatibilité avec les anciennes versions.
        requestChatPhoneNumber();
    }

    private void signInChatPhone(PhoneAuthCredential credential){
        // Conservé pour compatibilité source V33/V34. Le flux V35 n'appelle plus Phone Auth.
        openOrCreateClientConversation();
    }

    private void showChatFirebaseError(String action, Exception e){
        String detail=e==null?"erreur inconnue":e.getLocalizedMessage();
        if(detail==null || detail.trim().isEmpty()) detail=e==null?"erreur inconnue":e.getClass().getSimpleName();
        android.util.Log.e("YB_CHAT", action+" : "+detail, e);
        new AlertDialog.Builder(this)
            .setTitle("Chat — erreur")
            .setMessage(action+"\n\n"+detail+"\n\nSi cette erreur mentionne les règles Firestore, les règles du projet Firebase doivent être déployées. Si elle mentionne Phone Auth/SMS, vérifiez l'authentification Téléphone et les empreintes SHA de l'APK signé.")
            .setPositiveButton("OK",null).show();
    }

    private void openOrCreateClientConversation(){
        FirebaseUser user=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
        if(user==null){
            try{
                firebaseAuth=FirebaseAuth.getInstance();
                firebaseAuth.signInAnonymously().addOnCompleteListener(this,task->{
                    if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null) openOrCreateClientConversation();
                    else showChatFirebaseError("Connexion client impossible.",task.getException());
                });
            }catch(Exception e){ showChatFirebaseError("Connexion client impossible.",e); }
            return;
        }
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        clientUid=user.getUid();
        final String draft=pendingChatDraft==null?"":pendingChatDraft.trim();
        final String phone=pendingChatPhone==null?"":pendingChatPhone.trim();
        if(phone.isEmpty()){
            requestChatPhoneNumber();
            return;
        }
        firestore.collection("yb_chat_conversations").whereEqualTo("ownerUid",user.getUid()).limit(1).get()
            .addOnSuccessListener(snapshot->{
                if(!snapshot.isEmpty()){
                    openClientConversationWithDraft(snapshot.getDocuments().get(0).getId());
                }else{
                    createConversationAndSendDraft(user,draft);
                }
            })
            .addOnFailureListener(e->showChatFirebaseError("Lecture des conversations impossible.",e));
    }

    private void openClientConversationWithDraft(String conversationId){
        String draft=pendingChatDraft==null?"":pendingChatDraft.trim();
        if(draft.isEmpty()){ openChatConversation(conversationId,false); return; }
        sendClientMessageAtomic(conversationId,draft);
    }

    private void adminChatInbox(){
        if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
        if(!isChatAdmin()){
            Toast.makeText(this,"Accès réservé au compte administrateur Firebase autorisé.",Toast.LENGTH_LONG).show(); return;
        }
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        if(chatListListener!=null){chatListListener.remove();chatListListener=null;}
        base("BOÎTE DE RÉCEPTION CHAT",NAVY);
        body.addView(tv("💬 CONVERSATIONS CLIENTS",21));
        body.addView(tv("Sélectionnez une conversation pour répondre. Les clients ne peuvent consulter que leur propre conversation.",14));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        chatListListener=firestore.collection("yb_chat_conversations")
            .addSnapshotListener((snap,error)->runOnUiThread(()->{
                list.removeAllViews();
                if(error!=null){
                    list.addView(tv("Erreur de lecture Firestore : "+(error.getLocalizedMessage()==null?"accès refusé ou connexion indisponible":error.getLocalizedMessage()),14));
                    return;
                }
                if(snap==null || snap.isEmpty()){
                    list.addView(tv("Aucune conversation pour le moment.",15));
                    return;
                }
                ArrayList<DocumentSnapshot> docs=new ArrayList<>(snap.getDocuments());
                Collections.sort(docs,(a,b)->Long.compare(
                    b.getLong("updatedAt")==null?0L:b.getLong("updatedAt"),
                    a.getLong("updatedAt")==null?0L:a.getLong("updatedAt")));
                for(DocumentSnapshot doc:docs){
                    String id=doc.getId();
                    String ph=doc.getString("phone");
                    String last=doc.getString("lastMessage");
                    String status=doc.getString("status");
                    boolean unread=Boolean.TRUE.equals(doc.getBoolean("adminUnread"));
                    String title=(unread?"🔴 NOUVEAU — ":"")+"📱 "+(ph==null||ph.isEmpty()?"Client":ph);
                    String text=(last==null||last.isEmpty()?"Aucun message":last);
                    Button item=btn(title+"\n"+text+"\nStatut : "+(status==null?"OPEN":status),unread?GREEN:BLUE);
                    item.setOnClickListener(v->openChatConversation(id,true));
                    list.addView(item,new LinearLayout.LayoutParams(-1,dp(82)));
                }
            }));
        Button back=btn("← RETOUR AU BUREAU",NAVY);
        back.setOnClickListener(v->{if(chatListListener!=null){chatListListener.remove();chatListListener=null;}home();});
        body.addView(back);
    }

    private void openChatConversation(String conversationId,boolean admin){
        activeChatConversationId=conversationId;
        if(chatMessagesListener!=null){chatMessagesListener.remove();chatMessagesListener=null;}
        base(admin?"CHAT CLIENT — ADMIN":"CHAT SERVICE CLIENT",admin?NAVY:BLUE);
        body.addView(tv(admin?"Réponse du service client":"Posez votre question à YOUNGEST’S BUSINESS",19));
        LinearLayout messages=new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); body.addView(messages);
        EditText input=new EditText(this); input.setHint("Écrire votre message…"); input.setMinLines(1); input.setMaxLines(4);
        body.addView(input,new LinearLayout.LayoutParams(-1,dp(54)));
        Button send=btn("ENVOYER LE MESSAGE",GREEN); body.addView(send,new LinearLayout.LayoutParams(-1,dp(52)));
        send.setOnClickListener(v->{
            String text=input.getText().toString().trim(); FirebaseUser user=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
            if(text.isEmpty()){
                Toast.makeText(this,"Écrivez un message avant l’envoi.",Toast.LENGTH_SHORT).show();
                return;
            }
            if(user==null){
                if(admin){ Toast.makeText(this,"Session administrateur expirée. Reconnectez-vous.",Toast.LENGTH_LONG).show(); }
                else { persistPendingChatDraft(text); Toast.makeText(this,"Renseignez votre numéro pour envoyer ce message.",Toast.LENGTH_LONG).show(); requestChatPhoneNumber(); }
                return;
            }
            send.setEnabled(false);
            if(!admin){
                persistPendingChatDraft(text);
                if(pendingChatPhone==null || pendingChatPhone.isEmpty()){ requestChatPhoneNumber(); send.setEnabled(true); return; }
                sendClientMessageAtomic(conversationId,text);
                input.setText("");
                send.setEnabled(true);
            } else {
                DocumentReference adminConversation=firestore.collection("yb_chat_conversations").document(conversationId);
                // V36 : la réponse Admin porte aussi ownerUid afin que le client
                // puisse la lire avec les mêmes règles que ses propres messages.
                adminConversation.get()
                    .addOnSuccessListener(conversationSnap->{
                        if(!conversationSnap.exists()){
                            send.setEnabled(true);
                            Toast.makeText(this,"Conversation introuvable.",Toast.LENGTH_LONG).show();
                            return;
                        }
                        String ownerUid=conversationSnap.getString("ownerUid");
                        if(ownerUid==null || ownerUid.trim().isEmpty()){
                            send.setEnabled(true);
                            Toast.makeText(this,"Identité du client introuvable.",Toast.LENGTH_LONG).show();
                            return;
                        }
                        Map<String,Object> m=new HashMap<>();
                        m.put("senderUid",user.getUid());
                        m.put("ownerUid",ownerUid);
                        m.put("senderRole","admin");
                        m.put("text",text);
                        m.put("createdAt",System.currentTimeMillis());
                        m.put("phone",conversationSnap.getString("phone")==null?"":conversationSnap.getString("phone"));
                        adminConversation.collection("messages").add(m)
                            .addOnSuccessListener(ref->{
                                Map<String,Object> update=new HashMap<>();
                                update.put("lastMessage",text);
                                update.put("updatedAt",System.currentTimeMillis());
                                update.put("clientUnread",true);
                                update.put("adminUnread",false);
                                adminConversation.update(update)
                                    .addOnCompleteListener(t->{
                                        input.setText("");
                                        send.setEnabled(true);
                                        if(!t.isSuccessful()){
                                            android.util.Log.e("YB_CHAT", "Réponse Admin enregistrée, mais mise à jour de la conversation échouée", t.getException());
                                        }
                                    });
                            })
                            .addOnFailureListener(e->{
                                send.setEnabled(true);
                                String detail=e.getLocalizedMessage();
                                Toast.makeText(this,"Message non envoyé : "+(detail==null?"erreur Firestore":detail),Toast.LENGTH_LONG).show();
                                android.util.Log.e("YB_CHAT", "message send failed", e);
                            });
                    })
                    .addOnFailureListener(e->{
                        send.setEnabled(true);
                        String detail=e.getLocalizedMessage();
                        Toast.makeText(this,"Conversation non accessible : "+(detail==null?"erreur Firestore":detail),Toast.LENGTH_LONG).show();
                        android.util.Log.e("YB_CHAT", "conversation read failed", e);
                    });
            }
        });
        chatMessagesListener=firestore.collection("yb_chat_conversations").document(conversationId).collection("messages")
            .orderBy("createdAt",com.google.firebase.firestore.Query.Direction.ASCENDING).addSnapshotListener((snap,error)->runOnUiThread(()->{
                messages.removeAllViews();
                if(error!=null){messages.addView(tv("Impossible de charger les messages. Vérifiez les règles Firestore.",14));return;}
                if(snap==null || snap.isEmpty()){messages.addView(tv("Début de la conversation. Écrivez votre message ci-dessous.",14));return;}
                for(DocumentSnapshot d:snap.getDocuments()){
                    String role=d.getString("senderRole"), text=d.getString("text");
                    messages.addView(tv(("admin".equals(role)?"🟦 SERVICE CLIENT":"🟩 VOUS")+"\n"+(text==null?"":text),15));
                }
            }));
        Button back=btn(admin?"← BOÎTE DE RÉCEPTION":"← RETOUR",NAVY);
        back.setOnClickListener(v->{if(chatMessagesListener!=null){chatMessagesListener.remove();chatMessagesListener=null;}if(admin)adminChatInbox();else clientHome();}); body.addView(back);
    }

    void contactPage(){
        base("CONTACTEZ-NOUS",NAVY);
        body.addView(tv("📞 COORDONNÉES ET CONTACTS",21));
        body.addView(tv("Notre équipe est à votre disposition pour vous accompagner.",15));
        body.addView(tv("📱 +257 66 79 66 15\n📱 +257 67 15 64 14\n📱 +243 817 447 127",18));
        body.addView(tv("Pour les prêts, les services Mobile Money, les transferts et toute question concernant votre compte.",15));
        body.addView(tv("💬 CHAT AVEC NOTRE SERVICE",20));
        body.addView(tv("Écrivez votre message ci-dessous. Votre numéro sera associé à votre conversation client pour permettre au service de vous répondre.",14));
        EditText message=input("Écrire votre message ici…",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        if(pendingChatDraft!=null && !pendingChatDraft.trim().isEmpty()) message.setText(pendingChatDraft);
        message.setMinLines(3); message.setMaxLines(6); message.setGravity(Gravity.TOP | Gravity.START);
        body.addView(message,new LinearLayout.LayoutParams(-1,dp(112)));
        Button chat=btn("📨 ENVOYER LE MESSAGE",BLUE);
        chat.setOnClickListener(v->{
            String draft=message.getText().toString().trim();
            if(draft.isEmpty()){ Toast.makeText(this,"Écrivez votre message avant l’envoi.",Toast.LENGTH_SHORT).show(); return; }
            persistPendingChatDraft(draft);
            Toast.makeText(this,"Préparation de l’envoi du message…",Toast.LENGTH_SHORT).show();
            openChatEntry();
        });
        body.addView(chat,new LinearLayout.LayoutParams(-1,dp(54)));
        Button back=btn("← RETOUR",NAVY);
        back.setOnClickListener(v->{if(clientMode) clientHome(); else home();});
        body.addView(back,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    void aboutPage(){
        base("À PROPOS DE NOUS",PURPLE);
        body.addView(tv("ℹ️ YOUNGEST’S BUSINESS",21));
        body.addView(tv("YOUNGEST’S BUSINESS est un service basé dans le domaine du Mobile Money, dédié à l’accompagnement financier de ses clients à travers des solutions de prêt adaptées à leurs besoins.\n\nNous accordons une importance particulière à la responsabilité, la transparence, la discipline financière et au respect des engagements.\n\nNotre objectif est d'offrir un service sérieux, confidentiel et accessible, tout en accompagnant nos clients dans une gestion financière responsable.",15));
    }

    void clientProfilePage(){
        base("MON PROFIL CLIENT",GREEN);
        body.addView(tv("👤 Vos informations",19));
        body.addView(tv("Ces informations sont utilisées pour préremplir vos prochaines demandes de prêt.",15));
        EditText n=input("Nom complet",InputType.TYPE_CLASS_TEXT);
        EditText ph=input("Téléphone du portefeuille",InputType.TYPE_CLASS_PHONE);
        Spinner walletNetwork=new Spinner(this);
        walletNetwork.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"M-Pesa","Airtel Money","Orange Money","Afrimoney"}));
        String savedNet=savedClientWalletNetwork();
        if(!savedNet.isEmpty()){
            for(int i=0;i<walletNetwork.getAdapter().getCount();i++) if(savedNet.equals(walletNetwork.getAdapter().getItem(i))) { walletNetwork.setSelection(i); break; }
        }
        n.setText(savedClientName());
        ph.setText(savedClientPhone());
        body.addView(n); body.addView(ph);
        body.addView(tv("📱 PORTEFEUILLE MOBILE MONEY ASSOCIÉ",15));
        body.addView(walletNetwork);

        Button save=btn("💾 ENREGISTRER MON PROFIL",GREEN);
        save.setOnClickListener(v->{
            String name=n.getText().toString().trim(), phone=ph.getText().toString().trim();
            if(name.isEmpty()||phone.isEmpty()){
                Toast.makeText(this,"Veuillez renseigner le nom et le téléphone.",Toast.LENGTH_SHORT).show();
                return;
            }
            String walletNet=walletNetwork.getSelectedItem()==null?"":walletNetwork.getSelectedItem().toString();
            prefs.edit().putString(clientPref("name"),name).putString(clientPref("phone"),phone).putString(clientPref("wallet_network"),walletNet).apply();
            Toast.makeText(this,"Profil enregistré.",Toast.LENGTH_SHORT).show();
            clientHome();
        });
        body.addView(save);

        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back);
    }

    private void ensureClientAuth(Runnable afterReady){
        try{
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();
            if(firebaseAuth.getCurrentUser()!=null){
                clientUid=firebaseAuth.getCurrentUser().getUid();
                if(clientMode) attachClientRequestsListener();
                afterReady.run();
                return;
            }
            Toast.makeText(this,"Connexion sécurisée en cours…",Toast.LENGTH_SHORT).show();
            firebaseAuth.signInAnonymously().addOnCompleteListener(task->{
                if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                    clientUid=firebaseAuth.getCurrentUser().getUid();
                    if(clientMode) attachClientRequestsListener();
                    afterReady.run();
                }else{
                    Toast.makeText(this,"Connexion client à Firebase impossible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
                }
            });
        }catch(Exception e){
            Toast.makeText(this,"Firebase est indisponible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
        }
    }


    private void autoFillWalletName(EditText phone, EditText name, TextView result, Spinner network){
        String p=phone.getText().toString().trim();
        if(normalizePhone(p).length()<8){ name.setText(""); result.setText("🔎 Saisissez le numéro du portefeuille."); return; }
        String net=network.getSelectedItem()==null?"":network.getSelectedItem().toString();
        WalletVerification r=verifyWalletSimulation(p,net);
        if(r.verified){
            name.setText(r.holderName);
            result.setText("✅ NOM AUTOMATIQUE : "+r.holderName+"\nPortefeuille : "+net+" — "+p+"\nSource : "+r.source);
        }else{
            name.setText("");
            result.setText("🔎 Numéro non trouvé dans le registre local.\nEn attente de l'API officielle du réseau pour une identification réelle.");
        }
    }

    void clientTransferPage(){
        base("ENVOYER DE L'ARGENT",BLUE);
        body.addView(tv("💸 TRANSFERT MOBILE MONEY — YOUNGEST'S BUSINESS",19));
        body.addView(tv("Le transfert B2C envoie l'argent depuis la caisse YOUNGEST'S BUSINESS vers le portefeuille Mobile Money du bénéficiaire. Réseaux : M-Pesa, Airtel Money, Orange Money et Afrimoney. Devises : CDF ou USD.",14));
        body.addView(tv("🔐 Sécurité : aucun PIN Mobile Money n'est demandé ni enregistré dans YOUNGEST'S BUSINESS. La clé WonyaPay reste côté serveur sécurisé.",14));

        final String[] networks={"M-Pesa","Airtel Money","Orange Money","Afrimoney"};
        final String[] currencies={"CDF — Franc congolais","USD — Dollar américain"};

        body.addView(tv("📲 RÉSEAU DU BÉNÉFICIAIRE",17));
        Spinner network=new Spinner(this);
        network.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,networks));
        body.addView(network);

        body.addView(tv("📱 NUMÉRO DU BÉNÉFICIAIRE",17));
        EditText beneficiaryPhone=input("Numéro Mobile Money (10 chiffres)",InputType.TYPE_CLASS_PHONE);
        body.addView(beneficiaryPhone);
        body.addView(tv("Le numéro est transmis à WonyaPay comme MobileMoney pour l'action B2C. Aucun PIN n'est demandé.",13));

        body.addView(tv("💰 MONTANT",17));
        Spinner currency=new Spinner(this);
        currency.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,currencies));
        EditText amount=input("Montant à envoyer",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView fee=tv("Frais estimés (2 %) : —",17);
        TextView total=tv("Total estimé à débiter : —",18);
        body.addView(currency); body.addView(amount); body.addView(fee); body.addView(total);
        TextWatcher tw=new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ updateTransferTotal(amount,fee,total,currency); }
            public void afterTextChanged(Editable e){}
        };
        amount.addTextChangedListener(tw);
        currency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ updateTransferTotal(amount,fee,total,currency); }
        });

        body.addView(tv("👤 NOM DU BÉNÉFICIAIRE (FACULTATIF)",17));
        EditText beneficiaryName=input("Nom du bénéficiaire (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        body.addView(beneficiaryName);

        body.addView(tv("📋 MOTIF / DESCRIPTION",17));
        EditText reason=input("Motif du transfert (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.addView(reason);
        body.addView(tv("⚙️ API WonyaPay : POST /payment — Action B2C. La référence de transaction est générée automatiquement côté serveur pour éviter les doublons.",13));

        Button confirm=btn("💸 ENVOYER VIA WONYA PAY",GREEN);
        confirm.setOnClickListener(v->{
            try{
                String bp=normalizePhone(beneficiaryPhone.getText().toString().trim());
                double a=Double.parseDouble(amount.getText().toString().trim());
                String net=network.getSelectedItem().toString();
                String cur=currency.getSelectedItemPosition()==1?"USD":"CDF";
                if(bp.length()!=10 || !bp.matches("[0-9]{10}") || a<=0) throw new Exception();
                double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
                Transfer t=new Transfer(cur,"YOUNGEST'S BUSINESS","","CAISSE WONYA PAY",beneficiaryName.getText().toString().trim(),bp,net,a,f,reason.getText().toString().trim());
                t.clientInitiated=true;
                t.requesterUid=clientUid==null?"":clientUid;
                t.apiStatus="PREPARATION";
                transfersList.add(t); saveData();
                submitWonyaPayTransfer(t, ()->clientTransferReceipt(t));
            }catch(Exception e){ Toast.makeText(this,"Vérifiez le réseau, le numéro à 10 chiffres et le montant.",Toast.LENGTH_LONG).show(); }
        });
        body.addView(confirm,new LinearLayout.LayoutParams(-1,dp(60)));

        Button history=btn("📜 MES TRANSFERTS",BLUE); history.setOnClickListener(v->clientTransferHistoryPage());
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(54)));
        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    private void submitWonyaPayTransfer(Transfer t, Runnable after){
        t.apiStatus="ENVOI_VERS_WONYAPAY";
        saveData();
        Map<String,Object> data=new HashMap<>();
        data.put("network",t.beneficiaryNetwork);
        data.put("mobileMoney",normalizePhone(t.beneficiaryPhone));
        data.put("amount",t.amount);
        data.put("currency",t.currency);
        data.put("reason",t.reason.isEmpty()?"Transfert YOUNGEST'S BUSINESS":t.reason);
        data.put("clientInitiated",t.clientInitiated);
        FirebaseFunctions.getInstance().getHttpsCallable("createWonyaPayTransfer").call(data)
            .addOnSuccessListener(result->{
                try{
                    Map<?,?> rootData=(Map<?,?>)result.getData();
                    boolean success=Boolean.TRUE.equals(rootData.get("success"));
                    Object d=rootData.get("data");
                    Map<?,?> out=d instanceof Map?(Map<?,?>)d:Collections.emptyMap();
                    Object statusValue=out.get("status");
                    t.apiStatus=statusValue==null?"pending":String.valueOf(statusValue);
                    Object txValue=out.get("refTransa");
                    if(txValue==null) txValue=out.get("transactionId");
                    t.providerReference=txValue==null?"":String.valueOf(txValue);
                    Object apiFee=out.get("frais");
                    if(apiFee instanceof Number) t.fees=((Number)apiFee).doubleValue();
                    if(success && isTerminalTransferStatus(t.apiStatus)) t.status="TERMINE";
                    else if(success) t.status="EN_COURS";
                    else t.status="ANNULE";
                    saveData();
                    Toast.makeText(this, success?"Transfert envoyé à WonyaPay : "+transferStatusLabel(t.status):"WonyaPay a refusé le transfert.",Toast.LENGTH_LONG).show();
                    after.run();
                }catch(Exception e){
                    t.status="EN_COURS"; t.apiStatus="REPONSE_API_INCOMPRISE"; saveData();
                    Toast.makeText(this,"Réponse WonyaPay reçue mais non interprétée. Vérifiez l'historique.",Toast.LENGTH_LONG).show();
                    after.run();
                }
            })
            .addOnFailureListener(e->{
                t.status="ANNULE"; t.apiStatus="ERREUR_API: "+(e.getMessage()==null?"inconnue":e.getMessage()); saveData();
                Toast.makeText(this,"Échec de l'envoi WonyaPay. Aucun PIN n'a été demandé.",Toast.LENGTH_LONG).show();
                after.run();
            });
    }

    private boolean isTerminalTransferStatus(String s){
        if(s==null) return false;
        String x=s.toLowerCase(Locale.US);
        return x.contains("success") || x.contains("complete") || x.contains("completed") || x.contains("successful") || x.contains("paid") || x.equals("done") || x.equals("success");
    }

    private void refreshWonyaPayStatus(Transfer t){
        if(t.providerReference==null || t.providerReference.trim().isEmpty()){
            Toast.makeText(this,"Référence WonyaPay indisponible.",Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this,"Vérification du statut WonyaPay…",Toast.LENGTH_SHORT).show();
        Map<String,Object> data=new HashMap<>();
        data.put("refTransa",t.providerReference);
        FirebaseFunctions.getInstance().getHttpsCallable("getWonyaPayStatus").call(data)
            .addOnSuccessListener(result->{
                try{
                    Map<?,?> rootData=(Map<?,?>)result.getData();
                    Object d=rootData.get("data");
                    Map<?,?> out=d instanceof Map?(Map<?,?>)d:Collections.emptyMap();
                    Object statusValue=out.get("status");
                    t.apiStatus=statusValue==null?t.apiStatus:String.valueOf(statusValue);
                    Object apiFee=out.get("frais");
                    if(apiFee instanceof Number) t.fees=((Number)apiFee).doubleValue();
                    if(isTerminalTransferStatus(t.apiStatus)) t.status="TERMINE";
                    saveData();
                    Toast.makeText(this,"Statut : "+transferStatusLabel(t.status),Toast.LENGTH_LONG).show();
                    showTransferReceipt(t);
                }catch(Exception e){ Toast.makeText(this,"Réponse de statut non reconnue.",Toast.LENGTH_LONG).show(); }
            })
            .addOnFailureListener(e->Toast.makeText(this,"Impossible de vérifier le statut : "+(e.getMessage()==null?"erreur":e.getMessage()),Toast.LENGTH_LONG).show());
    }

    void clientTransferHistoryPage(){
        base("MES TRANSFERTS",BLUE);
        String myPhone=normalizePhone(savedClientPhone());
        body.addView(tv("📜 HISTORIQUE DES TRANSFERTS INITIÉS DEPUIS VOTRE ESPACE CLIENT",19));
        int count=0;
        for(int i=transfersList.size()-1;i>=0;i--){
            Transfer t=transfersList.get(i);
            if(!t.clientInitiated || (clientUid!=null && !clientUid.isEmpty() && !clientUid.equals(t.requesterUid))) continue;
            count++;
            body.addView(tv(t.id+"  •  "+transferStatusLabel(t.status)+"\n"+t.senderNetwork+" — "+t.senderPhone+"\n→ "+t.beneficiaryNetwork+" — "+t.beneficiaryPhone+"\nMontant : "+money(t.amount,t.currency)+"\nFrais : "+money(t.fees,t.currency)+"\nTotal : "+money(t.total(),t.currency)+"\nAPI : "+t.apiStatus,14));
        }
        if(count==0) body.addView(tv("Aucun transfert client enregistré pour ce portefeuille.",15));
        Button back=btn("← ESPACE CLIENT",NAVY); back.setOnClickListener(v->clientHome()); body.addView(back);
    }

    void clientTransferReceipt(Transfer t){ showTransferReceipt(t); }


    void clientRequestForm(){
        base("DEMANDE DE PRÊT",GREEN);
        body.addView(tv("Remplissez votre demande",19));
        EditText n=input("Nom complet",InputType.TYPE_CLASS_TEXT);
        EditText ph=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        EditText a=input("Montant souhaité (FBu)",InputType.TYPE_CLASS_NUMBER);
        EditText d=input("Durée souhaitée (jours)",InputType.TYPE_CLASS_NUMBER);
        EditText r=input("Motif de la demande",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        n.setText(savedClientName());
        ph.setText(savedClientPhone());
        body.addView(n); body.addView(ph); body.addView(a); body.addView(d); body.addView(r);

        Button send=btn("ENVOYER LA DEMANDE",GREEN);
        send.setOnClickListener(v->{
            try{
                String name=n.getText().toString().trim(), phone=ph.getText().toString().trim(), reason=r.getText().toString().trim();
                double amount=Double.parseDouble(a.getText().toString().trim());
                int days=Integer.parseInt(d.getText().toString().trim());
                if(name.isEmpty()||phone.isEmpty()||amount<=0||days<=0||reason.isEmpty()) throw new Exception();

                final double requestAmount=amount;
                final int requestDays=days;
                final String requestName=name, requestPhone=phone, requestReason=reason;

                ensureClientAuth(()->{
                    if(clientUid==null||clientUid.isEmpty()){
                        Toast.makeText(this,"Connexion client à Firebase impossible. Vérifiez Internet puis réessayez.",Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs.edit().putString(clientPref("name"),requestName).putString(clientPref("phone"),requestPhone).apply();
                    LoanRequest q=new LoanRequest(clientUid,requestName,requestPhone,requestAmount,requestDays,requestReason);
                    q.clientId=clientUid;
                    loanRequests.add(q);
                    saveData();
                    uploadLoanRequest(q);
                    localNotification("Demande de prêt", "Votre demande a été envoyée au bureau pour étude.");
                    Toast.makeText(this,"Demande envoyée au bureau.",Toast.LENGTH_LONG).show();
                    clientRequestsPage();
                });
            }catch(Exception e){
                Toast.makeText(this,"Veuillez remplir correctement les champs : nom, téléphone, montant, durée et motif.",Toast.LENGTH_LONG).show();
            }
        });
        body.addView(send);

        Button my=btn("📋 VOIR MES DEMANDES",NAVY);
        my.setOnClickListener(v->clientRequestsPage());
        body.addView(my);

        Button profile=btn("👤 MODIFIER MON PROFIL",NAVY);
        profile.setOnClickListener(v->clientProfilePage());
        body.addView(profile);

        Button back=btn("← ESPACE CLIENT",NAVY);
        back.setOnClickListener(v->clientHome());
        body.addView(back);
    }

    void clientRequestsPage(){
        base("MES DEMANDES",GREEN);
        if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();

        body.addView(tv("📋 SUIVI DE VOS DEMANDES",19));
        body.addView(tv("Retrouvez ici toutes les demandes envoyées depuis ce compte client. Appuyez sur une demande pour consulter ses détails et son statut.",15));
        int totalRequests=0, pendingRequests=0, approvedRequests=0, refusedRequests=0;
        for(LoanRequest q:loanRequests){
            if(clientUid!=null && clientUid.equals(q.requesterUid)){
                totalRequests++;
                if("EN_ATTENTE".equals(q.status)) pendingRequests++;
                else if("APPROUVEE".equals(q.status)) approvedRequests++;
                else if("REFUSEE".equals(q.status)) refusedRequests++;
            }
        }
        body.addView(tv("📊 Total : "+totalRequests+"   🟡 En attente : "+pendingRequests+"   🟢 Approuvées : "+approvedRequests+"   🔴 Refusées : "+refusedRequests,14));

        boolean found=false;
        for(LoanRequest q:loanRequests){
            if(clientUid!=null && clientUid.equals(q.requesterUid)){
                found=true;
                String statusLabel=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE");
                int statusColor=q.status.equals("APPROUVEE")?GREEN:(q.status.equals("REFUSEE")?RED:NAVY);
                String subtitle=fmt(q.amount)+" FBu • "+q.days+" jours\n"+date(q.date);
                Button b=btn(statusLabel+"\n"+subtitle,statusColor);
                b.setOnClickListener(v->clientRequestDetails(q));
                body.addView(b,new LinearLayout.LayoutParams(-1,dp(92)));
            }
        }

        if(!found){
            body.addView(tv("Aucune demande enregistrée pour ce compte client.\n\nAppuyez sur « DEMANDER UN PRÊT » pour envoyer votre première demande au bureau.",16));
        }

        Button refresh=btn("🔄 ACTUALISER MES DEMANDES",NAVY);
        refresh.setOnClickListener(v->{
            if(clientMode && clientUid!=null && !clientUid.isEmpty()) attachClientRequestsListener();
            clientRequestsPage();
        });
        body.addView(refresh);

        Button newRequest=btn("📝 NOUVELLE DEMANDE DE PRÊT",GREEN);
        newRequest.setOnClickListener(v->clientRequestForm());
        body.addView(newRequest);

        Button back=btn("← ESPACE CLIENT",NAVY);
        back.setOnClickListener(v->clientHome());
        body.addView(back);
    }

    void clientRequestDetails(LoanRequest q){
        String status=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE");
        StringBuilder details=new StringBuilder();
        details.append("Statut : ").append(status)
            .append("\n\nMontant demandé : ").append(fmt(q.amount)).append(" FBu")
            .append("\nDurée souhaitée : ").append(q.days).append(" jours")
            .append("\nDate de la demande : ").append(date(q.date))
            .append("\nDernière mise à jour : ").append(date(q.updatedAt))
            .append("\nTéléphone : ").append(q.phone.isEmpty()?"Non renseigné":q.phone)
            .append("\nMotif : ").append(q.reason.isEmpty()?"Non précisé":q.reason);

        if("APPROUVEE".equals(q.status)){
            Loan approved=null;
            for(Loan l:loans){
                if(l.c!=null && q.clientId.equals(l.c.id) && Math.abs(l.principal-q.amount)<0.01 && l.days==q.days){ approved=l; break; }
            }
            if(approved!=null){
                double paid=approved.paid(payments), balance=approved.balance(payments);
                details.append("\n\n💰 MONTANT ACCORDÉ : ").append(fmt(approved.principal)).append(" FBu")
                    .append("\n📈 INTÉRÊT : ").append(fmt(approved.interest())).append(" FBu")
                    .append("\n💵 TOTAL À REMBOURSER : ").append(fmt(approved.total())).append(" FBu")
                    .append("\n📅 ÉCHÉANCE : ").append(date(approved.dueDate()))
                    .append("\n💳 DÉJÀ PAYÉ : ").append(fmt(paid)).append(" FBu")
                    .append("\n⏳ SOLDE RESTANT : ").append(fmt(balance)).append(" FBu");
            }
        }

        new AlertDialog.Builder(this)
            .setTitle("📋 DÉTAIL DE LA DEMANDE")
            .setMessage(details.toString())
            .setPositiveButton("FERMER",null)
            .show();
    }

    void dashboard(){
        base("TABLEAU DE BORD",NAVY);
        double capital=0,intt=0,paid=0; int late=0,active=0;
        for(Loan l:loans){ capital+=l.principal; intt+=l.interest(); paid+=l.paid(payments); if(l.balance(payments)>0){active++; if(System.currentTimeMillis()>l.dueDate())late++;} }
        body.addView(tv("SITUATION RÉELLE DE L'ACTIVITÉ",19));
        body.addView(tv("👥 Clients : "+clients.size()+"\n📋 Prêts : "+loans.size()+"\n🟢 Prêts actifs : "+active+"\n🔴 Échéances dépassées : "+late+"\n💰 Capital prêté : "+fmt(capital)+" FBu\n📈 Intérêts prévus : "+fmt(intt)+" FBu\n💵 Total à récupérer : "+fmt(capital+intt)+" FBu\n🔄 Total encaissé : "+fmt(paid)+" FBu\n⏳ Solde à récupérer : "+fmt(capital+intt-paid)+" FBu",17));
        int pendingRequests=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingRequests++;
        body.addView(tv("📥 DEMANDES DE PRÊT CLIENT\n🟡 En attente : "+pendingRequests,17));
        Button requests=btn("📥 OUVRIR LES DEMANDES CLIENTS",GREEN); requests.setOnClickListener(v->bureauRequestsPage()); body.addView(requests,new LinearLayout.LayoutParams(-1,dp(54)));
        Button journal=btn("📋 JOURNAL DES PRÊTS",NAVY); journal.setOnClickListener(v->loanJournal()); body.addView(journal);
    }

    void loanJournal(){
        base("JOURNAL DES PRÊTS",NAVY); body.addView(tv("Historique des prêts",19));
        if(loans.isEmpty()){body.addView(tv("Aucun prêt enregistré.",16)); return;}
        for(Loan l:loans){
            double paid=l.paid(payments), bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(l.c.name+"\n"+fmt(l.principal)+" FBu • Total "+fmt(l.total())+" FBu\n"+status+" • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(88)));
        }
    }

    void loanDetails(Loan l){
        base("DÉTAIL DU PRÊT",RED);
        double paid=l.paid(payments), bal=l.balance(payments);
        body.addView(tv("CLIENT\n"+l.c.name+(l.c.phone.isEmpty()?"":"\n"+l.c.phone),17));
        body.addView(tv("MONTANT : "+fmt(l.principal)+" FBu\nTAUX : "+fmt(l.rate)+" %\nDURÉE : "+l.days+" jours\nINTÉRÊT : "+fmt(l.interest())+" FBu\nTOTAL : "+fmt(l.total())+" FBu\nDÉJÀ PAYÉ : "+fmt(paid)+" FBu\nSOLDE : "+fmt(bal)+" FBu\nÉCHÉANCE : "+date(l.dueDate()),17));
        Button p=btn("💵 ENREGISTRER UN REMBOURSEMENT",PURPLE); p.setOnClickListener(v->paymentForm(l)); body.addView(p);
    }

    void loanForm(){ loanForm(null); }

    void loanForm(Client preselected){
        base("NOUVEAU PRÊT",RED); body.addView(tv("Enregistrer un prêt",19));
        Spinner sp=new Spinner(this); ArrayList<String> ns=new ArrayList<>(); int selected=-1;
        for(int i=0;i<clients.size();i++){ Client c=clients.get(i); ns.add(c.name); if(c==preselected) selected=i; }
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ns));
        if(selected>=0) sp.setSelection(selected);
        body.addView(sp);
        EditText amt=input("Montant prêté (FBu)",InputType.TYPE_CLASS_NUMBER), rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL), days=input("Durée en jours",InputType.TYPE_CLASS_NUMBER);
        body.addView(amt); body.addView(rate); body.addView(days); TextView calc=tv("Intérêt : —\nTotal à récupérer : —",16); body.addView(calc);
        TextWatcher w=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){calculate(amt,rate,calc);} public void afterTextChanged(Editable e){}};
        amt.addTextChangedListener(w); rate.addTextChangedListener(w);
        Button save=btn("ENREGISTRER LE PRÊT",RED); save.setOnClickListener(v->{
            try{ if(clients.isEmpty())throw new Exception(); double a=Double.parseDouble(amt.getText().toString()),r=Double.parseDouble(rate.getText().toString()); int d=Integer.parseInt(days.getText().toString());
                if(a<=0||r<0||d<=0)throw new Exception(); Loan l=new Loan(clients.get(sp.getSelectedItemPosition()),a,r,d); loans.add(l); saveData(); uploadLoan(l); Toast.makeText(this,"Prêt enregistré avec succès",Toast.LENGTH_LONG).show(); loanJournal();
            }catch(Exception e){Toast.makeText(this,"Veuillez remplir correctement les champs",Toast.LENGTH_SHORT).show();}
        }); body.addView(save);
    }

    EditText input(String hint,int type){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); return e; }
    void calculate(EditText a,EditText r,TextView out){ try{double x=Double.parseDouble(a.getText().toString()),y=Double.parseDouble(r.getText().toString()); out.setText("Intérêt : "+fmt(x*y/100)+" FBu\nTotal à récupérer : "+fmt(x+x*y/100)+" FBu");}catch(Exception ignored){out.setText("Intérêt : —\nTotal à récupérer : —");} }

    void clientsPage(){
        base("CLIENTS",NAVY); body.addView(tv("CLIENTS ENREGISTRÉS : "+clients.size(),19));
        for(Client c:clients){ Button b=btn("👤 "+c.name+(c.phone.isEmpty()?"":" — "+c.phone),NAVY); b.setOnClickListener(v->clientDetails(c)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(56))); }
        Button add=btn("＋ AJOUTER UN CLIENT",NAVY); add.setOnClickListener(v->addClient()); body.addView(add);
    }

    void clientDetails(Client c){
        base("FICHE CLIENT",NAVY); body.addView(tv("👤 "+c.name+"\n📱 "+(c.phone.isEmpty()?"Non renseigné":c.phone),19));
        int n=0; double total=0,paid=0; for(Loan l:loans)if(l.c==c){n++;total+=l.total();paid+=l.paid(payments);}
        body.addView(tv("Prêts : "+n+"\nTotal à récupérer : "+fmt(total)+" FBu\nTotal payé : "+fmt(paid)+" FBu\nSolde : "+fmt(total-paid)+" FBu",17));
        Button addLoan=btn("＋ AJOUTER UN PRÊT À CE CLIENT",RED); addLoan.setOnClickListener(v->loanForm(c)); body.addView(addLoan);
        body.addView(tv("HISTORIQUE DES PRÊTS",18));
        boolean found=false;
        for(Loan l:loans) if(l.c==c){
            found=true; double bal=l.balance(payments);
            String status=bal<=0?"REMBOURSÉ":(System.currentTimeMillis()>l.dueDate()?"EN RETARD":"ACTIF");
            Button b=btn(fmt(l.principal)+" FBu • "+status+"\nTotal "+fmt(l.total())+" FBu • Échéance "+date(l.dueDate()), status.equals("REMBOURSÉ")?GREEN:(status.equals("EN RETARD")?RED:NAVY));
            b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(82)));
        }
        if(!found) body.addView(tv("Aucun prêt pour ce client.",15));
    }

    void addClient(){
        final EditText n=input("Nom et post-nom",InputType.TYPE_CLASS_TEXT), p=input("Téléphone",InputType.TYPE_CLASS_PHONE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("Nouveau client").setView(box).setPositiveButton("ENREGISTRER",(d,w)->{if(n.getText().length()>0){Client c=new Client(n.getText().toString().trim(),p.getText().toString().trim()); clients.add(c); saveData(); uploadClient(c); clientsPage();}}).setNegativeButton("ANNULER",null).show();
    }

    void paymentPage(){
        base("PAIEMENT",PURPLE);
        body.addView(tv("💳 ENREGISTRER UN PAIEMENT",19));
        body.addView(tv("Sélectionnez le prêt concerné puis saisissez le montant réellement reçu. Le paiement sera enregistré localement et synchronisé avec Firebase lorsqu'une connexion est disponible.",15));
        boolean found=false;
        for(Loan l:loans){
            double bal=l.balance(payments);
            if(bal>0){
                found=true;
                Button b=btn("💳 "+l.c.name+"\nSolde : "+fmt(bal)+" FBu",PURPLE);
                b.setOnClickListener(v->paymentForm(l));
                body.addView(b,new LinearLayout.LayoutParams(-1,dp(72)));
            }
        }
        if(!found) body.addView(tv("Aucun solde à payer.",16));
    }

    void repay(){
        base("REMBOURSEMENTS",PURPLE); body.addView(tv("Choisissez un prêt puis enregistrez le paiement",18));
        for(Loan l:loans){ double bal=l.balance(payments); if(bal>0){ Button b=btn(l.c.name+" — Solde "+fmt(bal)+" FBu",PURPLE); b.setOnClickListener(v->paymentForm(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(62))); } }
    }

    void paymentForm(Loan l){
        EditText a=input("Montant du paiement (FBu)",InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("💳 Paiement — "+l.c.name).setView(a).setPositiveButton("ENCAISSER",(d,w)->{
            try{double x=Double.parseDouble(a.getText().toString()); if(x<=0||x>l.balance(payments))throw new Exception(); Payment p=new Payment(l,x); payments.add(p); saveData(); uploadPayment(p); Toast.makeText(this,"Remboursement enregistré",Toast.LENGTH_SHORT).show(); loanDetails(l);}
            catch(Exception e){Toast.makeText(this,"Montant invalide",Toast.LENGTH_SHORT).show();}
        }).setNegativeButton("ANNULER",null).show();
    }

    /**
     * Tableau de bord Administration — présentation en cartes 2 colonnes.
     * Les actions existantes sont conservées : seule la présentation/navigation
     * de l'espace administrateur est modernisée.
     */
    void adminDash(){
        base("ADMINISTRATION",NAVY);

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(20),dp(4),dp(20),dp(4));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(96)));

        TextView heading=tv("🔐 ESPACE ADMINISTRATEUR",22);
        heading.setTextColor(NAVY);
        heading.setTypeface(null,Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        body.addView(heading);

        TextView intro=tv("Accès réservé à la gestion interne de YOUNGEST’S BUSINESS.",15);
        intro.setGravity(Gravity.CENTER);
        body.addView(intro);

        TextView question=tv("Que souhaitez-vous faire ?",20);
        question.setTypeface(null,Typeface.BOLD);
        question.setPadding(dp(4),dp(14),dp(4),dp(10));
        body.addView(question);

        LinearLayout grid=new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(0),dp(2),dp(0),dp(2));

        LinearLayout row1=newAdminRow(
            adminCard("📊","TABLEAU DE BORD","Vue d’ensemble des activités",NAVY,()->dashboard()),
            adminCard("👥","GESTION DES CLIENTS","Ajouter, modifier et suivre les clients",GOLD,()->clientsPage())
        );
        LinearLayout row2=newAdminRow(
            adminCard("💰","GESTION DES PRÊTS","Enregistrer, suivre et gérer les prêts",RED,()->loanJournal()),
            adminCard("💵","REMBOURSEMENTS","Suivi des paiements et échéances",PURPLE,()->repay())
        );
        LinearLayout row3=newAdminRow(
            adminCard("📥","DEMANDES DE PRÊTS CLIENTS","Nouvelles demandes à traiter",GREEN,()->bureauRequestsPage()),
            adminCard("📞","CONTACT_NOUS — COORDONNÉES","Voir et gérer les contacts",NAVY,()->contactPage())
        );
        LinearLayout row4=newAdminRow(
            adminCard("💬","CONTACT_NOUS — RÉPONDRE AU CHAT","Messages clients en temps réel",BLUE,()->requireAdmin(()->adminChatInbox())),
            adminCard("📊","RAPPORTS MENSUELS & ÉCHÉANCES","Statistiques et rapports détaillés",PURPLE,()->monthlyReportsPage())
        );
        LinearLayout row5=newAdminRow(
            adminCard("💾","SAUVEGARDER LES DONNÉES","Sécuriser toutes les données",GREEN,()->exportData()),
            adminCard("📥","RESTAURER LES DONNÉES","Restaurer depuis une sauvegarde",BLUE,()->confirmRestore())
        );
        LinearLayout row6=newAdminRow(
            adminCard("📶","YOUNGEST’S B WIFI","Préparer les paramètres Wi-Fi synchronisés",BLUE,()->requireAdmin(()->wifiAdminPage())),
            adminCard("ℹ️","ÉTAT DU MATÉRIEL","Antenne et MikroTik non configurés",NAVY,()->requireAdmin(()->wifiAdminPage()))
        );

        grid.addView(row1); grid.addView(row2); grid.addView(row3); grid.addView(row4); grid.addView(row5); grid.addView(row6);
        body.addView(grid);

        LinearLayout logout=adminCard("🚪","SE DÉCONNECTER","Quitter l’espace administrateur",BLUE,()->{
            adminSession=false;
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            firebaseAuth.signOut();
            clientUid=null;
            pendingChatDraft=null;
            pendingChatPhone=null;
            Toast.makeText(this,"Déconnexion du Bureau réussie.",Toast.LENGTH_SHORT).show();
            home();
        });
        LinearLayout.LayoutParams logoutLp=new LinearLayout.LayoutParams(-1,dp(82));
        logoutLp.setMargins(0,dp(8),0,dp(8));
        body.addView(logout,logoutLp);
    }

    private LinearLayout newAdminRow(LinearLayout left, LinearLayout right){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(158));
        lp.setMargins(0,dp(5),0,dp(5));
        row.setLayoutParams(lp);
        row.addView(left,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams rightLp=new LinearLayout.LayoutParams(0,-1,1);
        rightLp.setMargins(dp(7),0,0,0);
        row.addView(right,rightLp);
        return row;
    }

    private LinearLayout adminCard(String icon,String title,String description,int color,final Runnable action){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14),dp(10),dp(10),dp(10));
        card.setBackground(bg(color,18));
        if(android.os.Build.VERSION.SDK_INT>=21) card.setElevation(dp(4));
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v->{ if(action!=null) action.run(); });

        TextView iconView=tv(icon,25);
        iconView.setTextColor(Color.WHITE);
        iconView.setPadding(0,0,0,dp(2));
        card.addView(iconView,new LinearLayout.LayoutParams(-1,dp(32)));

        TextView titleView=tv(title,15);
        titleView.setTextColor(Color.WHITE);
        titleView.setTypeface(null,Typeface.BOLD);
        titleView.setPadding(0,0,dp(28),0);
        titleView.setMaxLines(2);
        card.addView(titleView,new LinearLayout.LayoutParams(-1,dp(46)));

        TextView descView=tv(description,12);
        descView.setTextColor(Color.WHITE);
        descView.setPadding(0,0,dp(28),0);
        descView.setMaxLines(2);
        card.addView(descView,new LinearLayout.LayoutParams(-1,0,1));

        TextView arrow=tv("›",30);
        arrow.setTextColor(Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams arrowLp=new LinearLayout.LayoutParams(dp(28),dp(40));
        arrowLp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
        arrowLp.topMargin=-dp(40);
        card.addView(arrow,arrowLp);
        return card;
    }

    private Calendar reportMonthStart(int year, int monthZeroBased){
        Calendar c=Calendar.getInstance(); c.clear(); c.set(year,monthZeroBased,1,0,0,0); return c;
    }

    private boolean inReportMonth(long timestamp, long start, long end){ return timestamp>=start && timestamp<end; }

    void monthlyReportsPage(){
        Calendar now=Calendar.getInstance();
        int currentYear=now.get(Calendar.YEAR), currentMonth=now.get(Calendar.MONTH);
        base("RAPPORTS MENSUELS",PURPLE);
        body.addView(tv("🔐 RAPPORTS INTERNES — ADMINISTRATION",19));
        body.addView(tv("Choisissez un mois et une année pour consulter les prêts accordés, les paiements reçus et les échéances. Les chiffres sont calculés depuis les données enregistrées sur cet appareil et synchronisées.",14));
        String[] months={"Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"};
        Spinner monthSpinner=new Spinner(this);
        monthSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months));
        monthSpinner.setSelection(currentMonth);
        ArrayList<String> years=new ArrayList<>();
        for(int y=currentYear-5;y<=currentYear+1;y++) years.add(String.valueOf(y));
        Spinner yearSpinner=new Spinner(this);
        yearSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,years));
        yearSpinner.setSelection(years.indexOf(String.valueOf(currentYear)));
        body.addView(tv("MOIS DU RAPPORT",15)); body.addView(monthSpinner);
        body.addView(tv("ANNÉE",15)); body.addView(yearSpinner);
        LinearLayout reportContent=new LinearLayout(this); reportContent.setOrientation(LinearLayout.VERTICAL);
        body.addView(reportContent);
        Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            reportContent.removeAllViews();
            int m=monthSpinner.getSelectedItemPosition();
            int y=Integer.parseInt(yearSpinner.getSelectedItem().toString());
            Calendar from=reportMonthStart(y,m); long start=from.getTimeInMillis();
            Calendar to=(Calendar)from.clone(); to.add(Calendar.MONTH,1); long end=to.getTimeInMillis();
            double lent=0, interest=0, received=0, totalReceivedAll=0, balanceAll=0;
            int loansInMonth=0, paymentsInMonth=0, paidOff=0, active=0, overdue=0, dueInMonth=0;
            StringBuilder report=new StringBuilder();
            report.append("YOUNGEST'S BUSINESS — RAPPORT DES PRÊTS\nPériode : ").append(months[m]).append(" ").append(y).append("\n\n");
            report.append("PRÊTS ACCORDÉS PENDANT LE MOIS\n");
            for(Loan l:loans){
                double paid=l.paid(payments), bal=l.balance(payments);
                totalReceivedAll+=paid; balanceAll+=bal;
                if(inReportMonth(l.date,start,end)){
                    loansInMonth++; lent+=l.principal; interest+=l.interest();
                    report.append("• ").append(l.c.name).append(" — Capital : ").append(fmt(l.principal)).append(" FBu ; intérêt prévu : ").append(fmt(l.interest())).append(" FBu ; échéance : ").append(date(l.dueDate())).append("\n");
                }
                if(bal<=0) paidOff++;
                else { active++; if(l.dueDate()<System.currentTimeMillis()) overdue++; if(inReportMonth(l.dueDate(),start,end)) dueInMonth++; }
            }
            for(Payment p:payments){ if(inReportMonth(p.date,start,end)){ received+=p.amount; paymentsInMonth++; } }
            report.append("\nPAIEMENTS REÇUS PENDANT LE MOIS\n");
            for(Payment p:payments) if(inReportMonth(p.date,start,end)) report.append("• ").append(p.loan==null?"Prêt":p.loan.c.name).append(" — ").append(fmt(p.amount)).append(" FBu — ").append(date(p.date)).append("\n");
            report.append("\nSYNTHÈSE\nPrêts accordés : ").append(loansInMonth).append("\nCapital prêté ce mois : ").append(fmt(lent)).append(" FBu\nIntérêts prévus sur ces prêts : ").append(fmt(interest)).append(" FBu\nNombre de paiements reçus : ").append(paymentsInMonth).append("\nMontant encaissé ce mois : ").append(fmt(received)).append(" FBu\nPrêts entièrement remboursés (toutes périodes) : ").append(paidOff).append("\nPrêts encore actifs : ").append(active).append("\nÉchéances arrivant ce mois et encore dues : ").append(dueInMonth).append("\nPrêts en retard à ce jour : ").append(overdue).append("\nSolde total actuel à récupérer : ").append(fmt(balanceAll)).append(" FBu\nTotal payé sur tous les prêts : ").append(fmt(totalReceivedAll)).append(" FBu\n\nGénéré le : ").append(date(System.currentTimeMillis()));
            reportContent.addView(tv("📅 RAPPORT : "+months[m].toUpperCase(Locale.FRANCE)+" "+y,18));
            reportContent.addView(tv("PRÊTS ACCORDÉS : "+loansInMonth+"\nCapital prêté : "+fmt(lent)+" FBu\nIntérêts prévus sur ces prêts : "+fmt(interest)+" FBu\n\nPAIEMENTS REÇUS : "+paymentsInMonth+"\nMontant encaissé ce mois : "+fmt(received)+" FBu\n\nÉCHÉANCES EN COURS : "+active+" prêt(s)\nÉchéances dues ce mois : "+dueInMonth+"\nÉCHÉANCES EN RETARD : "+overdue+"\n\nCapital + intérêts restant à récupérer (solde actuel) : "+fmt(balanceAll)+" FBu",16));
            Button paidBtn=btn("💵 VOIR LES ÉCHÉANCES / PAIEMENTS DU MOIS",GREEN);
            paidBtn.setOnClickListener(v->showMonthlyPayments(y,m,months[m])); reportContent.addView(paidBtn);
            Button dueBtn=btn("🗓️ VOIR LES ÉCHÉANCES EN COURS CE MOIS",BLUE);
            dueBtn.setOnClickListener(v->showMonthlyDue(y,m,months[m],false)); reportContent.addView(dueBtn);
            Button lateBtn=btn("⚠️ VOIR LES ÉCHÉANCES EN RETARD",RED);
            lateBtn.setOnClickListener(v->showMonthlyDue(y,m,months[m],true)); reportContent.addView(lateBtn);
            Button export=btn("📄 GÉNÉRER / EXPORTER CE RAPPORT",NAVY);
            export.setOnClickListener(v->{
                pendingReportPdfText=report.toString();
                pendingReportPdfName="Rapport_YOUNGEST_BUSINESS_"+months[m]+"_"+y+".pdf";
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_TITLE,pendingReportPdfName);
                startActivityForResult(intent,CREATE_REPORT_PDF);
            });
            reportContent.addView(export);
        };
        monthSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh[0].run();} });
        yearSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh[0].run();} });
        refresh[0].run();
    }

    private void showMonthlyPayments(int year,int month,String monthName){
        base("PAIEMENTS DU MOIS",GREEN);
        Calendar from=reportMonthStart(year,month); long start=from.getTimeInMillis(); Calendar to=(Calendar)from.clone(); to.add(Calendar.MONTH,1); long end=to.getTimeInMillis();
        double total=0; int count=0;
        body.addView(tv("Paiements enregistrés en "+monthName+" "+year,18));
        for(Payment p:payments) if(inReportMonth(p.date,start,end)){ count++; total+=p.amount; Button b=btn((p.loan==null?"Client inconnu":p.loan.c.name)+"\n"+fmt(p.amount)+" FBu • "+date(p.date),GREEN); b.setOnClickListener(v->{if(p.loan!=null)loanDetails(p.loan);}); body.addView(b,new LinearLayout.LayoutParams(-1,dp(70))); }
        body.addView(tv("Nombre de paiements : "+count+"\nTotal encaissé : "+fmt(total)+" FBu",17));
        Button back=btn("← RETOUR AUX RAPPORTS",NAVY); back.setOnClickListener(v->monthlyReportsPage()); body.addView(back);
    }

    private void showMonthlyDue(int year,int month,String monthName,boolean lateOnly){
        base(lateOnly?"ÉCHÉANCES EN RETARD":"ÉCHÉANCES EN COURS",lateOnly?RED:BLUE);
        Calendar from=reportMonthStart(year,month); long start=from.getTimeInMillis(); Calendar to=(Calendar)from.clone(); to.add(Calendar.MONTH,1); long end=to.getTimeInMillis();
        long now=System.currentTimeMillis(); int count=0; double balance=0;
        body.addView(tv(lateOnly?"Prêts impayés dont la date limite est dépassée":"Prêts encore dus avec une échéance en "+monthName+" "+year,17));
        for(Loan l:loans){ double bal=l.balance(payments); boolean isLate=bal>0 && l.dueDate()<now; boolean dueInMonth=inReportMonth(l.dueDate(),start,end) && bal>0;
            if(bal>0 && (lateOnly?isLate:dueInMonth)){ count++; balance+=bal; Button b=btn(l.c.name+"\nSolde : "+fmt(bal)+" FBu • Échéance : "+date(l.dueDate()),lateOnly?RED:BLUE); b.setOnClickListener(v->loanDetails(l)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(78))); }
        }
        if(count==0) body.addView(tv("Aucune échéance dans cette catégorie.",16));
        body.addView(tv("Nombre de prêts concernés : "+count+"\nSolde restant total : "+fmt(balance)+" FBu",17));
        Button back=btn("← RETOUR AUX RAPPORTS",NAVY); back.setOnClickListener(v->monthlyReportsPage()); body.addView(back);
    }

    void bureauRequestsPage(){
        base("DEMANDES CLIENTS",GREEN);
        startBureauCloudSync();
        int pendingCount=0; for(LoanRequest q:loanRequests) if("EN_ATTENTE".equals(q.status)) pendingCount++;
        body.addView(tv("📥 Demandes reçues\n🟡 En attente : "+pendingCount+"\n\nAppuyez sur une demande pour voir les détails et la valider ou la refuser.",16));
        boolean found=false;
        for(LoanRequest q:loanRequests){ found=true; String status=q.status.equals("APPROUVEE")?"🟢 APPROUVÉE":(q.status.equals("REFUSEE")?"🔴 REFUSÉE":"🟡 EN ATTENTE"); Button b=btn(status+"\n"+q.name+" • "+fmt(q.amount)+" FBu\n"+q.days+" jours • "+(q.reason.isEmpty()?"Motif non précisé":q.reason), q.status.equals("APPROUVEE")?GREEN:(q.status.equals("REFUSEE")?RED:NAVY)); b.setOnClickListener(v->reviewLoanRequest(q)); body.addView(b,new LinearLayout.LayoutParams(-1,dp(100))); }
        if(!found) body.addView(tv("Aucune demande client pour le moment.",16));
        Button back=btn("← ADMINISTRATION",NAVY); back.setOnClickListener(v->adminDash()); body.addView(back);
    }

    void reviewLoanRequest(LoanRequest q){
        String details="Client : "+q.name+"\nTéléphone : "+q.phone+"\nMontant : "+fmt(q.amount)+" FBu\nDurée : "+q.days+" jours\nMotif : "+(q.reason.isEmpty()?"Non précisé":q.reason)+"\nStatut : "+q.status;
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("📥 Demande de prêt").setMessage(details);
        if("EN_ATTENTE".equals(q.status)){ b.setPositiveButton("APPROUVER",(d,w)->approveLoanRequest(q)); b.setNegativeButton("REFUSER",(d,w)->refuseLoanRequest(q)); } else b.setPositiveButton("FERMER",null);
        b.show();
    }

    private void refuseLoanRequest(LoanRequest q){ q.status="REFUSEE"; q.updatedAt=System.currentTimeMillis(); saveData(); uploadLoanRequest(q); localNotification("Demande refusée", "La demande de "+q.name+" a été refusée."); Toast.makeText(this,"Demande refusée.",Toast.LENGTH_LONG).show(); bureauRequestsPage(); }

    private void approveLoanRequest(LoanRequest q){
        final EditText rate=input("Taux d'intérêt (%)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        rate.setText("30");
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0); box.addView(rate);
        new AlertDialog.Builder(this).setTitle("✅ Approuver le prêt").setMessage("Définissez le taux avant de créer le prêt. Durée demandée : "+q.days+" jours.").setView(box).setPositiveButton("CRÉER LE PRÊT",(d,w)->{
            try{ double r=Double.parseDouble(rate.getText().toString()); if(r<0) throw new Exception(); Client c=findClient(q.clientId); if(c==null){ c=new Client(q.clientId,q.name,q.phone); clients.add(c); uploadClient(c); } Loan l=new Loan(c,q.amount,r,q.days); loans.add(l); q.status="APPROUVEE"; q.updatedAt=System.currentTimeMillis(); saveData(); uploadLoan(l); uploadLoanRequest(q); localNotification("Prêt approuvé", "Le prêt de "+q.name+" a été créé avec succès."); Toast.makeText(this,"Demande approuvée et prêt créé.",Toast.LENGTH_LONG).show(); bureauRequestsPage(); }catch(Exception e){ Toast.makeText(this,"Taux invalide.",Toast.LENGTH_LONG).show(); }
        }).setNegativeButton("ANNULER",null).show();
    }

    private void exportData(){
        try{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"youngest_business_sauvegarde.json"); startActivityForResult(i,9001);
        }catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void confirmRestore(){
        new AlertDialog.Builder(this)
            .setTitle("📥 Restaurer les données ?")
            .setMessage("La restauration remplacera les clients, prêts et remboursements actuellement enregistrés sur cet appareil. Continuez uniquement avec une sauvegarde fiable.")
            .setPositiveButton("CHOISIR LA SAUVEGARDE",(d,w)->{
                try{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,9002); }
                catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir le sélecteur de fichier.",Toast.LENGTH_LONG).show();}
            })
            .setNegativeButton("ANNULER",null).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if(requestCode==9001) { writeBackup(uri); return; }
        if(requestCode==9002) { readBackup(uri); return; }
        if(requestCode==CREATE_JOURNAL_PDF){
            writeTextPdf(uri,pendingJournalPdfText,"Rapport Journal PDF exporté avec succès.");
            return;
        }
        if(requestCode==CREATE_REPORT_PDF){
            writeTextPdf(uri,pendingReportPdfText,"Rapport mensuel PDF exporté avec succès.");
            return;
        }
    }

    private void writeTextPdf(Uri uri,String text,String successMessage){
        PdfDocument pdf=null;
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            if(out==null) throw new java.io.IOException("Impossible d'ouvrir le fichier PDF");
            pdf=new PdfDocument();
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            Paint brandPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
            String[] lines=(text==null?"":text).split("\n",-1);
            int pageNum=1,y=0;
            PdfDocument.Page page=null;
            Canvas canvas=null;
            Bitmap logo=BitmapFactory.decodeResource(getResources(),R.drawable.logo_youngests_business);
            for(String line:lines){
                if(page==null || y>790){
                    if(page!=null) pdf.finishPage(page);
                    PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,pageNum++).create();
                    page=pdf.startPage(info); canvas=page.getCanvas();
                    if(pageNum==2){
                        canvas.drawColor(Color.WHITE);
                        brandPaint.setColor(NAVY); canvas.drawRect(0,0,595,8,brandPaint);
                        if(logo!=null){
                            int maxW=150,maxH=68;
                            float scale=Math.min((float)maxW/logo.getWidth(),(float)maxH/logo.getHeight());
                            float w=logo.getWidth()*scale,h=logo.getHeight()*scale;
                            canvas.drawBitmap(logo,null,new android.graphics.RectF((595-w)/2f,18,(595+w)/2f,18+h),brandPaint);
                            y=(int)(28+h+8);
                        }else y=42;
                        brandPaint.setColor(NAVY); brandPaint.setTextSize(15f); brandPaint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
                        String brand="YOUNGEST'S BUSINESS"; float bw=brandPaint.measureText(brand);
                        canvas.drawText(brand,(595-bw)/2f,Math.max(y,98),brandPaint);
                        y=Math.max(y,98)+24;
                        canvas.drawLine(35,y,560,y,brandPaint); y+=22;
                    }else y=42;
                }
                paint.setTextSize(10f); paint.setColor(Color.BLACK); paint.setTypeface(Typeface.DEFAULT);
                String remaining=line;
                int max=92;
                while(remaining.length()>max){
                    int cut=remaining.lastIndexOf(' ',max);
                    if(cut<35) cut=max;
                    canvas.drawText(remaining.substring(0,cut),35,y,paint);
                    remaining=remaining.substring(cut).trim(); y+=15;
                    if(y>790){
                        pdf.finishPage(page);
                        PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,pageNum++).create();
                        page=pdf.startPage(info); canvas=page.getCanvas(); y=42;
                    }
                }
                canvas.drawText(remaining,35,y,paint); y+=15;
            }
            if(page!=null) pdf.finishPage(page);
            pdf.writeTo(out);
            if(logo!=null) logo.recycle();
            Toast.makeText(this,successMessage,Toast.LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(this,"Erreur lors de l'export PDF : "+e.getMessage(),Toast.LENGTH_LONG).show();
        }finally{ if(pdf!=null) pdf.close(); }
    }

    private String transactionTime(JSONObject o){
        String saved=o==null?"":o.optString("time","").trim();
        if(!saved.isEmpty()) return saved;
        long created=o==null?0:o.optLong("createdAt",0);
        if(created<=0) return "Heure non disponible";
        return new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(created));
    }

    private String buildBackup(){
        try{
            JSONObject all=new JSONObject(); JSONArray cs=new JSONArray(),ls=new JSONArray(),ps=new JSONArray();
            for(Client c:clients){JSONObject o=new JSONObject();o.put("name",c.name);o.put("phone",c.phone);cs.put(o);}
            for(Loan l:loans){JSONObject o=new JSONObject();o.put("client",clients.indexOf(l.c));o.put("principal",l.principal);o.put("rate",l.rate);o.put("days",l.days);o.put("date",l.date);ls.put(o);}
            for(Payment p:payments){JSONObject o=new JSONObject();o.put("loan",loans.indexOf(p.loan));o.put("amount",p.amount);o.put("date",p.date);ps.put(o);}
            all.put("app","YOUNGEST’S BUSINESS"); all.put("backup_version",1); all.put("created_at",System.currentTimeMillis()); all.put("clients",cs); all.put("loans",ls); all.put("payments",ps); return all.toString(2);
        }catch(Exception e){return null;}
    }

    private void writeBackup(Uri uri){
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            String raw=buildBackup(); if(raw==null)throw new Exception(); out.write(raw.getBytes("UTF-8")); out.flush(); Toast.makeText(this,"Sauvegarde créée avec succès.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Échec de la sauvegarde.",Toast.LENGTH_LONG).show();}
    }

    private void readBackup(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri)){
            java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) buffer.write(b,0,n);
            JSONObject all=new JSONObject(new String(buffer.toByteArray(),"UTF-8"));
            if(!"YOUNGEST’S BUSINESS".equals(all.optString("app")) && !"YOUNGEST'S BUSINESS".equals(all.optString("app"))) throw new Exception();
            JSONArray cs=all.optJSONArray("clients"),ls=all.optJSONArray("loans"),ps=all.optJSONArray("payments");
            if(cs==null||ls==null||ps==null)throw new Exception();
            ArrayList<Client> newClients=new ArrayList<>(); ArrayList<Loan> newLoans=new ArrayList<>(); ArrayList<Payment> newPayments=new ArrayList<>();
            for(int i=0;i<cs.length();i++){JSONObject o=cs.getJSONObject(i);newClients.add(new Client(o.optString("name"),o.optString("phone")));}
            for(int i=0;i<ls.length();i++){JSONObject o=ls.getJSONObject(i);int ci=o.optInt("client",-1);if(ci<0||ci>=newClients.size())throw new Exception();Loan l=new Loan(newClients.get(ci),o.optDouble("principal"),o.optDouble("rate"),o.optInt("days"));l.date=o.optLong("date",l.date);newLoans.add(l);}
            for(int i=0;i<ps.length();i++){JSONObject o=ps.getJSONObject(i);int li=o.optInt("loan",-1);if(li<0||li>=newLoans.size())throw new Exception();Payment p=new Payment(newLoans.get(li),o.optDouble("amount"));p.date=o.optLong("date",p.date);newPayments.add(p);}
            clients.clear();clients.addAll(newClients);loans.clear();loans.addAll(newLoans);payments.clear();payments.addAll(newPayments);saveData(); uploadAllClients(); uploadAllLoans(); uploadAllPayments(); Toast.makeText(this,"Données restaurées avec succès.",Toast.LENGTH_LONG).show(); adminDash();
        }catch(Exception e){Toast.makeText(this,"Fichier de sauvegarde invalide ou incompatible.",Toast.LENGTH_LONG).show();}
    }

    private void requireAdmin(Runnable action){
        if(adminSession){ action.run(); return; }
        showAdminLogin(action);
    }

    private void showAdminLogin(Runnable after){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20),0,dp(20),0);

        EditText email=input("Email Firebase Admin",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setText(FIREBASE_ADMIN_EMAIL);
        email.setEnabled(false);
        EditText password=input("Mot de passe Firebase",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(email);
        box.addView(password);

        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("🔐 Connexion Bureau / Admin")
            .setMessage("Connectez-vous avec le compte Firebase autorisé à gérer les demandes clients.")
            .setView(box)
            .setPositiveButton("SE CONNECTER",null)
            .setNegativeButton("ANNULER",null)
            .create();

        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String pass=password.getText().toString();
            if(pass.isEmpty()){
                Toast.makeText(this,"Veuillez saisir le mot de passe Firebase.",Toast.LENGTH_SHORT).show();
                return;
            }
            if(firebaseAuth==null) firebaseAuth=FirebaseAuth.getInstance();
            if(firestore==null) firestore=FirebaseFirestore.getInstance();

            // Si l'application était connectée anonymement, on ferme cette session
            // avant de connecter le compte Bureau avec son vrai UID Firebase.
            firebaseAuth.signOut();
            Toast.makeText(this,"Connexion Firebase du Bureau en cours…",Toast.LENGTH_SHORT).show();
            firebaseAuth.signInWithEmailAndPassword(FIREBASE_ADMIN_EMAIL,pass)
                .addOnCompleteListener(task->{
                    if(task.isSuccessful() && firebaseAuth.getCurrentUser()!=null){
                        clientUid=firebaseAuth.getCurrentUser().getUid();
                        adminSession=true;
                        initialCloudRequestsDone=false;
                        initialCloudClientsDone=false;
                        dlg.dismiss();
                        after.run();
                    }else{
                        Toast.makeText(this,"Connexion Firebase refusée. Vérifiez le mot de passe du compte Admin.",Toast.LENGTH_LONG).show();
                    }
                });
        }));
        dlg.show();
    }

    private String hash(String value){
        try{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] out=md.digest(value.getBytes("UTF-8")); StringBuilder sb=new StringBuilder(); for(byte q:out) sb.append(String.format(Locale.US,"%02x",q)); return sb.toString(); }catch(Exception e){ return ""; }
    }



    // V37 — JOURNAL LUMICASH : journal interne des transferts en FBu.
    // Les deux agents partagent la même base Firebase, mais leurs rapports restent séparés par agent.
    private static final String LUMICASH_JOURNAL_KEY = "yb_lumicash_journal_v37";
    private static final String LUMICASH_COLLECTION = "yb_lumicash_journal";
    private static final String LUMICASH_AGENT_1 = "ELISHA YOUNGEST";
    private static final String LUMICASH_AGENT_2 = "BLESSING";
    // V38 — codes agents stockes sous forme de hash SHA-256.
    private static final String LUMICASH_AGENT_1_CODE_HASH = "6613146a007a020a018bda45e6a2d7f2c553498bb38a9782ab9d1fcfd204dc94";
    private static final String LUMICASH_AGENT_2_CODE_HASH = "4b0cedc610be7592b26ad505a4db31a2cd51ef4e58dbda4ad2f9a3fde491a409";

    private JSONArray lumicashReadLocal(){
        try { return new JSONArray(prefs.getString(LUMICASH_JOURNAL_KEY,"[]")); }
        catch(Exception e){ return new JSONArray(); }
    }
    private void lumicashWriteLocal(JSONArray a){ prefs.edit().putString(LUMICASH_JOURNAL_KEY,a.toString()).apply(); }

    private boolean lumicashHasId(JSONArray a,String id){
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null && id.equals(o.optString("id"))) return true;
        }
        return false;
    }

    private void loadLumicashCloud(final Runnable after){
        if(firestore==null || !adminSession){ if(after!=null) after.run(); return; }
        firestore.collection(LUMICASH_COLLECTION).get()
            .addOnSuccessListener(snap->{
                JSONArray local=lumicashReadLocal();
                for(DocumentSnapshot d:snap.getDocuments()){
                    String id=d.getId();
                    JSONObject o=new JSONObject();
                    try{
                        o.put("id",id);
                        o.put("agent",d.getString("agent")==null?"":d.getString("agent"));
                        o.put("date",d.getString("date")==null?"":d.getString("date"));
                        o.put("phone",d.getString("phone")==null?"":d.getString("phone"));
                        o.put("beneficiary",d.getString("beneficiary")==null?"":d.getString("beneficiary"));
                        o.put("amount",number(d.get("amount")));
                        o.put("fees",number(d.get("fees")));
                        o.put("createdAt",longNumber(d.get("createdAt")));
                        o.put("time",d.getString("time")==null?"":d.getString("time"));
                        if(!lumicashHasId(local,id)) local.put(o);
                    }catch(Exception ignored){}
                }
                lumicashWriteLocal(local);
                if(after!=null) after.run();
            })
            .addOnFailureListener(e->{
                Toast.makeText(this,"Firebase : historique LUMICASH indisponible. Les données locales restent disponibles.",Toast.LENGTH_LONG).show();
                if(after!=null) after.run();
            });
    }

    private void uploadLumicashEntry(JSONObject o){
        if(firestore==null || o==null) return;
        try{
            String id=o.optString("id");
            Map<String,Object> m=new HashMap<>();
            m.put("id",id);
            m.put("agent",o.optString("agent"));
            m.put("date",o.optString("date"));
            m.put("phone",o.optString("phone"));
            m.put("beneficiary",o.optString("beneficiary"));
            m.put("amount",o.optDouble("amount"));
            m.put("fees",o.optDouble("fees"));
            m.put("createdAt",o.optLong("createdAt",System.currentTimeMillis()));
            m.put("time",o.optString("time",transactionTime(o)));
            firestore.collection(LUMICASH_COLLECTION).document(id).set(m)
                .addOnFailureListener(e->Toast.makeText(this,"Échec de synchronisation LUMICASH : "+e.getMessage(),Toast.LENGTH_LONG).show());
        }catch(Exception e){
            Toast.makeText(this,"Impossible de synchroniser cette opération LUMICASH.",Toast.LENGTH_LONG).show();
        }
    }

    void lumicashJournalPage(){
        base("JOURNAL LUMICASH",BLUE);
        body.addView(tv("📒 JOURNAL LUMICASH",22));
        body.addView(tv("Transferts en FBu — choisissez l'agent dont vous voulez gérer le rapport.",15));
        Button a1=btn("👤 AGENT 1 — ELISHA YOUNGEST",NAVY); a1.setOnClickListener(v->showLumicashAgentLogin(LUMICASH_AGENT_1));
        Button a2=btn("👤 AGENT 2 — BLESSING",PURPLE); a2.setOnClickListener(v->showLumicashAgentLogin(LUMICASH_AGENT_2));
        body.addView(a1,new LinearLayout.LayoutParams(-1,dp(58))); body.addView(a2,new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(tv("Les transactions sont enregistrées séparément par agent et synchronisées dans Firebase.",14));
        Button back=btn("← RETOUR",NAVY); back.setOnClickListener(v->home()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    private void showLumicashAgentLogin(final String agent){
        final String expected = LUMICASH_AGENT_1.equals(agent) ? LUMICASH_AGENT_1_CODE_HASH : LUMICASH_AGENT_2_CODE_HASH;
        EditText code=input("Code de l'agent",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("🔐 " + agent)
            .setMessage("Entrez le code personnel de cet agent pour ouvrir son Journal Lumicash.")
            .setView(code)
            .setPositiveButton("ACCÉDER",null)
            .setNegativeButton("ANNULER",null)
            .create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String entered=code.getText().toString();
            if(hash(entered).equals(expected)){
                dlg.dismiss();
                lumicashAgentPage(agent);
            }else{
                code.setError("Code incorrect");
                Toast.makeText(this,"Code incorrect pour "+agent+".",Toast.LENGTH_SHORT).show();
            }
        }));
        dlg.show();
    }

    void lumicashAgentPage(final String agent){
        base("JOURNAL LUMICASH",BLUE);
        body.addView(tv("JOURNAL LUMICASH",22));
        body.addView(tv("Rapport de service — FBu",15));
        body.addView(tv("Agent : "+agent,17));
        Button add=btn("➕ ENREGISTRER UNE TRANSACTION",GREEN); add.setOnClickListener(v->lumicashForm(agent));
        body.addView(add,new LinearLayout.LayoutParams(-1,dp(56)));

        EditText search=input("Rechercher nom du bénéficiaire ou numéro",InputType.TYPE_CLASS_TEXT);
        body.addView(search);
        Spinner period=new Spinner(this);
        String[] periods={"Rapport journalier — aujourd'hui","Rapport mensuel — ce mois","Tout l'historique"};
        period.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,periods));
        period.setSelection(2);
        body.addView(tv("PÉRIODE DU RAPPORT (facultatif)",14)); body.addView(period);

        LinearLayout dateRow=new LinearLayout(this); dateRow.setOrientation(LinearLayout.HORIZONTAL); dateRow.setGravity(Gravity.CENTER_VERTICAL);
        final String[] selectedDate={new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())};
        final Runnable[] rerender={null};
        Button chooseDate=btn("📅 Date : "+selectedDate[0],NAVY); dateRow.addView(chooseDate,new LinearLayout.LayoutParams(-1,dp(48))); body.addView(dateRow);
        chooseDate.setOnClickListener(v->{
            Calendar c=Calendar.getInstance();
            try{String[] p=selectedDate[0].split("-");c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]));}catch(Exception ignored){}
            new DatePickerDialog(this,(view,y,m,d)->{selectedDate[0]=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);chooseDate.setText("📅 Date : "+selectedDate[0]);if(rerender[0]!=null)rerender[0].run();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
        });

        LinearLayout summary=new LinearLayout(this); summary.setOrientation(LinearLayout.VERTICAL); summary.setPadding(dp(12),dp(10),dp(12),dp(10)); summary.setBackground(bg(Color.WHITE,12)); body.addView(summary);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        final String[] reportText={""}; final String[] reportName={"Rapport_Lumicash.pdf"};

        Runnable render=()->{
            summary.removeAllViews(); list.removeAllViews();
            JSONArray arr=lumicashReadLocal();
            int selected=period.getSelectedItemPosition();
            String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
            String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
            int count=0; double amountTotal=0,feesTotal=0;
            StringBuilder report=new StringBuilder("YOUNGEST'S BUSINESS\nJOURNAL LUMICASH — TRANSFERTS FBu\nAgent : ").append(agent).append("\n");
            report.append("Période : ").append(periods[selected]);
            if(selected==0) report.append(" — ").append(selectedDate[0]);
            report.append("\nGénéré le : ").append(today).append("\n\nHISTORIQUE DES TRANSACTIONS\n");
            for(int i=arr.length()-1;i>=0;i--){
                JSONObject o=arr.optJSONObject(i); if(o==null) continue;
                if(!agent.equals(o.optString("agent"))) continue;
                String d=o.optString("date"),phone=o.optString("phone"),beneficiary=o.optString("beneficiary");
                String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
                if(selected==0 && !selectedDate[0].equals(d)) continue;
                if(selected==1 && !d.startsWith(month)) continue;
                if(!q.isEmpty() && !(phone+" "+beneficiary).toLowerCase(Locale.ROOT).contains(q)) continue;
                String time=transactionTime(o);
                double amount=o.optDouble("amount"), fees=o.optDouble("fees");
                count++; amountTotal+=amount; feesTotal+=fees;
                report.append("• ").append(d).append(" ").append(time).append(" | N° ").append(phone).append(" | Bénéficiaire : ").append(beneficiary).append(" | Montant : ").append(fmt(amount)).append(" FBu | Frais : ").append(fmt(fees)).append(" FBu | Total : ").append(fmt(amount+fees)).append(" FBu\n");
                LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10),dp(8),dp(10),dp(8)); card.setBackground(bg(LIGHT,10));
                card.addView(tv(d+" • "+time+" • N° "+phone,16));
                card.addView(tv("Bénéficiaire : "+beneficiary+"\nMontant : "+fmt(amount)+" FBu\nFrais de dépôt : "+fmt(fees)+" FBu\nTotal : "+fmt(amount+fees)+" FBu",14));
                list.addView(card,new LinearLayout.LayoutParams(-1,dp(145)));
            }
            report.append("\nRÉSUMÉ\nNombre de transactions : ").append(count).append("\nMontant total transféré : ").append(fmt(amountTotal)).append(" FBu\nFrais de dépôt totaux : ").append(fmt(feesTotal)).append(" FBu\nTOTAL GÉNÉRAL : ").append(fmt(amountTotal+feesTotal)).append(" FBu\n");
            reportText[0]=report.toString();
            String suffix=selected==0?selectedDate[0]:selected==1?month:"historique";
            reportName[0]="Rapport_Lumicash_"+agent.replace(" ","_")+"_"+suffix+".pdf";
            summary.addView(tv("📊 "+periods[selected]+(selected==0?" — "+selectedDate[0]:""),18));
            summary.addView(tv("Transactions : "+count+"\nMontant total : "+fmt(amountTotal)+" FBu\nFrais de dépôt : "+fmt(feesTotal)+" FBu\nTOTAL : "+fmt(amountTotal+feesTotal)+" FBu",15));
            if(count==0) list.addView(tv("Aucune transaction pour cette période.",15));
        };
        rerender[0]=render;

        Button refresh=btn("🔄 ACTUALISER L’HISTORIQUE",NAVY);
        refresh.setOnClickListener(v->{refresh.setEnabled(false);refresh.setText("⏳ ACTUALISATION…");loadLumicashCloud(()->{refresh.setEnabled(true);refresh.setText("🔄 ACTUALISER L’HISTORIQUE");render.run();Toast.makeText(this,"Historique LUMICASH actualisé.",Toast.LENGTH_SHORT).show();});});
        body.addView(refresh,new LinearLayout.LayoutParams(-1,dp(50)));
        Button pdf=btn("📄 EXPORTER LE RAPPORT EN PDF",PURPLE);
        pdf.setOnClickListener(v->{pendingJournalPdfText=reportText[0];pendingJournalPdfName=reportName[0];Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");intent.putExtra(Intent.EXTRA_TITLE,pendingJournalPdfName);startActivityForResult(intent,CREATE_JOURNAL_PDF);});
        body.addView(pdf,new LinearLayout.LayoutParams(-1,dp(54)));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(Editable e){}});
        period.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}});
        loadLumicashCloud(render);
        render.run();
        Button back=btn("← RETOUR AU JOURNAL LUMICASH",NAVY); back.setOnClickListener(v->lumicashJournalPage()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void lumicashForm(final String agent){
        base("JOURNAL LUMICASH",BLUE);
        body.addView(tv("NOUVELLE TRANSACTION LUMICASH",20));
        body.addView(tv("Agent : "+agent,16));
        EditText phone=input("Numéro du client",InputType.TYPE_CLASS_PHONE);
        EditText beneficiary=input("Nom du bénéficiaire",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText amount=input("Montant du transfert en FBu",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText fees=input("Frais de dépôt en FBu",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText date=input("Date (AAAA-MM-JJ)",InputType.TYPE_CLASS_DATETIME); date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));

        // Ordre demandé : numéro, bénéficiaire, montant, frais, date, agent.
        body.addView(tv("Numéro du client",15)); body.addView(phone);
        body.addView(tv("Nom du bénéficiaire",15)); body.addView(beneficiary);
        body.addView(tv("Montant",15)); body.addView(amount);
        body.addView(tv("Frais de dépôt",15)); body.addView(fees);
        body.addView(tv("Date",15)); body.addView(date);
        body.addView(tv("Agent",15)); body.addView(tv(agent,16));

        Button save=btn("💾 ENREGISTRER LA TRANSACTION",GREEN);
        save.setOnClickListener(v->{
            try{
                String d=date.getText().toString().trim();
                String ph=phone.getText().toString().trim();
                String ben=beneficiary.getText().toString().trim();
                double a=Double.parseDouble(amount.getText().toString().trim());
                double f=fees.getText().toString().trim().isEmpty()?0:Double.parseDouble(fees.getText().toString().trim());
                if(!d.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}") || ph.length()<6 || ben.isEmpty() || a<=0 || f<0) throw new Exception();
                JSONObject o=new JSONObject();
                String id=UUID.randomUUID().toString();
                o.put("id",id); o.put("agent",agent); o.put("date",d); o.put("phone",ph); o.put("beneficiary",ben); o.put("amount",a); o.put("fees",f); o.put("createdAt",System.currentTimeMillis()); o.put("time",new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date()));
                JSONArray arr=lumicashReadLocal(); arr.put(o); lumicashWriteLocal(arr); uploadLumicashEntry(o);
                Toast.makeText(this,"Transaction LUMICASH enregistrée pour "+agent+".",Toast.LENGTH_LONG).show();
                lumicashAgentPage(agent);
            }catch(Exception e){ Toast.makeText(this,"Vérifiez le numéro, le bénéficiaire, la date et les montants.",Toast.LENGTH_LONG).show(); }
        });
        body.addView(save,new LinearLayout.LayoutParams(-1,dp(58)));
        Button back=btn("← RETOUR AU RAPPORT",NAVY); back.setOnClickListener(v->lumicashAgentPage(agent)); body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    // V24 — journal manuel des opérations Mobile Money. Aucun envoi n'est déclenché ici.
    private static final String JOURNAL_KEY = "yb_mobile_money_journal_v24";

    private JSONArray journalRead(){
        try { return new JSONArray(prefs.getString(JOURNAL_KEY,"[]")); }
        catch(Exception e){ return new JSONArray(); }
    }
    private void journalWrite(JSONArray a){ prefs.edit().putString(JOURNAL_KEY,a.toString()).apply(); }

    private void uploadJournalEntry(JSONObject o){
        if(firestore==null || o==null) return;
        try{
            String id=o.optString("id");
            if(id.isEmpty()) return;
            Map<String,Object> m=new HashMap<>();
            m.put("id",id); m.put("type",o.optString("type","ENVOI"));
            m.put("date",o.optString("date")); m.put("time",o.optString("time",transactionTime(o)));
            m.put("phone",o.optString("phone")); m.put("name",o.optString("name"));
            m.put("category",o.optString("category")); m.put("description",o.optString("description"));
            m.put("network",o.optString("network")); m.put("reference",o.optString("reference"));
            m.put("agent",o.optString("agent"));
            m.put("amount",o.optDouble("amount")); m.put("fees",o.optDouble("fees"));
            m.put("currency",o.optString("currency","CDF")); m.put("status",o.optString("status","Effectuée"));
            long createdAt=o.optLong("createdAt",System.currentTimeMillis()); m.put("createdAt",createdAt); m.put("createdAtMs",createdAt);
            m.put("createdBy",o.optString("createdBy")); m.put("source","android");
            firestore.collection("yb_mobile_money_journal").document(id).set(m)
                .addOnFailureListener(e->Toast.makeText(this,"Échec de synchronisation du Journal des opérations : "+e.getMessage(),Toast.LENGTH_LONG).show());
        }catch(Exception e){ Toast.makeText(this,"Impossible de synchroniser cette opération.",Toast.LENGTH_LONG).show(); }
    }

    private void syncJournalCloud(final Runnable after){
        if(firestore==null) firestore=FirebaseFirestore.getInstance();
        if(!adminSession){ if(after!=null) after.run(); return; }
        firestore.collection("yb_mobile_money_journal").get().addOnSuccessListener(snap->{
            JSONArray local=journalRead();
            java.util.HashSet<String> cloudIds=new java.util.HashSet<>();
            for(DocumentSnapshot d:snap.getDocuments()){
                String id=d.getId(); cloudIds.add(id);
                boolean exists=false;
                for(int i=0;i<local.length();i++){JSONObject item=local.optJSONObject(i);if(item!=null&&id.equals(item.optString("id"))){exists=true;break;}}
                if(!exists){
                    try{
                        JSONObject o=new JSONObject(); o.put("id",id);
                        o.put("type",d.getString("type")==null?"ENVOI":d.getString("type"));
                        o.put("date",d.getString("date")==null?"":d.getString("date"));
                        o.put("time",d.getString("time")==null?"":d.getString("time"));
                        o.put("phone",d.getString("phone")==null?"":d.getString("phone"));
                        o.put("name",d.getString("name")==null?"":d.getString("name"));
                        o.put("category",d.getString("category")==null?"":d.getString("category"));
                        o.put("description",d.getString("description")==null?"":d.getString("description"));
                        o.put("network",d.getString("network")==null?"":d.getString("network"));
                        o.put("reference",d.getString("reference")==null?"":d.getString("reference"));
                        o.put("agent",d.getString("agent")==null?"":d.getString("agent"));
                        o.put("amount",number(d.get("amount"))); o.put("fees",number(d.get("fees")));
                        o.put("currency",d.getString("currency")==null?"CDF":d.getString("currency"));
                        o.put("status",d.getString("status")==null?"Effectuée":d.getString("status"));
                        Object createdAtMs=d.get("createdAtMs"); o.put("createdAt",createdAtMs instanceof Number?((Number)createdAtMs).longValue():longNumber(d.get("createdAt"))); o.put("createdBy",d.getString("createdBy")==null?"":d.getString("createdBy"));
                        local.put(o);
                    }catch(Exception ignored){}
                }
            }
            journalWrite(local);
            // Upload local history with stable document IDs; repeated syncs do not create duplicates.
            for(int i=0;i<local.length();i++){JSONObject o=local.optJSONObject(i);if(o!=null&&!o.optString("id").isEmpty()&&!cloudIds.contains(o.optString("id")))uploadJournalEntry(o);}
            if(after!=null) after.run();
        }).addOnFailureListener(e->{Toast.makeText(this,"Firebase : journal des opérations indisponible. Les données locales sont conservées.",Toast.LENGTH_LONG).show();if(after!=null)after.run();});
    }

    private String journalTypeLabel(String type){
        if("RETRAIT".equalsIgnoreCase(type)) return "RETRAIT";
        if("DEPENSE".equalsIgnoreCase(type)) return "DÉPENSE";
        return "ENVOI";
    }

    void journalPage(){
        base("JOURNAL DES OPÉRATIONS",BLUE);
        body.addView(tv("📒 JOURNAL DES OPÉRATIONS MOBILE MONEY",20));
        body.addView(tv("Un seul journal pour les envois, les retraits et les dépenses. La date et l’heure sont enregistrées automatiquement. Cette rubrique sert au suivi comptable : elle ne déclenche aucun transfert.",14));
        Button add=btn("➕ ENREGISTRER UNE OPÉRATION",GREEN);
        add.setOnClickListener(v->journalForm()); body.addView(add,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText search=input("Rechercher nom, numéro, référence ou description",InputType.TYPE_CLASS_TEXT); body.addView(search);
        Spinner period=new Spinner(this);
        String[] periods={"Date précise","Rapport journalier — aujourd'hui","Rapport mensuel — ce mois","Tout l'historique"};
        period.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,periods)); period.setSelection(3); body.addView(period);
        LinearLayout dateRow=new LinearLayout(this); dateRow.setOrientation(LinearLayout.HORIZONTAL); dateRow.setGravity(Gravity.CENTER_VERTICAL);
        final String[] selectedDate={new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())};
        final Runnable[] rerender={null};
        Button chooseDate=btn("📅 Date : "+selectedDate[0],NAVY); dateRow.addView(chooseDate,new LinearLayout.LayoutParams(0,dp(48),1)); body.addView(dateRow);
        chooseDate.setOnClickListener(v->{Calendar c=Calendar.getInstance(); try{String[] p=selectedDate[0].split("-");c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]));}catch(Exception ignored){} new DatePickerDialog(this,(view,y,m,d)->{selectedDate[0]=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);chooseDate.setText("📅 Date : "+selectedDate[0]);if(rerender[0]!=null)rerender[0].run(); },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();});
        Spinner typeFilter=new Spinner(this); String[] types={"Tous les types","ENVOI","RETRAIT","DÉPENSE"};
        typeFilter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));
        body.addView(tv("Type d’opération",14)); body.addView(typeFilter);
        Spinner statusFilter=new Spinner(this); String[] statuses={"Tous les statuts","Effectuée","En attente","Échouée"};
        statusFilter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses));
        body.addView(tv("Statut de l'opération",14)); body.addView(statusFilter);
        LinearLayout summary=new LinearLayout(this); summary.setOrientation(LinearLayout.VERTICAL); summary.setPadding(dp(12),dp(10),dp(12),dp(10)); summary.setBackground(bg(Color.WHITE,12)); body.addView(summary);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        final String[] reportText={""}; final String[] reportName={"Rapport_Journal_Operations.pdf"};
        Runnable render=()->{
            summary.removeAllViews(); list.removeAllViews(); JSONArray arr=journalRead();
            String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT); int count=0,sendCount=0,withdrawCount=0,expenseCount=0; double sendCdf=0,sendUsd=0,withdrawCdf=0,withdrawUsd=0,expenseCdf=0,expenseUsd=0,sendFeesCdf=0,sendFeesUsd=0,withdrawFeesCdf=0,withdrawFeesUsd=0; int completed=0,pending=0,failed=0;
            StringBuilder report=new StringBuilder("YOUNGEST'S BUSINESS\nRAPPORT DU JOURNAL DES OPÉRATIONS\nPériode : ");
            report.append(periods[period.getSelectedItemPosition()]); if(period.getSelectedItemPosition()==0)report.append(" — ").append(selectedDate[0]); report.append("\nGénéré le : ").append(today).append("\n\nHISTORIQUE DES OPÉRATIONS\n");
            java.util.ArrayList<JSONObject> displayed=new java.util.ArrayList<>();
            for(int i=arr.length()-1;i>=0;i--){ JSONObject o=arr.optJSONObject(i); if(o==null)continue;
                String type=journalTypeLabel(o.optString("type","ENVOI"));
                String date=o.optString("date"),name=o.optString("name"),phone=o.optString("phone"),cur=o.optString("currency","CDF"),status=o.optString("status","Effectuée"),time=transactionTime(o),category=o.optString("category"),description=o.optString("description"),reference=o.optString("reference"),agent=o.optString("agent");
                int selected=period.getSelectedItemPosition(); if(selected==0&&!date.equals(selectedDate[0]))continue; if(selected==1&&!date.equals(today))continue; if(selected==2&&!date.startsWith(month))continue;
                if(typeFilter.getSelectedItemPosition()>0&&!type.equals(types[typeFilter.getSelectedItemPosition()]))continue;
                if(statusFilter.getSelectedItemPosition()>0&&!status.equals(statuses[statusFilter.getSelectedItemPosition()]))continue;
                String searchable=(name+" "+phone+" "+category+" "+description+" "+reference+" "+agent).toLowerCase(Locale.ROOT);
                if(!q.isEmpty()&&!searchable.contains(q))continue;
                displayed.add(o);
                double amount=o.optDouble("amount"),fees=o.optDouble("fees");
                if("Effectuée".equals(status)){
                    count++; completed++;
                    if("ENVOI".equals(type)){sendCount++;if("USD".equals(cur)){sendUsd+=amount;sendFeesUsd+=fees;}else{sendCdf+=amount;sendFeesCdf+=fees;}}
                    else if("RETRAIT".equals(type)){withdrawCount++;if("USD".equals(cur)){withdrawUsd+=amount;withdrawFeesUsd+=fees;}else{withdrawCdf+=amount;withdrawFeesCdf+=fees;}}
                    else {expenseCount++;if("USD".equals(cur))expenseUsd+=amount;else expenseCdf+=amount;}
                }else if("En attente".equals(status))pending++;else if("Échouée".equals(status))failed++;
                String detail="DÉPENSE".equals(type)?(category+" — "+description):((name.isEmpty()?"—":name)+" | "+(phone.isEmpty()?"—":phone));
                String feeLabel="ENVOI".equals(type)?"Frais d'envoi":"Frais de retrait";
                report.append(date).append(" ").append(time).append(" | ").append(type).append(" | ").append(detail).append(" | ").append(status).append(" | Montant : ").append(money(amount,cur));
                if(!"DEPENSE".equals(type))report.append(" | ").append(feeLabel).append(" : ").append(money(fees,cur));
                report.append(" | Agent : ").append(agent.isEmpty()?"—":agent).append(" | Réf. : ").append(reference.isEmpty()?"—":reference).append("\n");
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setBackground(bg(LIGHT,10));
                card.addView(tv(date+" • "+time+" • "+type,16));
                StringBuilder detailText=new StringBuilder();
                if("DEPENSE".equals(type))detailText.append("Catégorie : ").append(category.isEmpty()?"—":category).append("\nDescription : ").append(description.isEmpty()?"—":description);
                else detailText.append(("ENVOI".equals(type)?"Bénéficiaire : ":"Client : ")).append(name.isEmpty()?"—":name).append("\nN° : ").append(phone.isEmpty()?"—":phone).append("\nRéseau : ").append(o.optString("network","—"));
                detailText.append("\nMontant : ").append(money(amount,cur));
                if(!"DEPENSE".equals(type))detailText.append("\n").append(feeLabel).append(" : ").append(money(fees,cur)).append("\nTotal : ").append(money(amount+fees,cur));
                detailText.append("\nStatut : ").append(status).append("\nAgent : ").append(agent.isEmpty()?"—":agent);
                if(!reference.isEmpty())detailText.append("\nRéférence : ").append(reference);
                card.addView(tv(detailText.toString(),14)); list.addView(card,new LinearLayout.LayoutParams(-1,-2));
            }
            report.append("\nRÉSUMÉ DES OPÉRATIONS EFFECTUÉES\nNombre : ").append(count)
                .append("\nENVOIS : ").append(sendCount).append(" | CDF : ").append(money(sendCdf,"CDF")).append(" | USD : ").append(money(sendUsd,"USD"))
                .append("\nFRAIS D'ENVOI : CDF ").append(money(sendFeesCdf,"CDF")).append(" | USD ").append(money(sendFeesUsd,"USD"))
                .append("\nRETRAITS : ").append(withdrawCount).append(" | CDF : ").append(money(withdrawCdf,"CDF")).append(" | USD : ").append(money(withdrawUsd,"USD"))
                .append("\nFRAIS DE RETRAIT : CDF ").append(money(withdrawFeesCdf,"CDF")).append(" | USD ").append(money(withdrawFeesUsd,"USD"))
                .append("\nDÉPENSES : ").append(expenseCount).append(" | CDF : ").append(money(expenseCdf,"CDF")).append(" | USD : ").append(money(expenseUsd,"USD"))
                .append("\nStatuts : ").append(completed).append(" effectuées, ").append(pending).append(" en attente, ").append(failed).append(" échouées.");
            reportText[0]=report.toString(); reportName[0]="Rapport_Journal_Operations_"+(period.getSelectedItemPosition()==0?selectedDate[0]:period.getSelectedItemPosition()==2?month:today)+".pdf";
            summary.addView(tv("📊 " + periods[period.getSelectedItemPosition()] +(period.getSelectedItemPosition()==0?" — "+selectedDate[0]:""),18));
            summary.addView(tv("ENVOIS : "+sendCount+"\nCDF : "+money(sendCdf,"CDF")+" • USD : "+money(sendUsd,"USD")+"\nFrais d'envoi : "+money(sendFeesCdf,"CDF")+" CDF • "+money(sendFeesUsd,"USD")+" USD",14));
            summary.addView(tv("RETRAITS : "+withdrawCount+"\nCDF : "+money(withdrawCdf,"CDF")+" • USD : "+money(withdrawUsd,"USD")+"\nFrais de retrait : "+money(withdrawFeesCdf,"CDF")+" CDF • "+money(withdrawFeesUsd,"USD")+" USD",14));
            summary.addView(tv("DÉPENSES : "+expenseCount+"\nCDF : "+money(expenseCdf,"CDF")+" • USD : "+money(expenseUsd,"USD"),14));
            summary.addView(tv("Statuts : "+completed+" effectuées • "+pending+" en attente • "+failed+" échouées",14));
            if(displayed.isEmpty())list.addView(tv("Aucune opération pour ce filtre.",15));
        };
        rerender[0]=render;
        Button refresh=btn("🔄 ACTUALISER L’HISTORIQUE",NAVY);
        refresh.setOnClickListener(v->{refresh.setEnabled(false);refresh.setText("⏳ ACTUALISATION…");syncJournalCloud(()->{refresh.setEnabled(true);refresh.setText("🔄 ACTUALISER L’HISTORIQUE");render.run();Toast.makeText(this,"Journal des opérations actualisé.",Toast.LENGTH_SHORT).show();});});
        body.addView(refresh,new LinearLayout.LayoutParams(-1,dp(50)));
        Button pdf=btn("📄 EXPORTER LE RAPPORT EN PDF",PURPLE); pdf.setOnClickListener(v->{pendingJournalPdfText=reportText[0];pendingJournalPdfName=reportName[0];Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");intent.putExtra(Intent.EXTRA_TITLE,pendingJournalPdfName);startActivityForResult(intent,CREATE_JOURNAL_PDF);});body.addView(pdf,new LinearLayout.LayoutParams(-1,dp(54)));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(Editable e){}});
        period.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}});
        typeFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}});
        statusFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}});
        syncJournalCloud(render);
        render.run();
    }

    void journalForm(){
        base("JOURNAL DES OPÉRATIONS",BLUE);
        body.addView(tv("Enregistrez une opération déjà réalisée. Aucune transaction réelle n'est déclenchée depuis ce formulaire.",14));
        Spinner type=new Spinner(this); String[] typeLabels={"ENVOI D'ARGENT","RETRAIT D'ARGENT","DÉPENSE"};
        type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,typeLabels));
        body.addView(tv("Type d'opération",15)); body.addView(type);
        String nowDate=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        String nowTime=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date());
        TextView dateValue=tv("Date automatique : "+nowDate,15); TextView timeValue=tv("Heure automatique : "+nowTime,15);
        body.addView(dateValue); body.addView(timeValue);
        TextView nameLabel=tv("Nom du bénéficiaire",15); EditText name=input("Nom complet",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        TextView phoneLabel=tv("Numéro du bénéficiaire",15); EditText phone=input("Numéro Mobile Money",InputType.TYPE_CLASS_PHONE);
        body.addView(nameLabel); body.addView(name); body.addView(phoneLabel); body.addView(phone);
        Spinner category=new Spinner(this); String[] categories={"TRANSPORT","FOURNITURES","LOYER","ÉLECTRICITÉ","COMMUNICATION","ENTRETIEN","SALAIRE","AUTRE"};
        category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,categories));
        TextView categoryLabel=tv("Catégorie de la dépense",15); EditText description=input("Description de la dépense",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        TextView descriptionLabel=tv("Description",15); body.addView(categoryLabel); body.addView(category); body.addView(descriptionLabel); body.addView(description);
        Spinner network=new Spinner(this); String[] networks={"M-Pesa / Vodacom","Airtel Money","Orange Money","Afrimoney","Autre / Non précisé"};
        network.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,networks));
        TextView networkLabel=tv("Réseau",15); body.addView(networkLabel); body.addView(network);
        EditText amount=input("Montant",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); body.addView(tv("Montant",15)); body.addView(amount);
        TextView feesLabel=tv("Frais d'envoi",15); EditText fees=input("Frais",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); body.addView(feesLabel); body.addView(fees);
        Spinner currency=new Spinner(this); currency.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"CDF — Franc congolais","USD — Dollar américain"}));
        body.addView(tv("Devise",15)); body.addView(currency);
        Spinner status=new Spinner(this); status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Effectuée","En attente","Échouée"}));
        body.addView(tv("Statut de l'opération",15)); body.addView(status);
        EditText agent=input("Agent responsable",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        if(firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null){String who=firebaseAuth.getCurrentUser().getDisplayName();if(who==null||who.trim().isEmpty())who=firebaseAuth.getCurrentUser().getEmail();if(who!=null)agent.setText(who);}
        body.addView(tv("Agent responsable",15));body.addView(agent);
        EditText reference=input("Référence (facultatif)",InputType.TYPE_CLASS_TEXT);body.addView(tv("Référence de l'opération (facultatif)",15));body.addView(reference);
        Runnable updateType=()->{
            boolean expense=type.getSelectedItemPosition()==2; boolean withdrawal=type.getSelectedItemPosition()==1;
            nameLabel.setText(expense?"Nom du fournisseur / bénéficiaire (facultatif)":withdrawal?"Nom du client":"Nom du bénéficiaire");
            phoneLabel.setText(expense?"Téléphone (facultatif)":withdrawal?"Numéro du client":"Numéro du bénéficiaire");
            name.setHint(expense?"Nom du fournisseur (facultatif)":"Nom complet"); phone.setHint(expense?"Téléphone (facultatif)":"Numéro Mobile Money");
            int personVisibility=expense?View.GONE:View.VISIBLE; nameLabel.setVisibility(personVisibility);name.setVisibility(personVisibility);phoneLabel.setVisibility(personVisibility);phone.setVisibility(personVisibility);
            int expenseVisibility=expense?View.VISIBLE:View.GONE;categoryLabel.setVisibility(expenseVisibility);category.setVisibility(expenseVisibility);descriptionLabel.setVisibility(expenseVisibility);description.setVisibility(expenseVisibility);
            networkLabel.setVisibility(expense?View.GONE:View.VISIBLE);network.setVisibility(expense?View.GONE:View.VISIBLE);
            feesLabel.setVisibility(expense?View.GONE:View.VISIBLE);fees.setVisibility(expense?View.GONE:View.VISIBLE);
            feesLabel.setText(withdrawal?"Frais de retrait":"Frais d'envoi"); fees.setHint(withdrawal?"Frais de retrait":"Frais d'envoi");
            amount.setHint(expense?"Montant de la dépense":withdrawal?"Montant retiré":"Montant envoyé");
        };
        type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){updateType.run();}}); updateType.run();
        Button save=btn("💾 ENREGISTRER L'OPÉRATION",GREEN);
        save.setOnClickListener(v->{try{
            long created=System.currentTimeMillis(); Date captured=new Date(created);
            String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(captured),t=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(captured);
            dateValue.setText("Date automatique : "+d); timeValue.setText("Heure automatique : "+t);
            String opType=type.getSelectedItemPosition()==2?"DEPENSE":type.getSelectedItemPosition()==1?"RETRAIT":"ENVOI";
            boolean expense="DEPENSE".equals(opType);
            String nm=name.getText().toString().trim(),ph=phone.getText().toString().trim(),desc=description.getText().toString().trim();
            double a=Double.parseDouble(amount.getText().toString().trim()),f=expense?0:(fees.getText().toString().trim().isEmpty()?0:Double.parseDouble(fees.getText().toString().trim()));
            if(a<=0||f<0||(!expense&&(ph.length()<6||nm.isEmpty()))||(expense&&desc.isEmpty()))throw new Exception();
            String[] networkValues={"M-Pesa","Airtel Money","Orange Money","Afrimoney","Autre"};
            String savedName=expense?"":nm,savedPhone=expense?"":ph;
            JSONArray arr=journalRead(); JSONObject o=new JSONObject();
            o.put("id",UUID.randomUUID().toString());o.put("type",opType);o.put("date",d);o.put("time",t);o.put("phone",savedPhone);o.put("name",savedName);o.put("category",expense?String.valueOf(category.getSelectedItem()):"");o.put("description",expense?desc:"");o.put("network",expense?"":networkValues[network.getSelectedItemPosition()]);o.put("reference",reference.getText().toString().trim());o.put("agent",agent.getText().toString().trim());o.put("amount",a);o.put("fees",f);o.put("currency",currency.getSelectedItemPosition()==1?"USD":"CDF");o.put("status",String.valueOf(status.getSelectedItem()));o.put("createdAt",created);o.put("createdBy",firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null?firebaseAuth.getCurrentUser().getUid():"");
            arr.put(o);journalWrite(arr);uploadJournalEntry(o);
            Toast.makeText(this,"Opération enregistrée dans le journal et synchronisation demandée.",Toast.LENGTH_LONG).show();journalPage();
        }catch(Exception e){Toast.makeText(this,"Vérifiez le type, la description et les montants. Pour un envoi ou retrait, vérifiez aussi le nom et le numéro.",Toast.LENGTH_LONG).show();}});
        body.addView(save,new LinearLayout.LayoutParams(-1,dp(58)));
        Button back=btn("← RETOUR AU JOURNAL",NAVY);back.setOnClickListener(v->journalPage());body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    // V24 : interface centrale Mobile Money utilisée dans les espaces Client et Administration.
    // Elle présente les actions; elle ne prétend pas exécuter un transfert sans confirmation du prestataire.
    void services(){
        base("YOUNGEST’S BUSINESS",NAVY);
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_youngests_business);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(28),dp(4),dp(28),dp(4));
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(92)));
        TextView brand=tv("PAIEMENTS & TRANSFERTS",20);
        brand.setGravity(Gravity.CENTER); brand.setTextColor(NAVY); brand.setTypeface(null,Typeface.BOLD);
        body.addView(brand);
        body.addView(tv(clientMode ? "Espace Client — choisissez une opération" : "Espace Administration — gestion des opérations",15));
        body.addView(tv("Que souhaitez-vous faire ?",19));

        GridLayout grid=new GridLayout(this); grid.setColumnCount(2);
        String[] labels={"➤\nEnvoyer de l’argent\nTransfert P2P","⇩\nRecevoir\nCoordonnées de réception","▤\nHistorique\nOpérations effectuées","▥\nRapports\nJournal et frais"};
        int[] colors={Color.rgb(20,125,65),BLUE,PURPLE,GOLD};
        for(int i=0;i<labels.length;i++){
            final int action=i;
            Button tile=btn(labels[i],colors[i]);
            tile.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
            tile.setPadding(dp(14),dp(10),dp(8),dp(10));
            tile.setTextSize(16);
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=0; lp.height=dp(118); lp.columnSpec=GridLayout.spec(i%2,1,1); lp.rowSpec=GridLayout.spec(i/2);
            lp.setMargins(dp(5),dp(5),dp(5),dp(5)); grid.addView(tile,lp);
            tile.setOnClickListener(v->{
                if(action==0){ if(clientMode) clientTransferPage(); else transfers(); }
                else if(action==1) receivePage();
                else if(action==2){ if(clientMode) clientTransferHistoryPage(); else transferListPage("HISTORIQUE"); }
                else { if(clientMode) clientTransferHistoryPage(); else journalPage(); }
            });
        }
        body.addView(grid);
        body.addView(tv("Opérateurs disponibles",18));
        LinearLayout ops=new LinearLayout(this); ops.setOrientation(LinearLayout.HORIZONTAL);
        String[] networks={"Vodacom","Airtel","Orange","Afrimoney"}; int[] nc={RED,RED,GOLD,BLUE};
        for(int i=0;i<networks.length;i++){
            TextView op=tv(networks[i],13); op.setTextColor(Color.WHITE); op.setGravity(Gravity.CENTER); op.setTypeface(null,Typeface.BOLD);
            op.setPadding(dp(3),dp(12),dp(3),dp(12)); op.setBackground(bg(nc[i],10));
            LinearLayout.LayoutParams olp=new LinearLayout.LayoutParams(0,dp(54),1); olp.setMargins(dp(3),dp(4),dp(3),dp(4)); ops.addView(op,olp);
        }
        body.addView(ops);
        body.addView(tv(clientMode ? "Vos opérations apparaîtront dans l’historique après confirmation par le prestataire." : "Journal manuel et rapports disponibles pour les opérations déjà réalisées. Les transferts réels nécessitent une réponse confirmée du prestataire.",14));
        Button back=btn(clientMode?"← ESPACE CLIENT":"← ACCUEIL ADMINISTRATION",NAVY);
        back.setOnClickListener(v->{if(clientMode)clientHome();else home();}); body.addView(back,new LinearLayout.LayoutParams(-1,dp(50)));
    }

    void receivePage(){
        base("RECEVOIR DE L’ARGENT",BLUE);
        body.addView(tv("Coordonnées de réception YOUNGEST’S BUSINESS",18));
        body.addView(tv("Sélectionnez le réseau et copiez le numéro pour effectuer le paiement dans l’application de votre opérateur.",14));
        mobileReceiver("📱 M-Pesa", "+243 817 447 127", "MUTABESHA MUSHAGALUSA ELISHA");
        mobileReceiver("📱 Airtel Money", "+243 994 565 534", "ELISHA MUTABESHA");
        mobileReceiver("📱 Orange Money", "+243 840 890 183", "ELISHA MUTABESHA");
        mobileReceiver("📱 Afrimoney", "+243 907 751 352", "ELISHA MUSHAGALUSA");
        body.addView(tv("Le paiement est exécuté dans le service Mobile Money de l’opérateur, pas dans cette page.",14));
        Button back=btn("← RETOUR À PAIEMENTS & TRANSFERTS",NAVY); back.setOnClickListener(v->services()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void mobileReceiver(String network, String number, String name){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(8),dp(12),dp(8));
        card.setBackground(bg(GREEN,14));
        TextView title=tv(network,17); title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        TextView info=tv("Numéro : "+number+"\nNom : "+name,15); info.setTextColor(Color.WHITE);
        card.addView(title); card.addView(info);
        Button copy=btn("📋 COPIER LE NUMÉRO",NAVY);
        copy.setOnClickListener(v->{
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Numéro "+network, number.replace(" ","")));
            Toast.makeText(this,"Numéro copié : "+number,Toast.LENGTH_SHORT).show();
        });
        card.addView(copy);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(150));
        cp.setMargins(0,dp(5),0,dp(5));
        body.addView(card,cp);
    }

    // WonyaSoft indique actuellement 2 % sur les transactions sortantes en production.
    // Le backend reste la source de vérité pour les frais réellement retournés par WonyaPay.
    static final double TRANSFER_FEE_RATE = 0.02;

    String money(double x, String currency){
        return fmt(x) + ("USD".equals(currency) ? " $" : " FC");
    }

    void transfers(){
        base("TRANSFERT MOBILE MONEY",BLUE);
        body.addView(tv("💸 TRANSFERTS WONYAPAY B2C",19));
        body.addView(tv("Réseaux : M-Pesa • Airtel Money • Orange Money • Afrimoney\nDevises : CDF • USD\nFrais sortants affichés à titre indicatif : 2 %. Le montant/frais réellement retournés par WonyaPay font foi.",14));

        Button b=btn("➕ NOUVEAU TRANSFERT",GREEN); b.setOnClickListener(v->newTransferPage());
        body.addView(b,new LinearLayout.LayoutParams(-1,dp(58)));
        Button in=btn("🟠 EN COURS",GOLD); in.setOnClickListener(v->transferListPage("EN_COURS"));
        Button done=btn("✅ TERMINÉS",GREEN); done.setOnClickListener(v->transferListPage("TERMINE"));
        Button cancelled=btn("❌ ANNULÉS / ÉCHECS",RED); cancelled.setOnClickListener(v->transferListPage("ANNULE"));
        Button history=btn("📜 HISTORIQUE COMPLET",NAVY); history.setOnClickListener(v->transferListPage("HISTORIQUE"));
        body.addView(in,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(done,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(cancelled,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(history,new LinearLayout.LayoutParams(-1,dp(52)));

        double fc=0, usd=0, feesFc=0, feesUsd=0; int count=0;
        for(Transfer t:transfersList){
            if("TERMINE".equals(t.status)){
                count++;
                if("USD".equals(t.currency)){ usd+=t.amount; feesUsd+=t.fees; }
                else { fc+=t.amount; feesFc+=t.fees; }
            }
        }
        body.addView(tv("📊 RÉSUMÉ DES TRANSFERTS TERMINÉS\nOpérations : "+count+"\nCDF : "+money(fc,"CDF")+" | Frais : "+money(feesFc,"CDF")+"\nUSD : "+money(usd,"USD")+" | Frais : "+money(feesUsd,"USD"),15));
    }

    void newTransferPage(){
        base("NOUVEAU TRANSFERT",BLUE);
        body.addView(tv("💸 TRANSFERT B2C — WONYAPAY",19));
        body.addView(tv("Ce formulaire correspond au format B2C de l'API WonyaPay : réseau/caisse, numéro bénéficiaire, montant, devise, motif. La référence API est générée côté serveur.",14));

        final String[] networks={"M-Pesa","Airtel Money","Orange Money","Afrimoney"};
        final String[] currencies={"CDF — Franc congolais","USD — Dollar américain"};
        body.addView(tv("📲 RÉSEAU DU BÉNÉFICIAIRE",17));
        Spinner network=new Spinner(this);
        network.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,networks));
        body.addView(network);

        body.addView(tv("📱 BÉNÉFICIAIRE",17));
        EditText bp=input("Numéro Mobile Money (10 chiffres)",InputType.TYPE_CLASS_PHONE);
        EditText bn=input("Nom du bénéficiaire (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        body.addView(bp); body.addView(bn);

        body.addView(tv("💰 MONTANT",17));
        Spinner currencySpinner=new Spinner(this);
        currencySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,currencies));
        body.addView(currencySpinner);
        EditText amount=input("Montant à transférer",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView fee=tv("Frais estimés (2 %) : —",17);
        TextView total=tv("Total estimé à débiter : —",18);
        body.addView(amount); body.addView(fee); body.addView(total);
        TextWatcher tw=new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ updateTransferTotal(amount,fee,total,currencySpinner); }
            public void afterTextChanged(Editable e){}
        };
        amount.addTextChangedListener(tw);
        currencySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ updateTransferTotal(amount,fee,total,currencySpinner); }
        });

        EditText reason=input("Motif / description (facultatif)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.addView(tv("📋 MOTIF",17)); body.addView(reason);
        body.addView(tv("🔐 La clé API WonyaPay n'est pas stockée dans l'APK. L'application appelle une fonction Firebase sécurisée qui porte le token côté serveur.",13));

        Button confirm=btn("💸 ENVOYER VIA WONYA PAY",GREEN);
        confirm.setOnClickListener(v->{
            try{
                String beneficiaryPhone=normalizePhone(bp.getText().toString().trim());
                double a=Double.parseDouble(amount.getText().toString().trim());
                String br=network.getSelectedItem().toString();
                if(beneficiaryPhone.length()!=10 || !beneficiaryPhone.matches("[0-9]{10}") || a<=0) throw new Exception();
                String cur=currencySpinner.getSelectedItemPosition()==1?"USD":"CDF";
                double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
                Transfer t=new Transfer(cur,"YOUNGEST'S BUSINESS","","CAISSE WONYA PAY",bn.getText().toString().trim(),beneficiaryPhone,br,a,f,reason.getText().toString().trim());
                t.clientInitiated=false;
                t.apiStatus="PREPARATION";
                transfersList.add(t); saveData();
                submitWonyaPayTransfer(t, ()->showTransferReceipt(t));
            }catch(Exception e){ Toast.makeText(this,"Veuillez vérifier le numéro à 10 chiffres et le montant.",Toast.LENGTH_LONG).show(); }
        });
        body.addView(confirm,new LinearLayout.LayoutParams(-1,dp(60)));
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    void updateTransferTotal(EditText amount,TextView fee,TextView total,Spinner currencySpinner){
        try{
            double a=Double.parseDouble(amount.getText().toString().trim());
            String cur=currencySpinner.getSelectedItemPosition()==1?"USD":"CDF";
            double f=Math.round(a*TRANSFER_FEE_RATE*100.0)/100.0;
            fee.setText("Frais estimés (2 %) : "+money(f,cur));
            total.setText("Total estimé à débiter : "+money(a+f,cur));
        }catch(Exception e){ fee.setText("Frais estimés (2 %) : —"); total.setText("Total estimé à débiter : —"); }
    }

    String transferStatusLabel(String s){
        if("TERMINE".equals(s)) return "TERMINÉ";
        if("ANNULE".equals(s)) return "ANNULÉ / ÉCHEC";
        return "EN COURS";
    }

    void transferListPage(String filter){
        String title="HISTORIQUE DES TRANSFERTS";
        if("EN_COURS".equals(filter)) title="TRANSFERTS EN COURS";
        else if("TERMINE".equals(filter)) title="TRANSFERTS TERMINÉS";
        else if("ANNULE".equals(filter)) title="TRANSFERTS ANNULÉS / ÉCHECS";
        base(title,BLUE);
        if(transfersList.isEmpty()) body.addView(tv("Aucun transfert enregistré.",16));
        int shown=0;
        for(int i=transfersList.size()-1;i>=0;i--){
            Transfer t=transfersList.get(i);
            if(!"HISTORIQUE".equals(filter) && !filter.equals(t.status)) continue;
            shown++;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10),dp(8),dp(10),dp(8)); card.setBackground(bg(LIGHT,12));
            TextView head=tv(t.id+"  •  "+transferStatusLabel(t.status),17); head.setTypeface(null,Typeface.BOLD); card.addView(head);
            String beneficiary=t.beneficiaryName.isEmpty()?"Bénéficiaire":t.beneficiaryName;
            card.addView(tv(beneficiary+"\n"+t.beneficiaryNetwork+" — "+t.beneficiaryPhone+"\n"+money(t.amount,t.currency)+"  |  Frais : "+money(t.fees,t.currency)+"\nTotal : "+money(t.total(),t.currency)+"\nAPI : "+t.apiStatus+(t.providerReference.isEmpty()?"":"\nRéf. prestataire : "+t.providerReference)+"\n"+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t.date)),14));
            if(!t.reason.isEmpty()) card.addView(tv("Motif : "+t.reason,13));
            body.addView(card,new LinearLayout.LayoutParams(-1,dp(205)));
        }
        if(shown==0) body.addView(tv("Aucun transfert dans cette rubrique.",16));
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back,new LinearLayout.LayoutParams(-1,dp(54)));
    }

    void showTransferReceipt(Transfer t){
        base("REÇU DU TRANSFERT",GREEN);
        body.addView(tv("📄 TRANSFERT — "+transferStatusLabel(t.status),20));
        String beneficiary=t.beneficiaryName.isEmpty()?"Non renseigné":t.beneficiaryName;
        StringBuilder s=new StringBuilder();
        s.append("Référence YOUNGEST'S BUSINESS : ").append(t.id)
         .append("\nBénéficiaire : ").append(beneficiary)
         .append("\nRéseau : ").append(t.beneficiaryNetwork)
         .append("\nNuméro : ").append(t.beneficiaryPhone)
         .append("\n\nMontant : ").append(money(t.amount,t.currency))
         .append("\nFrais : ").append(money(t.fees,t.currency))
         .append("\nTotal : ").append(money(t.total(),t.currency))
         .append("\n\nStatut : ").append(transferStatusLabel(t.status))
         .append("\nAPI : ").append(t.apiStatus);
        if(!t.providerReference.isEmpty()) s.append("\nRéférence prestataire : ").append(t.providerReference);
        s.append("\nDate : ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t.date)));
        if(!t.reason.isEmpty()) s.append("\nMotif : ").append(t.reason);
        body.addView(tv(s.toString(),15));
        if("EN_COURS".equals(t.status)) {
            body.addView(tv("⏳ La transaction est en attente. Ne relancez pas le même transfert tant que son statut n'est pas connu afin d'éviter un doublon.",14));
            Button check=btn("🔄 VÉRIFIER LE STATUT WONYAPAY",BLUE);
            check.setOnClickListener(v->refreshWonyaPayStatus(t));
            body.addView(check,new LinearLayout.LayoutParams(-1,dp(56)));
        }
        if("TERMINE".equals(t.status)) body.addView(tv("✅ WonyaPay a accepté le transfert. La référence prestataire est conservée dans l'historique.",14));
        Button history=btn("📜 HISTORIQUE",BLUE); history.setOnClickListener(v->transferListPage("HISTORIQUE")); body.addView(history);
        Button back=btn("← RETOUR AUX TRANSFERTS",NAVY); back.setOnClickListener(v->transfers()); body.addView(back);
    }

    @Override protected void onDestroy(){
        if(clientsListener!=null) clientsListener.remove();
        if(loansListener!=null) loansListener.remove();
        if(paymentsListener!=null) paymentsListener.remove();
        if(loanRequestsListener!=null) loanRequestsListener.remove();
        super.onDestroy();
    }

    String date(long time){return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date(time));}
    String fmt(double x){return String.format(Locale.US,"%,.0f",x).replace(',',' ');}
}
