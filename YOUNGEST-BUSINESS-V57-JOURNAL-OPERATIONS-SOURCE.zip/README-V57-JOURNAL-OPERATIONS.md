# YOUNGEST’S BUSINESS V57 — Journal des opérations

## Portée
Cette version reconstruit le module **Journal des opérations** dans l’application Android et le Web Admin. Il regroupe trois catégories dans la collection Firebase existante `yb_mobile_money_journal` :

- `ENVOI` : bénéficiaire, numéro, opérateur, montant, devise, **frais d’envoi**, statut, agent et référence.
- `RETRAIT` : client, numéro, opérateur, montant, devise, frais de retrait, statut, agent et référence.
- `DEPENSE` : catégorie, description, montant, devise, statut, agent et référence.

La date (`yyyy-MM-dd`) et l’heure (`HH:mm:ss`) sont générées automatiquement au moment de l’enregistrement. Les anciens enregistrements sans champ `type` restent traités comme des envois.

## Synchronisation et rapports
- Android et Web Admin utilisent la collection Firestore `yb_mobile_money_journal`.
- Les champs `type`, `date`, `time`, `category`, `description`, `network`, `fees`, `currency`, `status`, `agent` et `reference` sont conservés.
- Les vues récapitulatives séparent envois, retraits, dépenses, frais d’envoi et frais de retrait.
- Les filtres de période, le filtrage par type et l’export PDF sont disponibles dans le journal Android ; le Web Admin propose également le filtrage par période, la recherche et l’export PDF.

## Sécurité et limites
Le formulaire reste un registre comptable manuel. Il ne déclenche pas de transfert, de retrait ou de paiement réel. Les opérations doivent être enregistrées après leur exécution ou confirmation par le prestataire. Les règles Firestore existantes continuent de réserver les lectures et écritures du journal à l’administrateur.

## Vérification
Le JavaScript du Web Admin doit passer `node --check`. La compilation Android et le déploiement Firebase doivent être validés par le workflow GitHub Actions V57 avec les secrets de signature Android et le compte de service Firebase déjà utilisés par le dépôt.
