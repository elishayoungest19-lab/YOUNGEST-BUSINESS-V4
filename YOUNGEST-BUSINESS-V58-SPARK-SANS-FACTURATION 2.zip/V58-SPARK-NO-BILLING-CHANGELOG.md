# V58 Spark — adaptation sans facturation

- Web Admin Lumicash : écriture Firestore directe protégée par les règles existantes `isAdmin()`.
- Suppression de l'appel callable depuis le navigateur et retrait des champs PIN Web (le PIN côté navigateur ne peut pas être vérifié secrètement sans backend).
- Workflow : compilation APK signée, puis déploiement Hosting + règles Firestore uniquement. Aucun déploiement Cloud Functions.
- Les fonctions serveur existantes sont conservées dans le code mais ne sont pas déployées ; les fonctionnalités qui en dépendent ne sont pas garanties sur Spark.
