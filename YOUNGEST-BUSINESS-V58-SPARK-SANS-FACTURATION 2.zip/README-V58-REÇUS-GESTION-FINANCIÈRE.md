# YOUNGEST’S BUSINESS V58 — Reçus Mobile Money

## Modifications intégrées dans les sources
- Le formulaire Android du Journal des opérations comporte désormais Nom et Postnom distincts pour les transactions ENVOI et RETRAIT.
- Le postnom est sauvegardé localement et synchronisé dans `yb_mobile_money_journal` via le champ `postName`.
- Une référence YB-MM horodatée est générée si aucune référence externe n’est fournie.
- Chaque ligne ENVOI / RETRAIT de l’historique Android propose « VOIR / IMPRIMER LE REÇU ». Le reçu reprend l’opérateur, la référence, le type, la date/heure, le nom, le postnom, le numéro, le montant, les frais, l’agent et le statut.
- Le Web Admin ajoute le champ Postnom, génère une référence si elle est absente et propose Voir / Imprimer pour chaque opération ENVOI / RETRAIT.
- Les reçus sont des reçus internes de registre YOUNGEST’S BUSINESS. Ils ne constituent pas une preuve de règlement du réseau opérateur ; le statut enregistré est affiché tel quel.

## Compatibilité
- Collection conservée : `yb_mobile_money_journal`.
- Les anciennes transactions restent lisibles ; le champ `postName` est facultatif pour les anciens enregistrements.
- Version Android : `versionCode 58`, `versionName 1.58.0-mobile-money-receipts`.

## Vérifications effectuées ici
- `node --check web-admin/app.js` : réussi.
- Vérification statique des champs et boutons de reçu : à effectuer dans le workflow GitHub Actions.
- Compilation Android : non exécutée dans l’environnement de préparation (Gradle et Android SDK ne sont pas installés). Le workflow GitHub Actions V58 doit confirmer la compilation APK et la signature avant déploiement.


## Correctif V58 — journaux Lumicash et Wi-Fi
- Les dépenses Lumicash sont enregistrées comme opérations `DEPENSE` dans la collection existante `yb_lumicash_journal` ; elles ne nécessitent donc pas une nouvelle collection Firestore ni une règle supplémentaire. Le callable `createLumicashJournalEntry` valide l’administrateur, le PIN de l’agent, le type, la devise et les montants avant l’écriture serveur.
- Android et Web Admin lisent et affichent les dépenses dans le même historique que les dépôts et retraits Lumicash. Les rapports distinguent FBU, CDF et USD sans conversion.
- Correction du calcul Android du résultat net Lumicash : frais de dépôt + commissions de retrait − dépenses. La version précédente omettait les commissions de retrait dans le résultat net.
- Les dépenses Wi-Fi utilisent la collection dédiée `yb_wifi_expenses`, déjà présente dans les règles Firestore V58, et sont séparées des ventes confirmées.
- Les dépenses Wi-Fi sont déduites des recettes confirmées dans les rapports Android et Web Admin, par devise.

## Limites de validation
- Les règles Firestore et les fonctions callable ont été inspectées statiquement ; aucun test d’écriture sur le projet Firebase de production n’a été exécuté.
- La compilation Android et la signature APK doivent être confirmées par GitHub Actions avant publication.
- Les coupons Wi-Fi restent un registre administratif : l’activation réelle sur MikroTik nécessite encore une intégration réseau sécurisée et des tests matériels.


## Correctif V58-Spark — mode sans facturation
- Le Web Admin n'appelle plus la Cloud Function `createLumicashJournalEntry` pour les écritures du Journal LUMICASH. Il écrit directement dans `yb_lumicash_journal` via le SDK Firestore, après contrôle de la session et du compte administrateur.
- Les règles Firestore existantes limitent déjà la lecture et les écritures de `yb_lumicash_journal` à `isAdmin()` (UID administrateur ou adresse e-mail administrateur). Elles restent la barrière de sécurité côté serveur ; le contrôle JavaScript n'est qu'une aide d'interface.
- Le formulaire Web n'utilise plus le PIN agent saisi côté navigateur. L'identité autorisée à écrire est le compte administrateur Firebase connecté. Le nom de l'agent reste une attribution de l'opération et ne constitue pas une authentification individuelle.
- Le workflow V58 déploie uniquement Firebase Hosting et les règles Firestore. Il ne tente plus de déployer Cloud Functions ni d'activer des API payantes.
- Les fonctions existantes (WonyaPay, notifications push serveur et rappels planifiés) ne sont ni supprimées ni redéployées. Elles ne seront pas disponibles si le projet reste sur Spark ; les transferts externes et automatismes serveur sont donc hors de portée de ce déploiement gratuit.
- Les écritures Android existantes dans `yb_lumicash_journal` restent inchangées ; Android et Web Admin utilisent la même collection.
- À valider avant production : compilation/signature APK dans GitHub Actions, déploiement Hosting/règles avec le compte de service, et test réel lecture/écriture avec un compte administrateur puis refus avec un compte non-admin.
