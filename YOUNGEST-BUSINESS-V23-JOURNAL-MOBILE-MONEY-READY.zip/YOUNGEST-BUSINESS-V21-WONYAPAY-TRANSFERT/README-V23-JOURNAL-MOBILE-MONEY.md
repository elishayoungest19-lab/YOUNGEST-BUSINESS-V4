# YOUNGEST'S BUSINESS V23 — Journal Mobile Money

Version Android : versionCode 23, versionName 1.17.0.

Cette version ajoute une rubrique séparée « Journal envois » pour enregistrer manuellement les transferts déjà effectués. Elle ne déclenche aucun transfert. Le menu « Transferts » et son flux WonyaPay existant sont conservés.

Fonctions du journal : nom complet, téléphone, date, montant, frais saisis séparément, devise CDF/USD, note facultative, recherche, historique, rapports journalier et mensuel avec totaux séparés par devise.

Le workflow GitHub Actions compile directement le projet présent dans le dépôt (il ne recherche pas une ancienne archive ZIP), vérifie la version et la signature puis publie l’APK sous le nom V23.

Secrets requis dans GitHub Actions : KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_PASSWORD. KEY_ALIAS est facultatif si l’alias peut être détecté dans le keystore. Gardez la même clé de signature que les versions précédentes pour permettre les mises à jour par-dessus l’application installée.
