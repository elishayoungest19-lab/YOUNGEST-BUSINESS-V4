# YOUNGEST'S BUSINESS – V4

Prototype Android de gestion de prêts.

## Améliorations V4
- Persistance locale des clients, prêts et remboursements : les données restent après fermeture de l'application.
- Tableau de bord amélioré : prêts actifs, échéances dépassées, capital, intérêts, encaissé et solde.
- Journal des prêts et fiche détaillée de chaque prêt.
- Calcul automatique intérêt/total pendant la saisie.
- Date d'échéance calculée à partir de la durée.
- Fiche client avec résumé de ses prêts.
- Validation renforcée des montants, taux, durées et remboursements.

## Limitation importante
Cette version est encore un prototype local. Avant d'utiliser l'application avec de l'argent réel, il faudra ajouter un backend sécurisé, authentification réelle, base de données distante, sauvegardes, journal d'audit, gestion des rôles et intégration officielle des moyens de paiement.

## Build
GitHub Actions utilise JDK 17 et Gradle 8.9 pour construire `app-debug.apk`.


## V16
Module Transfert Mobile Money RDC : FC/USD, frais automatiques 1,5 %, statuts EN COURS/TERMINÉ/ANNULÉ et HISTORIQUE.
