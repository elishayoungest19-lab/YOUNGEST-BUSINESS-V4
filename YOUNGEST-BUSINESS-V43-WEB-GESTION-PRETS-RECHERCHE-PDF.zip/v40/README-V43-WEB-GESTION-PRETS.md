# YOUNGEST'S BUSINESS — V43 Web Admin Gestion des prêts

Correctifs Web prévus :
- Boutons Valider / Refuser pour les demandes en attente.
- Validation Web : saisie du taux d'intérêt, création d'un prêt dans `yb_loans`, puis mise à jour de la demande dans `yb_loan_requests`.
- Recherche et actualisation des demandes et prêts.
- Export PDF du rapport journalier des demandes, avec logo, date/heure, montants et statuts.
- Affichage du montant prêté, de l'échéance, des remboursements connus et du solde estimé.

Déploiement : utiliser la procédure Firebase Hosting habituelle du projet `youngestsbusiness` et tester avec un compte administrateur autorisé. La version ne doit pas être considérée comme validée en production avant essais de bout en bout. Vérifier en particulier les règles Firestore, la création du prêt, l'absence de doublons et la correspondance des remboursements par `loanId`.
