# YOUNGEST'S BUSINESS V37

## Objectif
V37 part directement de la base V36 validée, sans modifier le Chat client -> Administration ni l'interface Administration existante.

### 1. Rapports mensuels
- La rubrique **RAPPORTS MENSUELS** est conservée.
- Le bouton **GÉNÉRER / EXPORTER CE RAPPORT** produit maintenant un véritable fichier PDF via le sélecteur de document Android.
- Le texte du rapport mensuel est rendu en PDF multi-page.

### 2. Journal LUMICASH
- Nouvelle rubrique **JOURNAL LUMICASH** sur l'accueil, dans l'emplacement précédemment vide.
- **À PROPOS DE NOUS** et **CONTACTEZ-NOUS** sont placés sur la même ligne.
- Le titre reste **JOURNAL LUMICASH**.
- Deux espaces de rapport distincts :
  - Agent 1 : ELISHA YOUNGEST
  - Agent 2 : BLESSING
- Chaque agent dispose de :
  - nouvelle transaction ;
  - rapport journalier ;
  - rapport mensuel ;
  - historique des transactions ;
  - date ;
  - numéro du client ;
  - montant du transfert en FBu ;
  - frais de dépôt ;
  - export PDF réel.
- Les transactions sont enregistrées avec le champ `agent` et synchronisées dans `yb_lumicash_journal`.

### 3. Protection V36
- Chat client -> administration conservé.
- Réponse administration -> client conservée.
- `ownerUid` conservé.
- Notifications Firebase conservées.
- Les cartes Administration existantes sont conservées.

## Version
- versionCode : 37
- versionName : 1.30.0
- applicationId : `com.aistudio.youngestbiz.mbkz`
