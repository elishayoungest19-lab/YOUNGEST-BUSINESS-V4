# YOUNGEST’S BUSINESS V35 — CHAT DELIVERY FINAL

## Objectif
Garantir que les messages du Chat client arrivent dans la boîte de réception administrative.

## Corrections
- Le Chat client utilise la session Firebase anonyme déjà utilisée par l’espace client au lieu de dépendre de Phone Authentication/SMS.
- Le numéro international saisi par le client est conservé avec la conversation.
- Le brouillon du message et le numéro sont persistants via SharedPreferences.
- La création de la conversation et le premier message sont écrits dans une transaction Firestore.
- Les messages d’une conversation existante utilisent une transaction Firestore.
- La boîte Admin lit les conversations sans dépendre d’un `orderBy` Firestore et les trie localement par `updatedAt`.
- Les nouvelles conversations avec `adminUnread=true` sont clairement signalées à l’administration.
- Le texte des coordonnées utilise de vrais retours à la ligne.
- Les règles Firestore autorisent le Chat pour tout utilisateur Firebase authentifié possédant sa propre conversation; l’Admin reste contrôlé par UID/email.
- Le flux Phone Auth reste présent uniquement pour compatibilité source mais n’est plus appelé par le parcours Chat V35.

Version Android : versionCode 35, versionName 1.28.0.


V35 ADMIN CARDS CHAT FIX: interface administration conservée telle quelle. Le chat crée maintenant la conversation avant son premier message, et les règles Firestore n’exigent plus phone_number dans le token Firebase.


## V35 — objectif

Le parcours officiel est : Client → Contactez-nous → message → Firebase Firestore → Boîte de réception Admin → réponse Admin → notification client.

L’interface d’administration en cartes est conservée sans reconstruction ni remplacement.
