# V39 — YOUNGEST'S BUSINESS Administration PC/Web

V39 ajoute une première interface Web d'administration destinée à être ouverte depuis un ordinateur.

## Principe
- V38 Android est conservé.
- L'interface Web utilise le même projet Firebase `youngestsbusiness`.
- Authentification par email/mot de passe Firebase.
- Le compte administrateur attendu est `elishayoungest19@gmail.com`.
- Les règles Firestore de V38 restent la protection serveur.

## Modules initiaux
- Tableau de bord
- Clients
- Demandes de prêts
- Prêts
- Remboursements
- Journal LUMICASH
- Journal des envois Mobile Money (collection `yb_mobile_money_journal`)
- Chat clients

## Hébergement
Le `firebase.json` contient maintenant une section Hosting pointant vers `web-admin`.
Depuis un environnement Firebase CLI authentifié :

    firebase use youngestsbusiness
    firebase deploy --only hosting

Le déploiement doit être fait uniquement après vérification de l'environnement Firebase et des règles.

## Journal des envois
La rubrique « Journal des envois » est distincte du Journal LUMICASH. Elle affiche les envois Mobile Money enregistrés dans `yb_mobile_money_journal`, avec montant, frais, devise, bénéficiaire, numéro et statut. Elle ne déclenche aucun transfert réel.

**Important :** dans V38 Android, le journal des envois historique (`yb_mobile_money_journal_v24`) est encore stocké localement dans les préférences de l'appareil. Pour rendre cet historique visible sur le PC et synchronisé entre appareils, il faudra ensuite migrer/synchroniser ces enregistrements vers Firestore `yb_mobile_money_journal`.
