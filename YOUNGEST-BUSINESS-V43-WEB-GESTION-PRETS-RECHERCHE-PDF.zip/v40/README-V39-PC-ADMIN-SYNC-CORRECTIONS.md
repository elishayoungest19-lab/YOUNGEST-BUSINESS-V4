# YOUNGEST'S BUSINESS V39 — Corrections Web Admin et synchronisation

Cette révision ajoute :
- une rubrique Web « Rapports mensuels des prêts » basée sur les collections Firebase `yb_loans` et `yb_payments` ;
- un tableau complet du Journal des envois (bénéficiaire, numéro, montant, frais, total, statut, date et identifiant) ;
- un filtre LUMICASH pour afficher séparément ELISHA YOUNGEST et BLESSING, avec des totaux calculés pour l'agent choisi ;
- une règle Firestore dédiée à `yb_mobile_money_journal` ;
- l'envoi vers Firebase des nouvelles opérations du Journal des envois saisies par une session administrateur Android, ainsi que la migration des opérations locales déjà présentes lors de l'ouverture du journal ;
- version Android `versionCode 39`, `versionName 1.32.0`.

## À noter
Le déploiement Hosting seul ne publie pas les règles Firestore. Le workflow du dépôt doit exécuter `firebase deploy --only hosting,firestore:rules --project youngestsbusiness --non-interactive`.

Les opérations locales d'un téléphone ne peuvent être transférées vers Firebase que lorsque l'application est connectée avec la session administrateur autorisée et que les règles Firestore corrigées sont publiées. Les anciennes données ne sont pas supprimées par ce correctif.
