# YOUNGEST'S BUSINESS V40 — Journaux et synchronisation

Cette version ajoute les formulaires d'enregistrement Web pour le Journal des envois et LUMICASH, le filtre et les totaux Agent 1 / Agent 2, une rubrique de rapports mensuels des prêts, ainsi que l'envoi et la fusion du Journal des envois Android vers Firestore.

Collections utilisées : `yb_mobile_money_journal`, `yb_lumicash_journal`, `yb_loans`, `yb_payments`.

Important : l'historique local Android ne sera migré vers Firestore que lorsque l'application V40 aura été installée et que l'administrateur ouvrira le Journal des envois avec une connexion et des règles Firestore valides. Les rapports dépendent des champs/dates disponibles dans les documents Firestore et doivent être vérifiés sur données de test.

Les formulaires Web sont des formulaires d'historique comptable ; ils ne déclenchent pas de transfert d'argent.
