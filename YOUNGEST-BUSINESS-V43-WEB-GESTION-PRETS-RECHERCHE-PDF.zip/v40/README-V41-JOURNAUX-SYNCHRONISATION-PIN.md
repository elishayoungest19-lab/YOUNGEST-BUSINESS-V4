# YOUNGEST'S BUSINESS V41 — Journaux, PIN agent et rapports mensuels

## Changements V41
- Le formulaire Web LUMICASH demande le PIN de l'agent sélectionné.
- Le PIN est vérifié côté serveur dans la Cloud Function `createLumicashJournalEntry`; aucun PIN n'est inclus dans le code JavaScript public ou dans Firestore.
- La fonction vérifie l'identité administrateur et valide les champs avant d'enregistrer une opération.
- La lecture des dates de rapports accepte les timestamps Firestore, les secondes/millisecondes Unix et les dates texte.
- Version Android : `versionCode 40`, `versionName 1.33.0`.

## Configuration obligatoire avant le déploiement de la fonction
Dans le projet Firebase `youngestsbusiness`, créer les deux secrets Firebase Functions :
- `AGENT1_PIN` : PIN choisi pour Agent 1 (Elisha Youngest)
- `AGENT2_PIN` : PIN choisi pour Agent 2 (Blessing)

Depuis un terminal authentifié avec Firebase CLI et le projet sélectionné :
```bash
firebase functions:secrets:set AGENT1_PIN --project youngestsbusiness
firebase functions:secrets:set AGENT2_PIN --project youngestsbusiness
firebase deploy --only functions:createLumicashJournalEntry --project youngestsbusiness
```
Saisir les PIN à l'invite sécurisée. Ne pas les écrire dans un fichier, un commit, une capture d'écran ou un message. Après déploiement de la fonction, déployer le contenu `web-admin` de ce ZIP sur Firebase Hosting.

## Limites à vérifier en test
- Cette version ne transfère pas d'argent : LUMICASH reste un journal d'opérations comptables.
- La synchronisation du Journal des envois Android/Web dépend toujours de l'installation de cette version Android, d'une session administrateur active et des règles Firestore. Les anciennes entrées locales sont poussées lors de l'ouverture du journal; tester avant d'effacer les données de l'ancienne application.
- Le rapport mensuel n'est fiable que si les documents de prêt et de remboursement contiennent une date reconnue et les montants attendus.
