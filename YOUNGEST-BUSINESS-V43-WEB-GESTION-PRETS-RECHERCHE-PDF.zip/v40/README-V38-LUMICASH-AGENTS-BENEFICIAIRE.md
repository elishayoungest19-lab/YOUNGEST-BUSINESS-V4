# V38 — Journal Lumicash

Modifications par rapport à V37 :
- Agent 1 ELISHA YOUNGEST protégé par le code `Youngest081`.
- Agent 2 BLESSING protégé par le code `Blessing082`.
- Formulaire dans l’ordre : Numéro du client, Nom du bénéficiaire, Montant, Frais de dépôt, Date, Agent.
- Nom du bénéficiaire synchronisé avec Firestore et inclus dans l’historique et le PDF.
- Chat, Administration et synchronisation Firebase existants conservés.

Les codes sont vérifiés localement par hash SHA-256 dans l’APK. Pour une sécurité renforcée, une authentification Firebase distincte par agent pourra être ajoutée ultérieurement.
