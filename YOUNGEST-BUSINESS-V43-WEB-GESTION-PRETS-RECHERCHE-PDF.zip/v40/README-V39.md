# YOUNGEST'S BUSINESS V39

Base : V38.
Mission : ajouter un accès Administration Web depuis une machine/PC, connecté au même Firebase que l'application Android.
V38 Android n'est pas supprimé.
