# YOUNGEST’S BUSINESS V59 — Reçus officiels personnalisés

## Corrections de cette révision
- Reçu Web : logo officiel YB chargé depuis le chemin absolu de Firebase Hosting et impression déclenchée après le chargement de l’image.
- Cache Web : nouvelles versions de `app.js` et `styles.css` référencées dans `index.html` pour forcer le navigateur à récupérer les fichiers V59 corrigés.
- Ordre du reçu Web : numéro du bénéficiaire, nom, puis postnom.
- Montant envoyé et frais : affichage explicite de `USD` ou `FC (CDF)` pour chacun.
- Coordonnées du reçu : +243 817 447 127, +243 994 565 534, +257 646 604 75 — Congo / DRC.
- Reçu Android : affichage explicite `USD` ou `FC (CDF)` pour le montant et les frais, sans changer le format monétaire général des autres écrans.
- Logo officiel présent dans les ressources Web et Android.

## Déploiement
Le workflow `.github/workflows/yb-journal-v59.yml` construit l’APK signé et déploie Firebase Hosting + Firestore rules uniquement. Il ne déploie pas Cloud Functions.
