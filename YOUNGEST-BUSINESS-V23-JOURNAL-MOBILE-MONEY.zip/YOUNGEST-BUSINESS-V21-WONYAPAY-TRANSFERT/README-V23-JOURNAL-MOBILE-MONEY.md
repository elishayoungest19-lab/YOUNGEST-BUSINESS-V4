# V23 — Journal des envois Mobile Money

Cette version remplace l'entrée **TRANSFERTS** de l'espace Bureau par un journal manuel des envois déjà effectués. Aucun appel d'envoi WonyaPay n'est déclenché depuis cette rubrique.

Fonctions : saisie de la date, nom complet du bénéficiaire, téléphone, montant, devise CDF/USD, frais et note facultative ; recherche par nom/téléphone ; rapport journalier et mensuel calculé automatiquement, avec les montants et frais séparés par devise. Les enregistrements sont conservés dans les données locales de l'application.

Attention : le journal V23 est local à l'appareil et n'est pas encore synchronisé vers Firestore.
