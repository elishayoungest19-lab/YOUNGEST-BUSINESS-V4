# V67 — Agrandissement et ajustement du reçu A4

## Objectif
Conserver le reçu sur une seule page A4 tout en utilisant beaucoup mieux la surface imprimable, selon le modèle de référence fourni.

## Modifications ciblées
- Mise en page d’impression du reçu Mobile Money uniquement.
- Reçu dimensionné pour remplir presque toute la hauteur imprimable A4.
- Logo YB, identité de marque, bandeau opérateur, tableau, textes, QR code et contacts agrandis.
- Le tableau occupe l’espace vertical restant afin d’éviter un reçu tassé en haut de page.
- Styles mobiles conservés pour l’écran et isolés des styles d’impression.

Aucun champ, donnée Firebase, flux métier, règle Firestore, Cloud Function ou autre module n’est volontairement modifié. Déploiement Firebase Hosting uniquement.

Version Android source : versionCode 67, versionName 1.67.0-receipt-a4-layout.

À vérifier après déploiement : aperçu avant impression A4 sur iPhone et ordinateur, une seule page, QR code lisible et aucun élément coupé.
