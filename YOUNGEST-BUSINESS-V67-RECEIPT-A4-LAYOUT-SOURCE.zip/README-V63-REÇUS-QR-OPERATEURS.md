# YOUNGEST'S BUSINESS V63 — Reçus officiels avec QR et opérateur

## Changements
- Android : génération du QR par ZXing dans le PDF du reçu Mobile Money ; ajout d'un badge opérateur basé sur le réseau de la transaction ; pied de page avec site et date/heure.
- Web Admin : reçu imprimable avec badge opérateur, QR dynamique et pied de page site/date/heure.
- Web : `verify.html` appelle la fonction Firebase `verifyMobileMoneyReceipt` avec l'identifiant du document Firestore. La page n'expose que référence, opérateur, type, date/heure, montant, devise et statut. Le numéro et le nom du bénéficiaire ne sont jamais retournés.
- Backend : fonction callable en lecture seule, sans ouvrir la lecture publique de la collection Firestore.
- Version Android : versionCode 63 / versionName 1.63.0-branded-receipts-qr.

## Déploiement
Le déploiement doit publier Firebase Hosting et uniquement la fonction `verifyMobileMoneyReceipt` :
`firebase deploy --only hosting,functions:verifyMobileMoneyReceipt --project youngestsbusiness --non-interactive`

Aucune règle Firestore n'est modifiée. Aucun transfert Mobile Money réel n'est exécuté par cette fonction.

## Remarques
- Le QR contient une URL de vérification liée à l'identifiant Firestore du reçu.
- Les badges opérateurs utilisent les noms et couleurs distinctifs des réseaux ; les fichiers de logos officiels de chaque opérateur n'étaient pas fournis dans le ZIP V62 de base.
- Le QR Android est généré localement avec ZXing. Le reçu Web utilise QRCode.js depuis cdnjs ; une connexion Internet est nécessaire au chargement de cette bibliothèque lors de l'impression.
- Tester d'abord avec une transaction de démonstration dont le statut est « Effectuée » avant usage opérationnel.
