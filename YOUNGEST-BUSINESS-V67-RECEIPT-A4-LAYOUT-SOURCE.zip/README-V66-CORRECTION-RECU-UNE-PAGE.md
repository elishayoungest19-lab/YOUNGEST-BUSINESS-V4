# V66 — Correction ciblée de la pagination du reçu

## Cause identifiée
La règle CSS mobile `@media(max-width:520px)` était appliquée aussi pendant l’impression sur iPhone. Elle réintroduisait des tailles et espacements plus grands après les règles `@media print`, repoussant le pied de page sur une deuxième page A4.

## Correction
La règle mobile est désormais limitée à `@media screen and (max-width:520px)`. Elle ne modifie donc plus les dimensions d’impression. Les styles d’impression compacts V65 restent actifs.

Aucun champ, logo, QR code, contact, référence, couleur, fonction métier, règle Firestore ou Cloud Function n’est modifié.

Version Android source : versionCode 66, versionName 1.66.0-one-page-receipt-fix.
