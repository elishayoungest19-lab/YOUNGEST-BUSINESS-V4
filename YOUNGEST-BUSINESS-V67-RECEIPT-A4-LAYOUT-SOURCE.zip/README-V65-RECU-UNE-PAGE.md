# YOUNGEST’S BUSINESS V65 — Reçu PDF sur une seule page

## Objectif
V65 conserve le design du reçu Mobile Money V64 (logo YB, logos opérateurs, tableau, contacts, QR de vérification et couleurs) et compacte uniquement sa mise en page d’impression Web Admin pour tenir sur une seule page A4 portrait.

## Ajustements Web Admin
- Marges A4 réduites à 5 mm.
- En-tête et logo YB plus compacts à l’impression.
- Bannière et zone du logo opérateur resserrées.
- Espacement et taille de texte des lignes du tableau réduits sans supprimer de champ.
- Pied de page, contacts et QR code redimensionnés.
- Règles `break-inside` pour éviter une coupure du reçu.

## Préservation
Aucune donnée de transaction, aucun champ, aucun opérateur, aucune référence, aucun statut et aucune URL de vérification ne sont supprimés ou modifiés. Le style à l’écran reste distinct des règles d’impression. Le reçu Android conserve sa page A4 unique existante.

## Version
- Android `versionCode`: 65
- Android `versionName`: `1.65.0-one-page-receipt`

## Déploiement
Le workflow fourni déploie uniquement Firebase Hosting sur le projet `youngestsbusiness`. Il ne déploie ni Cloud Functions ni règles Firestore et ne demande pas d’activation de facturation.

## Test conseillé
Depuis Web Admin, ouvrir un reçu Mobile Money avec toutes les informations, lancer l’impression en A4 portrait et vérifier l’aperçu : une seule page doit contenir le reçu complet. Si le navigateur force des en-têtes/pieds de page, les désactiver dans la boîte d’impression.
