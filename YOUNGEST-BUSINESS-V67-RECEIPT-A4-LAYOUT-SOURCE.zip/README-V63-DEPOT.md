# V63 — Reçus Mobile Money avec QR de vérification

Archive source complète basée sur le projet V62 fourni.

- Android versionCode 63 / versionName 1.63.0-branded-receipts-qr.
- PDF Android : QR généré localement via ZXing, lien de vérification lié à l'ID Firestore, marque opérateur colorée, site et date/heure au pied.
- Web Admin : reçu imprimable avec QR dynamique et badge opérateur.
- Page publique `web-admin/verify.html` et fonction callable `verifyMobileMoneyReceipt` pour vérifier le statut sans ouvrir la lecture publique de la collection.
- Aucun changement des règles Firestore et aucune modification/suppression des enregistrements existants.

## Workflow
Fichier à déposer séparément dans le dépôt GitHub : `.github/workflows/yb-v63-receipts.yml`.
Il déploie uniquement Firebase Hosting et la fonction `verifyMobileMoneyReceipt`. Il ne construit pas l'APK Android.

## Important — logos opérateurs
Le ZIP V62 de base ne contenait pas les fichiers graphiques officiels des opérateurs. Pour éviter de fabriquer de faux logos, cette version affiche un badge de marque stylisé avec le nom et la couleur de l'opérateur détecté. Les vrais fichiers de logos officiels pourront remplacer ces badges dès qu'ils seront fournis ou validés.

## Test préalable
Après déploiement, tester le scan d'un reçu réel avec statut « Effectuée ». Le QR ouvre `https://youngestsbusiness.web.app/verify.html?id=...` et la fonction ne renvoie que référence, opérateur, type, date/heure, montant, devise et statut. Elle ne renvoie pas le nom ni le numéro du bénéficiaire.
