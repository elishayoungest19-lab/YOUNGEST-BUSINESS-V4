# V64 — Operator branding on receipts

- Android receipt PDF now selects a bundled operator image for M-Pesa/Vodacom, Airtel Money, Orange Money, and Afrimoney.
- Web Admin receipt print view uses matching local SVG assets from `web-admin/assets/operators/`.
- Lumicash and unknown operators retain a readable text fallback.
- No Cloud Functions, Cloud Build, Artifact Registry, Firebase billing, or Firestore rules changes are included.

## Important brand-asset note
The bundled SVG/PNG files in this draft are locally drawn text-and-symbol wordmark approximations based on public brand appearance, not original certified vector files supplied by the operators. Before using receipts as official partner-branded documents, replace them with approved brand-kit files from each operator.
