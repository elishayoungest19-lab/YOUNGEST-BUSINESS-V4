# YOUNGEST'S BUSINESS V11 — Firebase / Firestore

Cette version conserve les données locales existantes et ajoute une synchronisation centrale Firestore pour :

- Clients : `yb_clients`
- Prêts : `yb_loans`
- Paiements/remboursements : `yb_payments`

Chaque appareil s'authentifie anonymement auprès de Firebase pendant cette phase de test, puis écoute les trois collections en temps réel.

## Activation Firebase obligatoire

Dans Firebase Console :

1. Ouvrir le projet `youngestsbusiness`.
2. Aller dans Authentication → Sign-in method.
3. Activer le fournisseur **Anonymous**.
4. Enregistrer.
5. Dans Firestore Database → Rules, publier le contenu de `firestore.rules`.

Les règles autorisent actuellement uniquement les utilisateurs authentifiés à lire/écrire les trois collections de bureau. Elles sont destinées à la phase de test multi-téléphones. Une gestion de rôles plus stricte devra être ajoutée avant un déploiement réel.

## Paiement

Le bouton `💳 PAIEMENT` permet d'enregistrer un paiement reçu et de le synchroniser. Il ne déclenche pas encore automatiquement une transaction Mobile Money. L'intégration réelle M-Pesa/Airtel/etc. nécessitera les API officielles et un backend sécurisé.
