YOUNGEST’S BUSINESS V56 — WIFI VOUCHER MANAGER
================================================
Basé sur la source V55 fournie.

Ajouts :
- Ajout de l’action « Imprimer les vouchers A4 » dans le registre des coupons.
- Génération d’une planche imprimable au format A4, deux colonnes, style bleu marine, vert et or.
- Le document contient zone/routeur, forfait, prix, identifiant, statut et avertissement d’activation.
- Les coupons sont filtrés sur le statut PRÉPARÉ — NON ACTIVÉ pour éviter de présenter des coupons non validés comme actifs.
- Mise à jour du libellé du module Wi-Fi vers V56.

Limites explicites :
- Cette impression est un modèle d’exploitation à partir des coupons existants. Les champs utilisateur/mot de passe utilisent le nom de coupon et un placeholder si aucun identifiant n’existe encore.
- Aucun compte HotSpot n’est créé sur un routeur par cette version.
- Le statut « ACTIVÉ » ne doit être accordé qu’après intégration sécurisée et confirmation réelle du MikroTik.
- Les fonctions existantes et règles Firebase n’ont pas été testées sur le projet de production.
