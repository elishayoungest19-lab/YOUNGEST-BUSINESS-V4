# YOUNGEST'S BUSINESS V54 — Wi-Fi suivi et contrôle

Cette version regroupe les corrections Wi-Fi en une seule base source, en conservant les autres modules de YOUNGEST'S BUSINESS.

## Changements V54
- Android : création de références de coupons uniques (1 à 50 par opération), statut initial `PREPARE_NON_ACTIVE`, marqueurs `singleUse=true`, `shareable=false` et `networkActivated=false`.
- Android : enregistrement manuel d'une vente à partir du code exact du coupon; empêche une seconde vente si le coupon n'est plus préparé; met à jour le coupon et le journal des ventes en batch.
- Android : rapprochement de caisse (attendu, remis, écart, agent, note) et export PDF des statistiques.
- Android/Web : collections d'audit `yb_wifi_audit_logs` et de rapprochement `yb_wifi_cash_reconciliations`; historique sans modification/suppression permise par les règles Firestore.
- Web : onglet « Caisse & audit » avec rapprochements par période et devise et historique des actions.
- Version Android : `versionCode 54`, `versionName 1.54.0-wifi`.

## Limites à ne pas confondre avec les fonctionnalités administratives
- Les ventes sont saisies manuellement et ne prouvent pas à elles seules qu'un paiement externe a été reçu.
- Les références de coupon ne sont pas des identifiants d'accès réseau actifs. L'activation, l'expiration automatique, le blocage du partage et les sessions réelles nécessitent une intégration MikroTik via un backend sécurisé.
- Le rôle Wi-Fi séparé pour un gestionnaire dédié doit être validé avec les comptes Firebase réels et des règles de sécurité testées avant d'accorder un accès non-administrateur. Cette source ne doit pas être présentée comme une validation complète de ce rôle.
- Le rapprochement Android V54 agrège les ventes confirmées de la devise choisie sur l'historique disponible; utiliser le filtre de période dans le Web pour une clôture journalière ou mensuelle.

## Vérifications prévues dans GitHub Actions
1. Intégrité du ZIP et présence des fichiers requis.
2. `node --check web-admin/app.js`.
3. Vérification des marqueurs Android V54, des collections Wi-Fi et du logo.
4. Compilation Gradle, vérification de signature et du package/version de l'APK.
5. Déploiement Web/Firestore seulement après succès de la compilation.

Le succès de GitHub Actions confirme la compilation et le déploiement, pas les tests fonctionnels sur téléphone ou routeur. Tester les coupons, ventes, synchronisation, PDF et règles Firestore avant usage réel.
