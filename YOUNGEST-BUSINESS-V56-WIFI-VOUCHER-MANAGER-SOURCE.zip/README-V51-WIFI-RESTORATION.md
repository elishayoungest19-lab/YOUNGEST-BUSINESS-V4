# V51 — Restauration prudente de YOUNGEST'S B WIFI

Cette source est basée sur `YOUNGEST-BUSINESS-V50-CORRECTED-SOURCE.zip`, dont le code Android et l'administration Web contiennent déjà l'interface Wi-Fi.

Modifications apportées :
- version Android : `versionCode 51`, `versionName 1.51.0-wifi`;
- cache-buster de l'interface Web mis à jour pour V51;
- les fichiers fonctionnels de V50, y compris les écrans YOUNGEST'S B WIFI, la configuration Firestore et les fonctions existantes, sont conservés.

Aucune règle Firestore n'a été élargie et aucun faux coupon, vente ou état de routeur n'a été ajouté.
Cette archive n'a pas encore été compilée ni déployée. Vérifier les marqueurs Wi-Fi et le résultat de compilation dans GitHub Actions avant installation.
