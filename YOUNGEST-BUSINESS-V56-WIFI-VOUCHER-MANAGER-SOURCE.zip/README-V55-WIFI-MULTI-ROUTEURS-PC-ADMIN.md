# YOUNGEST'S BUSINESS V55 — YOUNGEST'S B WIFI Multi-routeurs & PC Admin

## Ajouts
- Tableau de bord principal du PC Admin : indicateurs YOUNGEST'S B WIFI et accès direct au module.
- Nouvel onglet « Mes routeurs » dans YOUNGEST'S B WIFI pour enregistrer plusieurs zones/routeurs (nom, code interne, emplacement, SSID et état administratif).
- Génération des références de coupons avec attribution au routeur/à la zone sélectionnée.
- Registre des coupons affiche désormais la zone attribuée.
- Collection Firestore `yb_wifi_routers`, protégée par les règles administrateur.
- Journal d'audit lors de l'enregistrement d'un routeur.

## Limites importantes
- Cette version enregistre les routeurs et les affectations administratives dans Firebase. Elle ne communique pas encore avec des MikroTik physiques.
- Les coupons restent « PRÉPARÉ — NON ACTIVÉ » tant qu'un backend sécurisé et une installation MikroTik réelle ne sont pas configurés et testés.
- Ne jamais stocker les mots de passe ou secrets MikroTik dans le JavaScript du navigateur ou dans les documents accessibles au client.
- Les ventes par agents nécessitent encore un flux d'authentification, des permissions dédiées et des règles serveur. Les écritures financières restent réservées à l'administrateur dans cette version.

## Déploiement
1. Vérifier le projet Firebase `youngestsbusiness` et les règles Firestore.
2. Tester l'interface PC Admin sur un environnement de test.
3. Déployer les règles avec `firebase deploy --only firestore:rules`.
4. Déployer l'administration Web avec `firebase deploy --only hosting`.
5. Tester création de routeurs, affectation de coupons et rapports avant usage réel.

## Contrôles effectués
- Vérification syntaxique JavaScript (`node --check web-admin/app.js`).
