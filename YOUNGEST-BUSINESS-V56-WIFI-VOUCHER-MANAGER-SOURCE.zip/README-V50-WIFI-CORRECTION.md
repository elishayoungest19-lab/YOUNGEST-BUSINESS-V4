# V50 — Correction YOUNGEST’S B WIFI

## Modifications
- Web Admin : configuration du service sauvegardée dans Firestore (`yb_wifi_config/main`).
- Profils et tarifs enregistrés dans `yb_wifi_profiles`, synchronisés en temps réel. Ils restent non activés sur le réseau tant que MikroTik n’est pas intégré.
- Journal et rapports lisent les enregistrements Firebase ; aucun faux chiffre ni faux coupon de démonstration.
- Android : nouvelle entrée réservée à l’administration permettant de lire et enregistrer la configuration Wi-Fi sur le même document Firestore.
- Firestore : accès administrateur pour configuration/profils ; écriture directe de ventes et coupons bloquée afin que le navigateur ne puisse pas inventer de ventes. Le backend sécurisé devra créer ces enregistrements.
- Workflow V50 prévu pour construire l’APK signé et déployer le Web Admin + règles depuis cette même archive source.

## Limites explicites
Cette version ne contrôle pas encore le routeur MikroTik, ne génère pas de vrais coupons, ne traite pas les paiements et ne confirme pas la connectivité de l’antenne. Ces fonctions nécessitent le matériel réel, la configuration RouterOS et un backend serveur sécurisé.

## Construction GitHub Actions
Placer ce ZIP sous le nom exact `YOUNGEST-BUSINESS-V50-CORRECTED-SOURCE.zip` à la racine du dépôt. Les secrets déjà configurés restent dans GitHub ; ne pas les inscrire dans les fichiers source. Puis lancer le workflow V50.
