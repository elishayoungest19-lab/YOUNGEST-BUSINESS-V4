# YOUNGEST’S BUSINESS V56 — Web-only Wi-Fi coupon print adjustment

This ZIP updates the Web Admin voucher print layout. Coupons are printed from the Web Admin only; the printable sheet uses four columns and up to 32 tickets per A4 page. The same coupon code is printed in both the username and password fields.

Coupons are still marked **PRÉPARÉ — NON ACTIVÉ**. This change does not create HotSpot accounts on MikroTik or confirm network activation. The printed layout and JavaScript syntax have been updated, but the full Android build and live browser print preview must be verified in GitHub Actions and on the target browser.
