package com.aistudio.youngestbiz.mbkz;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class AppNotificationService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "youngest_business_notifications";
    private static final String PREFS = "youngest_business_data";

    public static void createChannel(Context context){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null){
                NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"YOUNGEST'S BUSINESS",NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Notifications des prêts, remboursements et transferts");
                nm.createNotificationChannel(ch);
            }
        }
    }

    public static void notifyLocal(Context context,String title,String message){
        saveNotification(context,title,message);
        createChannel(context);
        if(Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        Intent intent=new Intent(context,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(context,CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi);
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null) nm.notify((int)(System.currentTimeMillis() & 0x7fffffff),b.build());
    }

    private static void saveNotification(Context context,String title,String message){
        try{
            android.content.SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
            JSONArray old=new JSONArray(p.getString("app_notifications","[]"));
            JSONArray out=new JSONArray();
            JSONObject n=new JSONObject();
            n.put("title",title); n.put("message",message);
            n.put("date",new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));
            out.put(n);
            for(int i=0;i<old.length() && i<49;i++) out.put(old.getJSONObject(i));
            p.edit().putString("app_notifications",out.toString()).apply();
        }catch(Exception ignored){}
    }

    @Override public void onMessageReceived(RemoteMessage message){
        String title=message.getNotification()!=null?message.getNotification().getTitle():null;
        String body=message.getNotification()!=null?message.getNotification().getBody():null;
        Map<String,String> data=message.getData();
        if(title==null || title.isEmpty()) title=data.get("title");
        if(body==null || body.isEmpty()) body=data.get("body");
        if(title==null || title.isEmpty()) title="YOUNGEST'S BUSINESS";
        if(body==null || body.isEmpty()) body="Vous avez une nouvelle notification.";
        notifyLocal(this,title,body);
    }

    @Override public void onNewToken(String token){
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("fcm_token",token).apply();
    }
}
