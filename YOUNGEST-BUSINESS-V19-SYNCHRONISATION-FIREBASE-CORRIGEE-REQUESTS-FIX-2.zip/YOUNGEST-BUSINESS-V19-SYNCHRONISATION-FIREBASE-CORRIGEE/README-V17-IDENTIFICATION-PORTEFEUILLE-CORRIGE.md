# YOUNGEST'S BUSINESS — V17 corrigé

## Objectif V17

V17 sépare clairement l'espace client de l'espace bureau et ajoute un parcours de transfert Mobile Money centré sur l'identification du portefeuille :

**Numéro → réseau/portefeuille (M-Pesa, Airtel Money, Orange Money, Afrimoney) → titulaire du portefeuille → montant → frais 1,5 % → authentification du fournisseur → résultat.**

### Espace client
- Accès indépendant du contrôle administrateur.
- Bouton ENVOYER DE L'ARGENT.
- Choix du portefeuille source et du portefeuille bénéficiaire.
- Numéro du portefeuille.
- Bouton de vérification.
- Nom du titulaire affiché en lecture seule lorsqu'une vérification pilote est disponible.
- Historique MES TRANSFERTS.
- Le transfert initié par le client est marqué clientInitiated et n'exige pas une validation manuelle du bureau.

### Espace bureau
- Accès protégé par l'administration.
- Les transferts initiés par le client sont affichés en supervision.
- Aucun bouton TERMINER/ANNULER manuel n'est présenté pour un transfert client ; le statut doit venir du prestataire dans la version connectée.

### Vérification Mobile Money
La version actuelle est un **mode pilote/simulation**. Elle ne lit pas le nom de la SIM et ne prétend pas interroger directement M-Pesa, Airtel Money, Orange Money ou Afrimoney.

Pour une vérification réelle, il faudra connecter le fournisseur/API officiel ou un PSP autorisé qui accepte ce type de vérification et retourne le titulaire lorsque cette donnée est disponible.

### Sécurité
- Aucun PIN Mobile Money n'est demandé ou stocké par YOUNGEST'S BUSINESS.
- En production, l'authentification doit être effectuée par l'opérateur/PSP avec son propre mécanisme (PIN, OTP, USSD, push, etc.).
- Les clés/API secrètes ne doivent pas être placées dans l'APK ; elles doivent rester côté serveur sécurisé.

### Important
Le bouton d'autorisation actuel simule uniquement la réponse du fournisseur. Il ne débite ni M-Pesa, ni Airtel Money, ni Orange Money, ni Afrimoney.
