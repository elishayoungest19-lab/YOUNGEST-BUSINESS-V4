# YOUNGEST’S BUSINESS — V19 Synchronisation Firebase corrigée

Cette version conserve les fonctions existantes et renforce la synchronisation multi-téléphones des clients, prêts et remboursements.

## Correction principale
- Un prêt reçu avant son client n’est plus perdu : le prêt contient aussi le nom et le téléphone du client comme secours.
- Un remboursement reçu avant son prêt est conservé temporairement puis rattaché lorsque le prêt arrive.
- Les nouveaux prêts créés sur un téléphone peuvent ainsi être récupérés par les autres téléphones connectés au même Firestore.
- Les identifiants restent stables afin d’éviter les doublons lors des snapshots Firestore.

## Important
Cette application utilise Firebase/Firestore pour la synchronisation. Les transferts Mobile Money restent en mode simulation tant qu’une intégration opérateur/API officiellement autorisée n’est pas connectée.
