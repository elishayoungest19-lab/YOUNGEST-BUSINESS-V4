# V47 — Archivage réversible des prêts

- Les dossiers sont actifs par défaut.
- Depuis Gestion des prêts, l’administration peut archiver ou restaurer chaque dossier.
- Les dossiers archivés restent dans `yb_loans` et ne sont pas supprimés. Les remboursements restent dans `yb_payments`.
- Le filtre permet d’afficher les dossiers actifs, archivés ou tous les dossiers.
- Les vues de production, les rapports de prêts et le traitement des rappels doivent exclure les dossiers archivés.
- Avant toute utilisation en production, vérifier les droits Firestore d’administration et tester sur un dossier d’essai confirmé.
